/* ===== الرسومات: SVG بالكود — تدرجات وظلال وإضاءة لواقعية أكبر ===== */
const shade=(h,a)=>{const n=parseInt(h.slice(1),16),f=c=>Math.max(0,Math.min(255,Math.round(a>0?c+(255-c)*a:c*(1+a))));
 return '#'+[n>>16,n>>8&255,n&255].map(c=>f(c).toString(16).padStart(2,'0')).join('')};
let UID=0;

function kid(o={}){
 const m=o.mood||'happy',hat=o.h,crop=!!o.crop,u='k'+(++UID);
 const noHair=['h2','h5','h6','h7'].includes(hat);
 const ink='#3a2418',lip='#8a2f45';
 const defs=`<defs>
 <radialGradient id="${u}s" cx=".42" cy=".3" r=".85"><stop offset="0" stop-color="#fff2de"/><stop offset=".55" stop-color="#ffdcb0"/><stop offset="1" stop-color="#e9ab78"/></radialGradient>
 <linearGradient id="${u}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#86b0ff"/><stop offset=".55" stop-color="#4f86ff"/><stop offset="1" stop-color="#3159cf"/></linearGradient>
 <linearGradient id="${u}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#85563a"/><stop offset="1" stop-color="#2f1c0e"/></linearGradient>
 <radialGradient id="${u}i" cx=".4" cy=".32" r=".8"><stop offset="0" stop-color="#c78f55"/><stop offset=".55" stop-color="#6b3f1e"/><stop offset="1" stop-color="#2a1305"/></radialGradient>
 <radialGradient id="${u}c" r=".5"><stop offset="0" stop-color="#ff7f9a" stop-opacity=".8"/><stop offset="1" stop-color="#ff7f9a" stop-opacity="0"/></radialGradient></defs>`;
 const arm=(sx,ang,cls)=>`<g transform="rotate(${ang} ${sx} 96)"><g class="${cls||''}"><rect x="${sx-6.5}" y="92" width="13" height="30" rx="6.5" fill="url(#${u}b)"/><rect x="${sx-6.5}" y="108" width="13" height="4" fill="#fff" opacity=".85"/><circle cx="${sx}" cy="123" r="8" fill="#fff"/><path d="M${sx-6} 125Q${sx} 133 ${sx+6} 125Q${sx+2} 129 ${sx-6} 125Z" fill="#d6ddee"/></g></g>`;
 const aL=m=='cheer'?arm(36,150,'wv'):m=='wow'?arm(36,62):arm(36,8);
 const aR=m=='happy'?arm(84,-148,'wv2'):m=='cheer'?arm(84,-150,'wv'):m=='think'?arm(84,160):m=='wow'?arm(84,-62):arm(84,-8);
 const br={happy:['M37 46Q46 41 55 46','M65 46Q74 41 83 46'],
  wow:['M37 40Q46 34 55 40','M65 40Q74 34 83 40'],
  cheer:['M37 41Q46 35 55 41','M65 41Q74 35 83 41'],
  think:['M37 47Q46 44 55 47','M65 40Q74 34 83 40'],
  oops:['M37 49L55 43','M65 43L83 49']}[m];
 const mouth={
  happy:`<path d="M47 73Q60 91 73 73Z" fill="${lip}"/><path d="M48.5 73.6Q60 78 71.5 73.6L73 73H47Z" fill="#fff"/><ellipse cx="60" cy="81" rx="5.5" ry="2.8" fill="#ff7a90"/>`,
  wow:`<ellipse cx="60" cy="80" rx="7" ry="9" fill="${lip}"/><ellipse cx="60" cy="85" rx="4.5" ry="2.5" fill="#ff7a90"/>`,
  cheer:`<path d="M43 72Q60 102 77 72Z" fill="${lip}"/><path d="M45 72.6Q60 78 75 72.6L77 72H43Z" fill="#fff"/><ellipse cx="60" cy="86" rx="8" ry="4" fill="#ff7a90"/>`,
  think:`<path d="M52 79Q60 75 69 80" stroke="${lip}" stroke-width="3.5" stroke-linecap="round" fill="none"/>`,
  oops:`<path d="M47 84Q54 74 60 80Q66 86 73 76" stroke="${lip}" stroke-width="3.5" stroke-linecap="round" fill="none"/>`}[m];
 const hair=noHair?'':`<path d="M20 58Q12 8 60 11Q108 8 100 58Q96 36 80 31Q70 40 54 31Q32 34 20 58Z" fill="url(#${u}h)"/><path d="M56 14Q60 0 72 7Q64 11 67 19Z" fill="url(#${u}h)"/><path d="M36 26Q58 15 82 27M28 40Q34 30 46 27M84 31Q94 38 97 50" stroke="#b27f56" stroke-width="2.6" fill="none" stroke-linecap="round" opacity=".55"/>`;
 const hats={
  h1:`<path d="M88 24L106 14V34Z M88 24L70 14V34Z" fill="#ff5d8f"/><path d="M88 24L106 14V22Z M88 24L70 14V22Z" fill="#ff8fb3"/><circle cx="88" cy="24" r="5" fill="#ffd23f" stroke="#e0a800" stroke-width="1.5"/>`,
  h2:`<path d="M22 44Q22 12 60 12Q98 12 98 44Z" fill="#e63946"/><path d="M30 36Q32 18 60 16" stroke="#ff7b86" stroke-width="3" fill="none" opacity=".6" stroke-linecap="round"/><rect x="58" y="38" width="50" height="9" rx="4.5" fill="#b3101c"/><circle cx="60" cy="12" r="4" fill="#fff"/>`,
  h3:`<circle cx="46" cy="58" r="12.5" fill="rgba(125,249,255,.22)" stroke="#222" stroke-width="3.5"/><circle cx="74" cy="58" r="12.5" fill="rgba(125,249,255,.22)" stroke="#222" stroke-width="3.5"/><path d="M58.5 58H61.5" stroke="#222" stroke-width="3.5"/><path d="M38 52Q42 49 47 50M66 52Q70 49 75 50" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" opacity=".8"/>`,
  h4:`<path d="M19 58Q16 14 60 14Q104 14 101 58" fill="none" stroke="#333" stroke-width="7"/><path d="M24 50Q24 20 60 19" fill="none" stroke="#666" stroke-width="2" opacity=".7"/><rect x="11" y="50" width="14" height="26" rx="7" fill="#ff6b9d"/><rect x="95" y="50" width="14" height="26" rx="7" fill="#ff6b9d"/><rect x="14" y="54" width="4" height="16" rx="2" fill="#ffb3cf"/>`,
  h5:`<ellipse cx="60" cy="30" rx="44" ry="8" fill="#1d1d1d"/><rect x="38" y="-8" width="44" height="40" rx="5" fill="#2a2a2a"/><rect x="38" y="16" width="44" height="8" fill="#e63946"/><rect x="42" y="-6" width="5" height="36" fill="#fff" opacity=".12"/>`,
  h6:`<path d="M32 30L35 4L48 20L60 0L72 20L85 4L88 30Z" fill="#ffd23f" stroke="#e0a800" stroke-width="2"/><path d="M34 28L36 10L46 22" fill="#fff3a8" opacity=".6"/><circle cx="60" cy="14" r="3.5" fill="#e63946"/><circle cx="42" cy="20" r="2.2" fill="#4cc9f0"/><circle cx="78" cy="20" r="2.2" fill="#7bd957"/>`,
   h7:`<path d="M10 40Q60 56 110 40Q100 46 60 46Q20 46 10 40Z" fill="#5b2d9e"/><path d="M28 42Q38 14 66 -18Q70 12 92 42Z" fill="#6f3bbf"/><path d="M30 40Q42 18 64 -12Q58 16 52 42Z" fill="#9b6df0" opacity=".5"/><rect x="30" y="30" width="62" height="8" fill="#ffd23f"/><path d="M62 4L64.4 9.4L70 10L65.8 13.8L67 19.4L62 16.6L57 19.4L58.2 13.8L54 10L59.6 9.4Z" fill="#ffe066"/>`,
   h8:`<circle cx="60" cy="62" r="50" fill="rgba(160,220,255,.16)" stroke="#e8eef8" stroke-width="5"/><path d="M22 44Q30 20 56 14" stroke="#fff" stroke-width="4.5" fill="none" stroke-linecap="round" opacity=".75"/><rect x="38" y="104" width="44" height="9" rx="4" fill="#cfd6e6" stroke="#9aa6bf" stroke-width="1.5"/>`,
   h9:`<path d="M20 50Q40 42 60 52Q80 42 100 50Q102 70 82 72Q66 72 60 62Q54 72 38 72Q18 70 20 50Z" fill="#1d1d2e"/><path d="M26 52Q40 47 54 54" stroke="#6b6b9a" stroke-width="2" fill="none" opacity=".7"/><ellipse cx="46" cy="58" rx="7.5" ry="6" fill="#fff"/><ellipse cx="74" cy="58" rx="7.5" ry="6" fill="#fff"/><circle cx="46" cy="58" r="4.3" fill="#2a1305"/><circle cx="74" cy="58" r="4.3" fill="#2a1305"/><circle cx="47.5" cy="56.3" r="1.5" fill="#fff"/><circle cx="75.5" cy="56.3" r="1.5" fill="#fff"/><path d="M20 52Q6 44 2 50M100 52Q114 44 118 50" stroke="#e63946" stroke-width="5" fill="none" stroke-linecap="round"/>`,
   h10:``,h11:`<path d="M44 92Q60 106 76 92L80 100Q60 116 40 100Z" fill="#e63946"/><circle cx="60" cy="100" r="4.5" fill="#ffd23f" stroke="#e0a800" stroke-width="1.2"/>`};
  const backs={h10:`<path d="M34 98Q-10 70 -2 22Q14 44 32 52Q20 64 38 82Z" fill="#fff" stroke="#cfe3ff" stroke-width="2"/><path d="M86 98Q130 70 122 22Q106 44 88 52Q100 64 82 82Z" fill="#fff" stroke="#cfe3ff" stroke-width="2"/><path d="M6 34Q14 50 28 56M114 34Q106 50 92 56" stroke="#cfe3ff" stroke-width="2" fill="none"/>`,h11:`<path d="M38 94L14 146Q60 160 106 146L82 94Z" fill="#e63946"/><path d="M38 94L14 146Q34 150 46 146L50 100Z" fill="#b3101c" opacity=".55"/>`};
 const ix=m=='think'?2.2:0,iy=m=='think'?-2:m=='oops'?1:0,ey=m=='wow'||m=='cheer'?9.4:8.4;
 const eyes=[46,74].map(x=>`<ellipse cx="${x}" cy="58" rx="7.4" ry="${ey}" fill="#fff"/><circle cx="${x+ix}" cy="${58+iy}" r="5.7" fill="url(#${u}i)"/><circle cx="${x+ix}" cy="${58+iy}" r="2.6" fill="#0f0602"/><circle cx="${x+ix+2.1}" cy="${58+iy-2.5}" r="1.9" fill="#fff"/><circle cx="${x+ix-1.9}" cy="${58+iy+2}" r=".9" fill="#fff" opacity=".8"/><path d="M${x-8} 56Q${x} ${58-ey-3} ${x+8} 56" stroke="${ink}" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M${x+7.5} 55.5l2.4-2.2" stroke="${ink}" stroke-width="1.6" stroke-linecap="round"/>`).join('');
 return `<svg class="${crop?'kidc':'kid'}" viewBox="${crop?(o.wide&&(hat=='h10'||hat=='h11')?'-6 -14 132 176':'8 -12 104 108'):'0 -14 120 164'}" xmlns="http://www.w3.org/2000/svg">${defs}`+
  `<ellipse cx="60" cy="147" rx="34" ry="4" fill="#000" opacity=".18"/>`+(backs[hat]||'')+
  `<rect x="42" y="126" width="14" height="20" rx="6" fill="#2b4aa8"/><rect x="64" y="126" width="14" height="20" rx="6" fill="#2b4aa8"/>`+
  `<rect x="39" y="136" width="19" height="11" rx="5.5" fill="#fff"/><rect x="62" y="136" width="19" height="11" rx="5.5" fill="#fff"/><rect x="39" y="142" width="19" height="5" rx="2.5" fill="#cfd6e6"/><rect x="62" y="142" width="19" height="5" rx="2.5" fill="#cfd6e6"/>`+
  `<rect x="52" y="86" width="16" height="16" rx="6" fill="#e6a878"/>`+
  `<rect x="34" y="92" width="52" height="44" rx="20" fill="url(#${u}b)"/><ellipse cx="50" cy="104" rx="10" ry="7" fill="#fff" opacity=".14"/><path d="M45 93Q60 108 75 93L71 90Q60 99 49 90Z" fill="#fff"/><rect x="36" y="127" width="48" height="5" rx="2.5" fill="#2b4aa8"/>`+
  `<polygon points="60,106 62.6,111.6 68.8,112.4 64.2,116.6 65.4,122.8 60,119.8 54.6,122.8 55.8,116.6 51.2,112.4 57.4,111.6" fill="#ffd23f" stroke="#e0a800" stroke-width="1.2" stroke-linejoin="round"/>`+aL+aR+
  `<circle cx="21" cy="60" r="8" fill="url(#${u}s)"/><circle cx="22" cy="61" r="4.2" fill="#e99a7c" opacity=".6"/><circle cx="99" cy="60" r="8" fill="url(#${u}s)"/><circle cx="98" cy="61" r="4.2" fill="#e99a7c" opacity=".6"/>`+
  `<ellipse cx="60" cy="58" rx="40" ry="38" fill="url(#${u}s)"/><ellipse cx="60" cy="88" rx="26" ry="5" fill="#c98b5b" opacity=".16"/>`+hair+
  br.map(d=>`<path d="${d}" stroke="${ink}" stroke-width="3.6" stroke-linecap="round" fill="none"/>`).join('')+eyes+
  `<path d="M57 67Q60 70.5 63 67" stroke="#d29566" stroke-width="2.2" fill="none" stroke-linecap="round"/><ellipse cx="59" cy="64.4" rx="2" ry="1.3" fill="#fff" opacity=".5"/>`+
  `<circle cx="34" cy="72" r="10" fill="url(#${u}c)"/><circle cx="86" cy="72" r="10" fill="url(#${u}c)"/>`+mouth+(hats[hat]||'')+`</svg>`}

function shipSvg(sh,pilot){const c=sh[3]||'#ffd23f',d=shade(c,-.3),l=shade(c,.45),dd=shade(c,-.5),u='s'+(++UID);
 const id=sh[0],glass=`url(#${u}g)`;
 const win=(cx,cy,rx,ry)=>{const cid=u+'w';let k='';
  if(pilot){const z=(2*rx*.95)/80,kd=kid(Object.assign({crop:1},pilot)).replace('<svg class="kidc"',`<svg x="${(cx-52*z).toFixed(1)}" y="${(cy-70*z+2).toFixed(1)}" width="${(104*z).toFixed(1)}" height="${(108*z).toFixed(1)}"`);k=`<g clip-path="url(#${cid})">${kd}</g>`}
  return `<clipPath id="${cid}"><ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}"/></clipPath><ellipse cx="${cx}" cy="${cy}" rx="${rx+2.6}" ry="${ry+2.6}" fill="${d}"/><ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#16264a"/>${k}<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${glass}" opacity="${pilot?.14:.85}"/><path d="M${cx-rx*.62} ${cy-ry*.3}Q${cx-rx*.35} ${cy-ry*.82} ${cx+rx*.12} ${cy-ry*.86}" stroke="#fff" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".8"/>`};
 const fl=(x,y,w,len,o,i)=>`<path class="fl" d="M${x-w} ${y}Q${x} ${y+len} ${x+w} ${y}Z" fill="${o}"/><path class="fl" d="M${x-w*.5} ${y}Q${x} ${y+len*.68} ${x+w*.5} ${y}Z" fill="${i}"/>`;
 let b='';
 if(id=='s0'){/* صاروخ كلاسيكي */
  b=fl(65,112,13,34,'#ff9f1c','#ffe066')+`<path d="M22 112L36 74V112Z M108 112L94 74V112Z" fill="${d}"/><path d="M32 112Q28 70 65 40Q102 70 98 112Z" fill="${c}"/><path d="M40 108Q38 74 65 46Q50 74 52 108Z" fill="#fff" opacity=".22"/><rect x="30" y="106" width="70" height="8" rx="4" fill="${d}"/>${win(65,84,15,15)}`;
 }else if(id=='s1'){/* طبق طائر */
  b=fl(65,108,13,28,'#9bf6ff','#fff')+`<path d="M35 92Q65 40 95 92Z" fill="${glass}" opacity=".5"/>${win(65,76,21,19)}<ellipse cx="65" cy="98" rx="58" ry="17" fill="${c}"/><ellipse cx="65" cy="92" rx="50" ry="8" fill="#fff" opacity=".18"/><path d="M12 100Q65 126 118 100Q112 112 65 114Q18 112 12 100Z" fill="${d}"/>`+[28,47,65,83,102].map(x=>`<circle cx="${x}" cy="99" r="4" fill="#ffe066"/><circle cx="${x-1}" cy="98" r="1.4" fill="#fff"/>`).join('');
 }else if(id=='s2'){/* مكوك بجناحين */
  b=fl(54,112,7,26,'#ff9f1c','#ffe066')+fl(76,112,7,26,'#ff9f1c','#ffe066')+`<path d="M46 80L8 120L8 128L46 114Z M84 80L122 120L122 128L84 114Z" fill="${d}"/><path d="M46 84L16 118L46 110Z M84 84L114 118L84 110Z" fill="${l}" opacity=".4"/><path d="M65 26Q90 50 88 100L88 114H42V100Q40 50 65 26Z" fill="${c}"/><path d="M65 26Q74 36 77 48H53Q56 36 65 26Z" fill="#2a2f4a"/><path d="M48 100Q46 56 62 34Q50 60 54 110Z" fill="#fff" opacity=".25"/><path d="M62 112L65 128L68 112Z" fill="${d}"/><rect x="42" y="104" width="46" height="8" rx="3" fill="${d}"/>${win(65,78,15,15)}`;
 }else if(id=='s3'){/* مروحية */
  b=`<ellipse class="rot" cx="65" cy="62" rx="58" ry="4" fill="#666"/><rect x="63" y="62" width="4" height="16" fill="#444"/><ellipse cx="65" cy="94" rx="38" ry="24" fill="${c}"/><ellipse cx="55" cy="84" rx="22" ry="8" fill="#fff" opacity=".2"/><rect x="96" y="88" width="28" height="9" rx="4" fill="${d}"/><ellipse class="rot" cx="122" cy="92" rx="3" ry="12" fill="#555"/>${win(50,90,18,14)}<path d="M26 120H104 M44 114V120 M86 114V120" stroke="${d}" stroke-width="4" fill="none"/><circle class="fl" cx="124" cy="100" r="3" fill="#cfd6e6" opacity=".7"/>`;
 }else if(id=='s4'){/* أجنحة مضيئة */
  b=fl(65,112,10,40,'#ff4fd8','#fff')+`<path d="M50 72Q8 42 4 100Q30 96 50 106Z M80 72Q122 42 126 100Q100 96 80 106Z" fill="${l}" opacity=".35"/><path d="M50 74Q14 52 10 96Q32 92 50 102Z M80 74Q116 52 120 96Q98 92 80 102Z" fill="${c}" opacity=".6"/><path d="M50 74Q14 52 10 96M80 74Q116 52 120 96" stroke="#fff" stroke-width="2" fill="none" opacity=".85"/><path d="M24 70L28 78L36 80L28 84L24 92L20 84L12 80L20 78Z M108 70L112 78L120 80L112 84L108 92L104 84L96 80L104 78Z" fill="#fff" opacity=".9"/><path d="M65 38Q92 60 88 108H42Q38 60 65 38Z" fill="${c}"/><path d="M46 104Q44 66 62 44Q52 70 56 106Z" fill="#fff" opacity=".25"/><rect x="44" y="104" width="42" height="8" rx="4" fill="${d}"/>${win(65,82,15,15)}`;
 }else if(id=='s5'){/* نفاثة دلتا */
  b=fl(65,114,8,52,'#4cc9f0','#fff')+`<path d="M65 44L85 82L128 104V112L80 104L72 116H58L50 104L2 112V104L45 82Z" fill="${c}"/><path d="M65 44L72 82H58Z" fill="${l}"/><path d="M85 82L128 104V108L82 92Z M45 82L2 104V108L48 92Z" fill="${d}" opacity=".5"/><path d="M96 98L120 106M34 98L10 106" stroke="#fff" stroke-width="2" opacity=".6"/>${win(65,84,13,15)}`;
 }else if(id=='s6'){/* يخت فضائي */
  b=fl(34,116,7,24,'#7ff5e0','#fff')+fl(96,116,7,24,'#7ff5e0','#fff')+`<path d="M65 14V58" stroke="#ddd" stroke-width="2.5"/><path d="M65 14L86 22L65 30Z" fill="#ff4d6d"/><path d="M6 92Q14 124 65 124Q116 124 124 92Z" fill="${c}"/><path d="M6 92H124L120 100H10Z" fill="#fff" opacity=".9"/><path d="M16 108Q65 118 114 108" stroke="${d}" stroke-width="3" fill="none"/><path d="M110 92L128 76L124 96Z" fill="${d}"/><path d="M20 92L2 76L6 96Z" fill="${d}"/><path d="M44 92Q44 58 65 58Q86 58 86 92Z" fill="${l}"/>${win(65,78,19,16)}`+[22,40,90,108].map(x=>`<circle cx="${x}" cy="110" r="3" fill="#ffe066"/>`).join('');
 }else{/* مركبة حربية */
  b=fl(65,112,12,40,'#ff3b1f','#ffd166')+fl(40,112,6,22,'#ff3b1f','#ffd166')+fl(90,112,6,22,'#ff3b1f','#ffd166')+`<rect x="10" y="58" width="12" height="46" rx="3" fill="${dd}"/><rect x="108" y="58" width="12" height="46" rx="3" fill="${dd}"/><rect x="12" y="50" width="8" height="14" rx="2" fill="#444"/><rect x="110" y="50" width="8" height="14" rx="2" fill="#444"/><rect x="22" y="78" width="12" height="8" fill="${d}"/><rect x="96" y="78" width="12" height="8" fill="${d}"/><path d="M65 30L94 66L102 112H28L36 66Z" fill="${c}"/><path d="M65 30L94 66H36Z" fill="${d}"/><path d="M40 104L44 70L58 50Q50 78 52 108Z" fill="#fff" opacity=".2"/><path d="M34 100H96M36 90H94" stroke="${dd}" stroke-width="2" opacity=".5"/><rect x="28" y="106" width="74" height="8" rx="3" fill="${dd}"/><path d="M58 38L65 28L72 38Z" fill="#ff3b1f"/>${win(65,78,14,14)}`;
 }
 return `<svg class="shipsvg" viewBox="0 0 130 140" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${u}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e8fbff"/><stop offset=".5" stop-color="#8fd8f5"/><stop offset="1" stop-color="#3b8fc4"/></linearGradient></defs>${b}</svg>`}

function petSvg(id,cls){const u='p'+(++UID);
 const C={f1:'#e9a14b',f2:'#d9a45e',f3:'#efe9e2',f4:'#f6f6f4',f5:'#e8742a',f6:'#6dbb3f',f7:'#dfa24a',f8:'#7a4e30'}[id]||'#e9a14b';
 const L=shade(C,.38),D=shade(C,-.34),DD=shade(C,-.55);
 const defs=`<defs><linearGradient id="${u}a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${L}"/><stop offset=".5" stop-color="${C}"/><stop offset="1" stop-color="${D}"/></linearGradient><radialGradient id="${u}h" cx=".38" cy=".3" r=".85"><stop offset="0" stop-color="${shade(C,.5)}"/><stop offset=".55" stop-color="${C}"/><stop offset="1" stop-color="${D}"/></radialGradient><radialGradient id="${u}e" cx=".4" cy=".3" r=".85"><stop offset="0" stop-color="#c98a3c"/><stop offset=".6" stop-color="#4a2a0e"/><stop offset="1" stop-color="#150a02"/></radialGradient></defs>`;
 const A=`url(#${u}a)`,H=`url(#${u}h)`;
 const eye=(x,y,r=2.6,ir,slit)=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*1.1}" fill="${ir||`url(#${u}e)`}"/><ellipse cx="${x}" cy="${y}" rx="${slit?r*.22:r*.5}" ry="${slit?r*.95:r*.62}" fill="#080402"/><circle cx="${x+r*.38}" cy="${y-r*.42}" r="${r*.34}" fill="#fff"/>`;
 const fur=(cx,cy,rx,ry,c,n,o=.35)=>{let s='';for(let i=0;i<n;i++){const a=i*2.399,r=Math.sqrt((i+.5)/n),x=cx+Math.cos(a)*r*rx*.92,y=cy+Math.sin(a)*r*ry*.92;s+=`M${x.toFixed(1)} ${y.toFixed(1)}q1.2 1.6 -.4 3.6`}return `<path d="${s}" stroke="${c}" stroke-width=".8" fill="none" stroke-linecap="round" opacity="${(o*.5).toFixed(2)}"/>`};
 const wh=(x,y,d)=>`<path d="M${x} ${y}q${d*7} -2 ${d*14} -4M${x} ${y+2.5}q${d*7} 0 ${d*14} 1M${x} ${y+5}q${d*7} 2 ${d*13} 5" stroke="#fff" stroke-opacity=".9" stroke-width=".7" fill="none" stroke-linecap="round"/>`;
 const leg=(x,y,w,h,c,pc)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${w/2.2}" fill="${c||A}"/><ellipse cx="${x+w/2-1}" cy="${y+h}" rx="${w*.78}" ry="${w*.42}" fill="${pc||c||C}"/>`;
 const sh=`<ellipse cx="52" cy="74" rx="40" ry="3.2" fill="#000" opacity=".22"/>`;
 const nose=(x,y,c,w=3)=>`<path d="M${x-w} ${y}Q${x} ${y-w*.8} ${x+w} ${y}Q${x+w*.6} ${y+w*1.3} ${x} ${y+w*1.5}Q${x-w*.6} ${y+w*1.3} ${x-w} ${y}Z" fill="${c}"/><ellipse cx="${x-.6}" cy="${y-.5}" rx="${w*.5}" ry="${w*.25}" fill="#fff" opacity=".55"/>`;
 let s='';
 if(id=='f1'){/* قطة */
  s=`<path d="M80 58Q99 58 96 36Q95 28 89 31" stroke="${D}" stroke-width="7.5" fill="none" stroke-linecap="round"/><path d="M80 58Q99 58 96 36Q95 28 89 31" stroke="${C}" stroke-width="5.5" fill="none" stroke-linecap="round"/><path d="M92 54Q97 50 96.5 44M93 40Q95 36 94 33" stroke="${DD}" stroke-width="2.4" fill="none" opacity=".55" stroke-linecap="round"/>`+
  leg(64,58,9,15,D)+`<ellipse cx="68" cy="56" rx="11" ry="13" fill="${A}"/>`+
  `<ellipse cx="55" cy="51" rx="26" ry="15.5" fill="${A}"/><ellipse cx="52" cy="60" rx="18" ry="6" fill="#fff4e4" opacity=".55"/><path d="M44 38Q46 46 44 52M54 36Q56 45 54 51M64 37Q66 44 64 50" stroke="${DD}" stroke-width="2.3" fill="none" stroke-linecap="round" opacity=".5"/>${fur(55,50,24,13,DD,40)}`+
  leg(36,56,8,17)+leg(45,57,8,16,D)+
  `<path d="M16 32L15 12L28 24Z M40 30L43 12L30 24Z" fill="${C}"/><path d="M18 27L18 17L24 23Z M38 26L40 17L33 23Z" fill="#ffb3c6"/><ellipse cx="28" cy="40" rx="15" ry="13.5" fill="${H}"/><path d="M28 27V33M23 28L24.5 33.5M33 28L31.5 33.5" stroke="${DD}" stroke-width="1.8" stroke-linecap="round" opacity=".6"/><ellipse cx="24" cy="46" rx="5.5" ry="4" fill="#fff4e4"/><ellipse cx="32" cy="46" rx="5.5" ry="4" fill="#fff4e4"/>${eye(22,38,3.1,'#9ad14b',1)}${eye(34,38,3.1,'#9ad14b',1)}${nose(28,43,'#e2607f',2.1)}<path d="M28 45.4V47.5Q25.5 50 23.5 48M28 47.5Q30.5 50 32.5 48" stroke="#4a2a2a" stroke-width="1" fill="none" stroke-linecap="round"/>${wh(15,45,-1)}${wh(41,45,1)}`;
 }else if(id=='f2'){/* كلب */
  s=`<path d="M82 52Q95 46 94 34" stroke="${D}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M82 52Q95 46 94 34" stroke="${C}" stroke-width="5" fill="none" stroke-linecap="round"/>`+
  leg(66,58,10,15,D)+`<ellipse cx="70" cy="56" rx="12" ry="13" fill="${A}"/>`+
  `<ellipse cx="57" cy="50" rx="27" ry="16" fill="${A}"/><ellipse cx="54" cy="60" rx="18" ry="5.5" fill="#fff0d6" opacity=".5"/>${fur(57,50,25,14,DD,46)}`+
  leg(36,55,9,18)+leg(46,57,9,16,D)+
  `<path d="M33 26Q47 27 45 47Q38 46 32 36Z" fill="${D}"/><path d="M35 29Q42 30 42 40" stroke="${DD}" stroke-width="1" fill="none" opacity=".4"/><ellipse cx="25" cy="38" rx="14" ry="13" fill="${H}"/><path d="M13 28Q15 22 20 24Q18 31 15 36Z" fill="${D}"/><ellipse cx="15" cy="44" rx="10" ry="7" fill="${L}"/><ellipse cx="15" cy="44" rx="10" ry="7" fill="#fff0d6" opacity=".55"/>${eye(22,35,2.7)}${eye(31,35,2.7)}<path d="M18 31Q21 29.5 24 31M28 31Q31 29.5 34 31" stroke="${DD}" stroke-width="1.2" fill="none" stroke-linecap="round" opacity=".7"/><ellipse cx="7.5" cy="41.5" rx="3.6" ry="2.8" fill="#1d1613"/><ellipse cx="6.5" cy="40.6" rx="1.3" ry=".8" fill="#fff" opacity=".6"/><path d="M8 44.5V47Q12 51 16 48M16 48Q19 50 21 46" stroke="#3a2222" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M12 48.5Q14 55 17 49Z" fill="#ff7a90"/>`;
 }else if(id=='f3'){/* أرنب */
  s=`<circle cx="83" cy="58" r="7" fill="#fff"/><circle cx="83" cy="58" r="7" fill="${C}" opacity=".35"/>${fur(83,58,6,6,'#cfc5bb',10,.6)}`+
  `<ellipse cx="56" cy="54" rx="24" ry="17" fill="${A}"/><ellipse cx="68" cy="58" rx="14" ry="14" fill="${A}"/><path d="M60 66Q72 72 82 66" stroke="${D}" stroke-width="1.2" fill="none" opacity=".5"/><ellipse cx="72" cy="71" rx="11" ry="3.8" fill="${C}"/>${fur(60,54,22,14,'#bfb4a8',44,.5)}`+
  `<ellipse cx="41" cy="68" rx="7" ry="4" fill="${C}"/><rect x="36" y="56" width="8" height="13" rx="4" fill="${A}"/><ellipse cx="40" cy="70" rx="6.5" ry="3.2" fill="${C}"/>`+
  `<ellipse cx="22" cy="17" rx="5" ry="15" transform="rotate(-10 22 17)" fill="${A}" stroke="#d8cdc3" stroke-width=".7"/><ellipse cx="22" cy="18" rx="2.4" ry="11" transform="rotate(-10 22 18)" fill="#ffb3c6"/><ellipse cx="35" cy="16" rx="5" ry="15" transform="rotate(13 35 16)" fill="${A}" stroke="#d8cdc3" stroke-width=".7"/><ellipse cx="35" cy="17" rx="2.4" ry="11" transform="rotate(13 35 17)" fill="#ffb3c6"/><ellipse cx="28" cy="43" rx="14" ry="13" fill="${H}" stroke="#d8cdc3" stroke-width=".7"/><ellipse cx="28" cy="49" rx="8" ry="6" fill="#fff"/>${eye(22,41,2.9)}${eye(34,41,2.9)}${nose(28,46,'#ff8fb0',2)}<path d="M28 48V50Q26 52.5 24.5 51M28 50Q30 52.5 31.5 51" stroke="#4a2a2a" stroke-width="1" fill="none" stroke-linecap="round"/><rect x="26.6" y="50.4" width="1.7" height="3.4" rx=".8" fill="#fff" stroke="#d5c5ba" stroke-width=".5"/><rect x="28.4" y="50.4" width="1.7" height="3.4" rx=".8" fill="#fff" stroke="#d5c5ba" stroke-width=".5"/><circle cx="18" cy="47" r="3" fill="#ff8fa6" opacity=".3"/><circle cx="38" cy="47" r="3" fill="#ff8fa6" opacity=".3"/>${wh(15,47,-1)}${wh(41,47,1)}`;
 }else if(id=='f4'){/* باندا */
  s=leg(64,56,12,17,'#1d1d1d')+`<circle cx="84" cy="56" r="4" fill="#fff" stroke="#d6d6d6" stroke-width=".6"/>`+
  `<ellipse cx="58" cy="51" rx="27" ry="18" fill="${A}" stroke="#d6d6d6" stroke-width=".7"/>${fur(58,52,24,15,'#c9c9c9',40,.5)}<path d="M36 36Q44 34 46 50Q46 62 40 66L33 64Q31 48 36 36Z" fill="#1d1d1d"/>`+
  leg(35,55,11,18,'#1d1d1d')+leg(47,57,10,16,'#242424')+
  `<circle cx="14" cy="22" r="6.5" fill="#1d1d1d"/><circle cx="40" cy="22" r="6.5" fill="#1d1d1d"/><circle cx="14" cy="20.5" r="2.4" fill="#fff" opacity=".12"/><ellipse cx="27" cy="36" rx="16" ry="14.5" fill="${A}" stroke="#d6d6d6" stroke-width=".7"/><ellipse cx="20.5" cy="35" rx="4.6" ry="6" transform="rotate(24 20.5 35)" fill="#1b1b1b"/><ellipse cx="33.5" cy="35" rx="4.6" ry="6" transform="rotate(-24 33.5 35)" fill="#1b1b1b"/><circle cx="21" cy="35" r="2.1" fill="#fff"/><circle cx="33" cy="35" r="2.1" fill="#fff"/><circle cx="21" cy="35.2" r="1.3" fill="#050505"/><circle cx="33" cy="35.2" r="1.3" fill="#050505"/><circle cx="21.5" cy="34.4" r=".5" fill="#fff"/><circle cx="33.5" cy="34.4" r=".5" fill="#fff"/><ellipse cx="27" cy="43.5" rx="6.5" ry="4.8" fill="#ece6df"/>${nose(27,40.6,'#1b1b1b',2.3)}<path d="M27 43V45Q24.6 47.5 22.6 46M27 45Q29.4 47.5 31.4 46" stroke="#333" stroke-width="1" fill="none" stroke-linecap="round"/>`;
 }else if(id=='f5'){/* ثعلب */
  s=`<path d="M78 56Q100 46 98 66Q95 76 80 69Z" fill="${A}"/><path d="M92 56Q100 56 98 66Q96 72 90 71Q95 65 92 56Z" fill="#fff6ec"/>${fur(88,62,9,8,DD,16,.4)}`+
  leg(66,59,8,14,'#2a1a12')+`<ellipse cx="68" cy="56" rx="11" ry="12" fill="${A}"/>`+
  `<ellipse cx="55" cy="51" rx="25" ry="14.5" fill="${A}"/><path d="M33 52Q44 66 62 63Q50 70 36 62Z" fill="#fff6ec"/>${fur(55,50,23,12,DD,36,.4)}`+
  leg(36,56,7,17,'#2a1a12')+leg(45,57,7,16,'#2a1a12')+
  `<path d="M14 33L12 8L29 24Z M42 31L44 8L27 24Z" fill="${C}"/><path d="M12 8L13.2 16L19 12Z M44 8L42.8 16L37 12Z" fill="#2a1a12"/><path d="M16 29L15.5 17L23 24Z M40 27L40.5 17L33 24Z" fill="#f6c9a0"/><ellipse cx="28" cy="38" rx="15" ry="13" fill="${H}"/><ellipse cx="19.5" cy="46" rx="7.5" ry="5" fill="#fff6ec"/><ellipse cx="36.5" cy="46" rx="7.5" ry="5" fill="#fff6ec"/><ellipse cx="28" cy="45.5" rx="5" ry="4" fill="#fff6ec"/>${eye(21,35,2.8,'#e7a627',1)}${eye(35,35,2.8,'#e7a627',1)}<path d="M16 31L19.5 33M40 31L36.5 33" stroke="#2a1a12" stroke-width="1.3" stroke-linecap="round"/>${nose(28,42,'#1e1e1e',2.3)}<path d="M28 44.4V46.5Q25.5 49 23.5 47.5M28 46.5Q30.5 49 32.5 47.5" stroke="#3a2a2a" stroke-width="1" fill="none" stroke-linecap="round"/>${wh(14,44,-1)}${wh(42,44,1)}`;
 }else if(id=='f6'){/* ضفدع */
  s=`<ellipse cx="52" cy="58" rx="31" ry="15" fill="${A}"/>${fur(52,57,28,12,DD,30,.35)}<circle cx="46" cy="52" r="2" fill="${DD}" opacity=".45"/><circle cx="58" cy="50" r="2.4" fill="${DD}" opacity=".45"/><circle cx="66" cy="55" r="1.8" fill="${DD}" opacity=".45"/><ellipse cx="40" cy="67" rx="16" ry="5" fill="#d3f0b4" opacity=".8"/>`+
  `<path d="M60 56Q82 40 88 62L94 70L84 72L80 68Q66 74 56 68Z" fill="${A}"/><path d="M88 66L98 72M84 69L96 75M80 70L90 76" stroke="${D}" stroke-width="2.4" stroke-linecap="round"/><path d="M62 54Q76 46 82 58" stroke="${DD}" stroke-width="1" fill="none" opacity=".4"/>`+
  `<path d="M34 62L30 72L24 73M34 64L33 73L29 75M37 64L38 73L34 75" stroke="${C}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`+
  `<ellipse cx="29" cy="50" rx="20" ry="13" fill="${H}"/><circle cx="19" cy="37" r="8" fill="${A}"/><circle cx="38" cy="37" r="8" fill="${A}"/><circle cx="19" cy="36" r="5.6" fill="#fff"/><circle cx="38" cy="36" r="5.6" fill="#fff"/><circle cx="19.5" cy="36.4" r="3.6" fill="#e7c93a"/><circle cx="37.5" cy="36.4" r="3.6" fill="#e7c93a"/><ellipse cx="19.5" cy="36.4" rx="2.3" ry="1.4" fill="#0a0a0a"/><ellipse cx="37.5" cy="36.4" rx="2.3" ry="1.4" fill="#0a0a0a"/><circle cx="20.5" cy="34.8" r="1" fill="#fff"/><circle cx="38.5" cy="34.8" r="1" fill="#fff"/><circle cx="26" cy="46" r=".9" fill="#2b6a1a"/><circle cx="31" cy="46" r=".9" fill="#2b6a1a"/><path d="M12 53Q29 62 46 53" stroke="#2b6a1a" stroke-width="1.8" fill="none" stroke-linecap="round"/><circle cx="14" cy="52" r="2.6" fill="#ff8fa6" opacity=".35"/><circle cx="44" cy="52" r="2.6" fill="#ff8fa6" opacity=".35"/>`;
 }else if(id=='f7'){/* أسد */
  const mn=shade(C,-.5),m2=shade(C,-.3);
  s=`<path d="M82 52Q96 50 94 36" stroke="${D}" stroke-width="5" fill="none" stroke-linecap="round"/><ellipse cx="94" cy="33" rx="4.5" ry="6.5" fill="${mn}"/>`+
  leg(66,58,10,15,D)+`<ellipse cx="70" cy="56" rx="12" ry="13" fill="${A}"/>`+
  `<ellipse cx="58" cy="51" rx="27" ry="16" fill="${A}"/><ellipse cx="55" cy="60" rx="18" ry="5" fill="#fff0cf" opacity=".4"/>${fur(58,51,25,14,DD,44,.35)}`+
  leg(38,56,9,17)+leg(48,57,9,16,D)+
  `<circle cx="28" cy="40" r="22" fill="${mn}"/><path d="M28 17Q35 24 42 18Q43 28 51 28Q46 34 50 41Q44 43 45 51Q38 48 35 57Q28 51 21 57Q18 48 11 51Q12 43 6 41Q10 34 5 28Q13 28 14 18Q21 24 28 17Z" fill="${m2}"/>${fur(28,40,19,19,mn,50,.6)}<circle cx="15" cy="26" r="5.5" fill="${C}"/><circle cx="41" cy="26" r="5.5" fill="${C}"/><circle cx="15" cy="26" r="2.8" fill="#f3b9a0"/><circle cx="41" cy="26" r="2.8" fill="#f3b9a0"/><ellipse cx="28" cy="41" rx="14" ry="13" fill="${H}"/><ellipse cx="28" cy="47" rx="8" ry="6" fill="#fff0cf"/>${eye(22,38,2.7,'#b9731d')}${eye(34,38,2.7,'#b9731d')}<path d="M18 33Q22 31 25 34M38 33Q34 31 31 34" stroke="${DD}" stroke-width="1.2" fill="none" stroke-linecap="round"/>${nose(28,43,'#6b3a24',2.5)}<path d="M28 45.5V48Q25.5 50.5 23.5 49M28 48Q30.5 50.5 32.5 49" stroke="#4a2a2a" stroke-width="1" fill="none" stroke-linecap="round"/>${wh(17,46,-1)}${wh(39,46,1)}`;
 }else if(id=='f8'){/* دب */
  s=`<circle cx="85" cy="50" r="4.5" fill="${D}"/>`+
  leg(65,57,12,16,D)+`<ellipse cx="69" cy="54" rx="13" ry="14" fill="${A}"/>`+
  `<ellipse cx="57" cy="48" rx="29" ry="19" fill="${A}"/><path d="M34 42Q40 28 56 31Q50 38 52 44Z" fill="${L}" opacity=".35"/>${fur(57,48,27,17,DD,56,.4)}`+
  leg(35,55,11,18)+leg(47,57,10,16,D)+
  `<circle cx="14" cy="24" r="7.5" fill="${A}"/><circle cx="40" cy="24" r="7.5" fill="${A}"/><circle cx="14" cy="24" r="4" fill="#d9a67a"/><circle cx="40" cy="24" r="4" fill="#d9a67a"/><ellipse cx="27" cy="38" rx="16.5" ry="15" fill="${H}"/>${fur(27,36,14,12,DD,24,.35)}<ellipse cx="27" cy="45" rx="9" ry="7" fill="#dcb98f"/>${eye(20,34,2.4)}${eye(34,34,2.4)}<path d="M16 30Q19.5 28.5 23 30M31 30Q34.5 28.5 38 30" stroke="${DD}" stroke-width="1.3" fill="none" stroke-linecap="round"/>${nose(27,41.4,'#1b1210',3)}<path d="M27 44.2V47Q24.4 49.6 22.4 48M27 47Q29.6 49.6 31.6 48" stroke="#3a2a2a" stroke-width="1.1" fill="none" stroke-linecap="round"/>`;
 }else s=`<ellipse cx="50" cy="52" rx="28" ry="18" fill="${A}"/>`;
 return `<svg class="${cls||'pet'}" data-pid="${id}" viewBox="0 0 100 80" xmlns="http://www.w3.org/2000/svg">${defs}${sh}${s}</svg>`}

function monsterSvg(k){const c=['#7b2cbf','#d00000','#2a9d8f','#f77f00','#3a86ff','#e5383b'][k%6],d=shade(c,-.35),l=shade(c,.4),id='mg'+(k%6)+'_'+(++UID);
 return `<svg class="mon" viewBox="0 0 200 190" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="${id}" cx=".38" cy=".3" r=".85"><stop offset="0" stop-color="${l}"/><stop offset=".6" stop-color="${c}"/><stop offset="1" stop-color="${d}"/></radialGradient><radialGradient id="${id}e" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#ffd66b"/><stop offset=".6" stop-color="#e5671b"/><stop offset="1" stop-color="#6b1d05"/></radialGradient><linearGradient id="${id}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6cf"/><stop offset="1" stop-color="#d6a92b"/></linearGradient></defs>
 <ellipse cx="100" cy="182" rx="62" ry="7" fill="#0005"/>
 <path d="M50 52L36 6L84 34Z M150 52L164 6L116 34Z" fill="url(#${id}h)" stroke="#b78d17" stroke-width="2"/>
 <path d="M46 44L40 16L62 32Z" fill="#fff" opacity=".35"/>
 <ellipse cx="22" cy="122" rx="16" ry="30" fill="url(#${id})" transform="rotate(20 22 122)"/><ellipse cx="178" cy="122" rx="16" ry="30" fill="url(#${id})" transform="rotate(-20 178 122)"/>
 <path d="M10 146l-6 8M22 150l-3 9M34 148l1 9M190 146l6 8M178 150l3 9M166 148l-1 9" stroke="#fff" stroke-width="4" stroke-linecap="round"/>
 <ellipse cx="100" cy="112" rx="78" ry="68" fill="url(#${id})"/><ellipse cx="100" cy="144" rx="44" ry="30" fill="${l}" opacity=".3"/>
 <g fill="${d}" opacity=".35"><circle cx="52" cy="140" r="8"/><circle cx="148" cy="136" r="10"/><circle cx="40" cy="116" r="5"/><circle cx="162" cy="108" r="6"/><circle cx="100" cy="60" r="5"/></g>
 <ellipse cx="74" cy="58" rx="26" ry="12" fill="#fff" opacity=".2" transform="rotate(-18 74 58)"/>
 <ellipse cx="72" cy="170" rx="22" ry="11" fill="${d}"/><ellipse cx="128" cy="170" rx="22" ry="11" fill="${d}"/>
 <circle cx="68" cy="92" r="21" fill="#fff"/><circle cx="132" cy="92" r="21" fill="#fff"/><circle cx="72" cy="96" r="12" fill="url(#${id}e)"/><circle cx="128" cy="96" r="12" fill="url(#${id}e)"/><circle cx="72" cy="96" r="5.5" fill="#12060a"/><circle cx="128" cy="96" r="5.5" fill="#12060a"/><circle cx="76" cy="91" r="3.8" fill="#fff"/><circle cx="132" cy="91" r="3.8" fill="#fff"/>
 <path d="M44 68L88 82M156 68L112 82" stroke="${d}" stroke-width="8" stroke-linecap="round"/>
 <path d="M58 130Q100 172 142 130Q100 142 58 130Z" fill="#3a0a1a"/><path d="M66 134L72 148L78 136M92 138L96 152L100 139M104 139L108 152L112 138M122 136L128 148L134 134" fill="#fff"/><path d="M82 150Q100 160 118 150Q100 146 82 150Z" fill="#e0445f"/></svg>`}

/* معاينة نمط السلاح في المتجر: نفس أشكال الطلقات في المعركة */
function wpSvg(id){const u='w'+(++UID),C={w0:'#4cc9f0',w1:'#ffe066',w2:'#7bd957',w3:'#c77dff',w4:'#ff9f1c',w5:'#ff4d6d'}[id]||'#4cc9f0';
 const star=(x,y)=>{let d='';for(let i=0;i<10;i++){const r=i%2?4:10,a=i*Math.PI/5;d+=(i?'L':'M')+(x+Math.sin(a)*r).toFixed(1)+' '+(y-Math.cos(a)*r).toFixed(1)}return `<path d="${d}Z" fill="${C}"/>`};
 const bolt=x=>`<path d="M${x+2} 54L${x-4} 45L${x+3} 41L${x-4} 32L${x+1} 25" stroke="${C}" stroke-width="3.5" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`;
 const spear=x=>`<path d="M${x} 14L${x+3.5} 32L${x} 58L${x-3.5} 32Z" fill="${C}"/><rect x="${x-1.2}" y="58" width="2.4" height="14" fill="${C}" opacity=".35"/>`;
 const miss=(x,y,r)=>`<g transform="translate(${x} ${y}) rotate(${r})"><ellipse rx="5" ry="13" fill="#e8ecf5"/><path d="M-5 6L-10 15L-3 11Z M5 6L10 15L3 11Z" fill="${C}"/><circle cy="-11" r="3" fill="${C}"/><ellipse cy="19" rx="3" ry="5" fill="#ffb703"/></g>`;
 let b='';
 if(id=='w0')b=`<ellipse cx="40" cy="40" rx="3.5" ry="10" fill="${C}"/>`;
 else if(id=='w1')b=bolt(31)+bolt(49);
 else if(id=='w2')b=star(22,46)+star(40,30)+star(58,46);
 else if(id=='w3')b=spear(26)+spear(35)+spear(45)+spear(54);
 else if(id=='w4')b=`<defs><radialGradient id="${u}g"><stop offset="0" stop-color="#fff6c0"/><stop offset=".45" stop-color="#ffb703"/><stop offset="1" stop-color="#ff3c00"/></radialGradient></defs><circle cx="40" cy="38" r="18" fill="url(#${u}g)"/><circle cx="40" cy="38" r="26" fill="none" stroke="${C}" stroke-width="2" opacity=".45"/>`;
 else b=miss(20,48,-22)+miss(40,32,0)+miss(60,48,22);
 return `<svg viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg" style="overflow:visible"><g style="filter:drop-shadow(0 0 4px ${C})">${b}</g></svg>`}
