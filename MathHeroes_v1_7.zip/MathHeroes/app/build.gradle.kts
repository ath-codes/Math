plugins { id("com.android.application") }
android {
    namespace = "com.mathheroes.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mathheroes.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "1.7"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
