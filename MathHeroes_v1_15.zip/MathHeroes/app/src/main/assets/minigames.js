/* ألعاب الاستراحة — المرحلة 11. يُحمَّل بعد fish.js. بادئة mg-.
   نظام الدورة: MGL قائمة الألعاب؛ بعد كل زعيم (كل ٣ كواكب) تفتح rest() اللعبة رقم (p.bw-1)%MGL.length.
   لإضافة لعبة جديدة (المراحل 12–13): عرّف دالة mgXxx(done) ثم أضف {id,n,e,d,f} إلى MGL.
   كل لعبة تستدعي done(score,miss) عند نهايتها فتُحسب المكافأة المتدرجة وتُعرض شاشة النهاية. */
const MGL=[];
const mgStars=(s,miss)=>Math.min(12,Math.floor(s/3)*3)+(s>=3&&!miss?2:0);
function rest(){SC='m';if(!MGL.length)return mini();const g=MGL[Math.max(0,(p.bw||1)-1)%MGL.length];
 show(`<h1>${g.e} استراحة!</h1>${mas('cheer')}<div class="card"><p><b>${g.n}</b></p><p>${g.d}</p></div><button class="big" onclick="mgStart(${MGL.indexOf(g)})">ابدأ اللعب ${g.e}</button><br><button class="alt" onclick="trip()">تخطّي ← الكوكب التالي 🚀</button>`)}
function mgStart(i){sfx('tap');MGL[i].f(mgEnd)}
function mgEnd(s,miss){clearInterval(IV[0]);const st=mgStars(s,miss);p.stars+=st;save();SC='m';sfx(st?'win':'bad');if(st)boom(10);
 show(`<h1>${st?'🎉 برافو!':'😊 حاول مرة أخرى!'}</h1>${mas(st?'cheer':'oops')}<div class="card"><p>نتيجتك: ${s}</p><p>${st?'مكافأتك '+st+' ⭐'+(!miss&&s>=3?' (بلا أخطاء! +٢)':''):'اقطع ٣ إجابات صحيحة لتأخذ نجوماً'}</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button>`)}

/* ===== قطّع الأرقام: أرقام تُقذف للأعلى؛ اسحب إصبعك عبر الرقم الذي هو الجواب الصحيح لتقطعه ===== */
function mgSlice(done){SC='m';
 show(`<div class="bxw full"><canvas id="cv"></canvas></div>`,0,'night',1);window.scrollTo(0,0);
 const cv=$('cv'),c=cv.getContext('2d'),W=360,H=Math.max(500,Math.min(820,Math.round(360*innerHeight/innerWidth)));cv.width=W;cv.height=H;
 const T=45,G=620,R0=30;let t=0,sc=0,miss=0,hp=3,nx=.3,since=0,fin=0,last=performance.now(),q=gen(p,1),flash=0,fc='#fff';
 const it2=[],hf=[],tr=[],pc=[];let lp=null;
 const burst=(x,y,cl,n)=>{for(let i=0;i<n;i++)pc.push({x,y,vx:R(-150,150),vy:R(-220,40),l:1,r:R(2,5),c:cl})};
 const wave=()=>{const n=R(1,3),vals=q.c.slice(),sl=[55,135,225,305].sort(()=>Math.random()-.5);
  for(let i=0;i<n;i++){let v=vals[R(0,vals.length-1)];if(i==0&&since>=2)v=q.a;if(v==q.a)since=-1;
   const x=sl[i]+R(-12,12);it2.push({x,y:H+R0,vx:(W/2-x)*R(15,45)/100,vy:-R(Math.sqrt(2*G*H*.62),Math.sqrt(2*G*H*.8)),v,r:R0,a:0,vr:R(-3,3)})}since++};
 const seg=(a,b)=>{for(let i=it2.length-1;i>=0;i--){const o=it2[i],dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy||1;let u=((o.x-a.x)*dx+(o.y-a.y)*dy)/l2;u=Math.max(0,Math.min(1,u));
   if(Math.hypot(a.x+u*dx-o.x,a.y+u*dy-o.y)<o.r+4){it2.splice(i,1);
    if(o.v==q.a){sc++;sfx('star');hv(15,80);burst(o.x,o.y,'#ffd23f',14);hf.push({x:o.x,y:o.y,vx:-80,vy:-120,a:o.a,v:o.v,l:1},{x:o.x,y:o.y,vx:80,vy:-120,a:o.a,v:o.v,l:1});flash=.4;fc='#5dff7a';q=gen(p,1);it2.length=0;since=0;nx=.5;break}
    else{hp--;miss++;sfx('bad');hpat([0,80,40,120]);burst(o.x,o.y,'#ff4d6d',10);flash=.4;fc='#ff4d6d'}}}};
 const pt=e=>{const r=cv.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*W,y:(e.clientY-r.top)/r.height*H}};
 cv.style.touchAction='none';cv.onpointerdown=e=>{lp=pt(e);tr.push({...lp,l:1})};
 cv.onpointermove=e=>{if(!e.buttons||!lp||fin)return;const n=pt(e);seg(lp,n);tr.push({...n,l:1});lp=n};cv.onpointerup=()=>{lp=null};
 const upd=dt=>{t+=dt;flash=Math.max(0,flash-dt);nx-=dt;if(nx<=0){wave();nx=1.1+Math.random()*.5}
  for(let i=it2.length-1;i>=0;i--){const o=it2[i];o.vy+=G*dt;o.x+=o.vx*dt;o.y+=o.vy*dt;o.a+=o.vr*dt;if(o.y>H+R0*2&&o.vy>0)it2.splice(i,1)}
  hf.forEach(h=>{h.vy+=G*dt;h.x+=h.vx*dt;h.y+=h.vy*dt;h.a+=dt*4;h.l-=dt*1.4});for(let i=hf.length-1;i>=0;i--)if(hf[i].l<=0)hf.splice(i,1);
  tr.forEach(p2=>p2.l-=dt*4);while(tr.length&&tr[0].l<=0)tr.shift();
  for(let i=pc.length-1;i>=0;i--){const q2=pc[i];q2.x+=q2.vx*dt;q2.y+=q2.vy*dt;q2.vy+=300*dt;q2.l-=dt*2;if(q2.l<=0)pc.splice(i,1)}};
 const ball=(x,y,r,v,a,al)=>{c.save();c.globalAlpha=al;c.translate(x,y);const g=c.createRadialGradient(-r*.3,-r*.3,2,0,0,r);g.addColorStop(0,'#9be7ff');g.addColorStop(1,'#4a5fe0');
  c.fillStyle=g;c.shadowColor='#7df9ff';c.shadowBlur=12;c.beginPath();c.arc(0,0,r,0,7);c.fill();c.shadowBlur=0;c.strokeStyle='#fff';c.lineWidth=3;c.stroke();
  c.rotate(a*.2);c.fillStyle='#fff';c.font='bold '+Math.round(r*.95)+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(v,0,2);c.restore()};
 const draw=()=>{c.clearRect(0,0,W,H);c.direction='ltr';
  const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'#2b1b6b');g.addColorStop(1,'#0b0a2c');c.fillStyle=g;c.fillRect(0,0,W,H);
  if(flash>0){c.fillStyle=fc;c.globalAlpha=flash*.35;c.fillRect(0,0,W,H);c.globalAlpha=1}
  it2.forEach(o=>ball(o.x,o.y,o.r,o.v,o.a,1));hf.forEach(h=>ball(h.x,h.y,R0*.8,h.v,h.a,Math.max(0,h.l)*.8));
  pc.forEach(q2=>{c.globalAlpha=Math.max(0,q2.l);c.fillStyle=q2.c;c.beginPath();c.arc(q2.x,q2.y,q2.r,0,7);c.fill()});c.globalAlpha=1;
  if(tr.length>1){c.lineCap='round';for(let i=1;i<tr.length;i++){c.strokeStyle='rgba(255,255,255,'+Math.max(0,tr[i].l)+')';c.lineWidth=2+6*tr[i].l;c.beginPath();c.moveTo(tr[i-1].x,tr[i-1].y);c.lineTo(tr[i].x,tr[i].y);c.stroke()}}
  c.fillStyle='rgba(10,10,40,.8)';c.fillRect(W/2-120,52,240,52);c.strokeStyle='#7df9ff';c.lineWidth=2;c.strokeRect(W/2-120,52,240,52);
  c.fillStyle='#aef';c.font='13px sans-serif';c.textAlign='center';c.fillText('قطّع الجواب الصحيح',W/2,67);c.fillStyle='#fff';c.font='bold 28px sans-serif';c.fillText(q.t,W/2,96);
  c.fillStyle='rgba(0,0,0,.5)';c.fillRect(20,114,W-40,8);c.fillStyle='#ffd23f';c.fillRect(20,114,(W-40)*Math.min(1,t/T),8);
  c.font='20px sans-serif';c.fillStyle='#fff';c.textAlign='right';c.fillText('❤'.repeat(Math.max(0,hp)),W-10,30);c.textAlign='left';c.fillText('✂ '+sc,10,30)};
 IV[0]=setInterval(()=>{if(fin)return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;upd(dt);draw();if(hp<=0||t>=T){fin=1;clearInterval(IV[0]);done(sc,miss)}},16)}
MGL.push({id:'slice',n:'قطّع الأرقام',e:'✂️',d:'تُقذف أرقام في الهواء. اسحب إصبعك عبر الرقم الذي هو جواب السؤال لتقطعه! احذر من الأرقام الخاطئة.',f:mgSlice});

/* ===== ذاكرة الحيوانات: اقلب البطاقات وطابق الأزواج؛ عند التطابق يُسمع صوت الحيوان. المرحلة 12 ===== */
function mgMemory(done){SC='m';
 const pairs=p.g==0?4:6,ids=['f1','f2','f3','f4','f5','f6','f7','f8'].sort(()=>Math.random()-.5).slice(0,pairs),cards=[...ids,...ids].sort(()=>Math.random()-.5);
 show(`<div class="bxw full mg-w"><div class="mg-top"><span>🧠 ذاكرة الحيوانات</span><span id="mgs">✔ 0/${pairs}</span></div><div class="mg-g" id="mgg" style="grid-template-columns:repeat(4,1fr)"></div><p id="mgm">اقلب بطاقتين متشابهتين 👆</p></div>`,0,'night',1);
 window.scrollTo(0,0);let open=[],found=0,miss=0,lock=0;const g=$('mgg');
 cards.forEach((id,i)=>{const b=document.createElement('div');b.className='mg-c';b.textContent='❓';
  b.onpointerdown=()=>{if(lock||b.classList.contains('on')||b.classList.contains('ok'))return;b.classList.add('on');b.textContent=(it(id)||[0,0,'🐾'])[2];sfx('tap');hv(8,40);open.push({b,id});
   if(open.length==2){lock=1;const[x,y]=open;open=[];
    if(x.id==y.id){found++;setTimeout(()=>{x.b.classList.add('ok');y.b.classList.add('ok');animal(x.id);sfx('star');$('mgs').textContent='✔ '+found+'/'+pairs;lock=0;
      if(found>=pairs)setTimeout(()=>done(found,miss>4),700)},350)}
    else{miss++;setTimeout(()=>{[x,y].forEach(o=>{o.b.classList.remove('on');o.b.textContent='❓'});lock=0},850)}}};
  g.appendChild(b)})}
MGL.push({id:'memory',n:'ذاكرة الحيوانات',e:'🧠',d:'اقلب بطاقتين في كل مرة وابحث عن الحيوانات المتشابهة. كلما تذكّرت أكثر أخطأت أقل!',f:mgMemory});

/* ===== اضرب الفضائي: ٣ فضائيين يطلّون من حفر ٣×٣ يحملون أرقاماً؛ اضرب حامل الجواب الصحيح. المرحلة 12 ===== */
function mgAlien(done){SC='m';
 show(`<div class="bxw full mg-w"><div class="mg-top"><span id="mgh">❤❤❤</span><b id="mgq"></b><span id="mgs">👾 0</span></div><div class="mg-bar"><i id="mgb" style="width:0"></i></div><div class="mg-g" id="mgg" style="grid-template-columns:repeat(3,1fr)"></div><p>اضرب الفضائي الذي يحمل الجواب الصحيح!</p></div>`,0,'night',1);
 window.scrollTo(0,0);const T=40,g=$('mgg'),holes=[];let q=gen(p,1),t=0,wt=.4,hp=3,sc=0,miss=0,fin=0,al=[];
 for(let i=0;i<9;i++){const h=document.createElement('div');h.className='mg-ho';g.appendChild(h);holes.push(h)}
 const hud=()=>{$('mgq').textContent=q.t;$('mgh').textContent='❤'.repeat(Math.max(0,hp));$('mgs').textContent='👾 '+sc;$('mgb').style.width=Math.min(100,t/T*100)+'%'};
 const clear=()=>{al.forEach(a=>a.remove());al=[]};
 const wave=()=>{clear();const hs=[0,1,2,3,4,5,6,7,8].sort(()=>Math.random()-.5).slice(0,3),vs=q.c.slice().sort(()=>Math.random()-.5);
  hs.forEach((hi,i)=>{const a=document.createElement('div'),v=vs[i];a.className='mg-a';a.innerHTML='<span>👾</span><b>'+v+'</b>';
   a.onpointerdown=()=>{if(fin||a.dead)return;a.dead=1;
    if(v==q.a){sc++;sfx('star');hv(15,80);p.ws=p.ws||{};p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);clear();q=gen(p,1);wt=.5}
    else{hp--;miss++;sfx('bad');hpat([0,80,40,120]);p.ws=p.ws||{};p.ws[q.o]=(p.ws[q.o]||0)+1;a.innerHTML='<span>💥</span>';setTimeout(()=>a.remove(),350)}hud()};
   holes[hi].appendChild(a);al.push(a)});wt=Math.max(1.3,2.2-sc*.04)};
 hud();
 IV[0]=setInterval(()=>{if(fin)return;t+=.1;wt-=.1;if(wt<=0)wave();hud();if(hp<=0||t>=T){fin=1;clearInterval(IV[0]);clear();save();done(sc,miss>0)}},100)}
MGL.push({id:'alien',n:'اضرب الفضائي',e:'👾',d:'فضائيون يطلّون من الحفر وكل واحد يحمل رقماً. اضرب من يحمل جواب السؤال، وانتبه من الخاطئين!',f:mgAlien});

/* ===== أطعِم رفيقك: رفيقك المختار جائع؛ ٣ أطعمة عليها أرقام، أطعمه الذي يحمل جواب السؤال. المرحلة 13 ===== */
function mgFeed(done){SC='m';
 const RN=9,id=p.eq.f||'f1',FD=['🍎','🍌','🍪','🥕','🍓','🍉'];let n=0,sc=0,miss=0,first=1,q,lock=0;
 show(`<div class="bxw full mg-w"><div class="mg-top"><span>🍽 أطعِم رفيقك</span><span id="mgs">0/${RN}</span></div><div class="mg-bar"><i id="mgb" style="width:0"></i></div><b class="mg-bub" id="mgq"></b><div class="mg-pet" id="mgp">${petSvg(id,'pet')}</div><div class="mg-fr" id="mgf"></div><p id="mgm">رفيقك جائع! أطعمه الجواب الصحيح 😋</p></div>`,0,'night',1);
 window.scrollTo(0,0);const fr=$('mgf'),msg=s=>{$('mgm').textContent=s};
 const hop=()=>{const e=$('mgp');e.classList.add('mg-hop');setTimeout(()=>e.classList.remove('mg-hop'),520)};
 const round=()=>{q=gen(p,1);lock=0;first=1;$('mgq').textContent=q.t;fr.innerHTML='';fr.children.length=0;
  const vs=q.c.slice().sort(()=>Math.random()-.5),fs=FD.slice().sort(()=>Math.random()-.5);
  vs.forEach((v,i)=>{const d=document.createElement('div');d.className='mg-fd';d.innerHTML='<span>'+fs[i]+'</span><b>'+v+'</b>';
   d.onpointerdown=()=>{if(lock)return;p.ws=p.ws||{};
    if(v==q.a){lock=1;if(first)sc++;n++;sfx('star');hv(15,80);animal(id);hop();msg('ممم لذيذ! 😋');p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);
     $('mgs').textContent=n+'/'+RN;$('mgb').style.width=(n/RN*100)+'%';save();
     if(n>=RN)setTimeout(()=>done(sc,miss>2),900);else setTimeout(round,750)}
    else{first=0;miss++;sfx('bad');hpat([0,60,40,80]);p.ws[q.o]=(p.ws[q.o]||0)+1;d.classList.add('bad');setTimeout(()=>d.classList.remove('bad'),320);msg('لا يا صديقي، هذا ليس طعامي 🙅 جرّب غيره')}};
   fr.appendChild(d)})};
 round()}
MGL.push({id:'feed',n:'أطعِم رفيقك',e:'🍎',d:'رفيقك جائع! حلّ المسألة وأطعمه الطعام الذي يحمل الجواب الصحيح.',f:mgFeed});

/* ===== فقاعات: ٦ فقاعات بأرقام تطفو؛ فرقعها بالترتيب من الأصغر (والجولة الأخيرة من الأكبر). المرحلة 13 ===== */
function mgBubbles(done){SC='m';
 const N=6,RD=3,T=70,mx=p.g==0?9:p.g==1?30:99;let rd=0,sc=0,miss=0,t=0,fin=0,bs=[],ord=[],ix=0,desc=0,lock=0;
 show(`<div class="bxw full mg-w"><div class="mg-top"><span id="mgh">الجولة 1/${RD}</span><b id="mgq"></b><span id="mgs">🫧 0</span></div><div class="mg-bar"><i id="mgb" style="width:0"></i></div><div class="mg-ar" id="mgar"></div></div>`,0,'night',1);
 window.scrollTo(0,0);const ar=$('mgar');
 const clear=()=>{bs.forEach(b=>b.el.remove());bs=[]};
 const start=()=>{clear();lock=0;ix=0;desc=p.g>0&&rd==RD-1?1:0;const s=new Set();while(s.size<N)s.add(R(1,mx));const ns=[...s];ord=ns.slice().sort((a,b)=>desc?b-a:a-b);
  $('mgq').textContent=desc?'من الأكبر ⬇':'من الأصغر ⬆';$('mgh').textContent='الجولة '+(rd+1)+'/'+RD;
  ns.forEach((v,i)=>{const el=document.createElement('div');el.className='mg-b';el.textContent=v;const b={el,v,x:15+(i%3)*35+R(-5,5),y:25+Math.floor(i/3)*45+R(-8,8),vy:R(40,70)/10,ph:Math.random()*6};
   el.onpointerdown=()=>{if(fin||lock||b.dead)return;
    if(v==ord[ix]){b.dead=1;sc++;ix++;sfx('star');hv(10,50);el.remove();bs=bs.filter(o=>o!==b);$('mgs').textContent='🫧 '+sc;
     if(ix>=N){lock=1;rd++;if(rd>=RD){fin=1;clearInterval(IV[0]);save();setTimeout(()=>done(sc,miss>3),500)}else setTimeout(start,700)}}
    else{miss++;sfx('bad');hpat([0,50,40,70]);el.classList.add('bad');setTimeout(()=>el.classList.remove('bad'),320)}};
   ar.appendChild(el);bs.push(b)})};
 const place=()=>bs.forEach(b=>{b.el.style.left=(b.x+Math.sin(b.ph)*3)+'%';b.el.style.top=b.y+'%'});
 start();place();
 IV[0]=setInterval(()=>{if(fin)return;t+=.05;$('mgb').style.width=Math.min(100,t/T*100)+'%';bs.forEach(b=>{b.y-=b.vy*.05;b.ph+=.05;if(b.y<-8)b.y=104});place();if(t>=T){fin=1;clearInterval(IV[0]);save();done(sc,miss>3)}},50)}
MGL.push({id:'bubbles',n:'فقاعات',e:'🫧',d:'فقاعات بأرقام تطفو في الهواء. فرقعها بالترتيب من الأصغر إلى الأكبر! والجولة الأخيرة من الأكبر إلى الأصغر.',f:mgBubbles});
