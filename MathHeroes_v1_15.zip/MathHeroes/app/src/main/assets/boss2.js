/* أنماط الزعيم الإضافية — سباق العوائق (Subway-style) على canvas. المراحل 7–8.
   يُحمَّل بعد game.js ويستعمل دوالّه العامة (show, sfx, hv, hpat, gen, animal, bwin, blose, B, p, IV...). */
function bossRun(){SC='b';
 const k=Math.max(1,Math.floor((p.planet-1)/3)),f=p.eq.f,iv=p.inv||{},mh=3+(f=='f3'?1:0)+(iv.hp?1:0),ivs=!!iv.sh;
 p.inv={hp:0,sh:0};save();B={k,f,x:0};sfx('tap');
 show(`<div class="bxw full"><canvas id="cv"></canvas><div class="bmsg" id="bm"></div><div class="bhud"><span></span>${f&&it(f)?`<button id="bp">${it(f)[2]}<small>مساعدة</small><i class="cdv" style="height:0"></i></button>`:'<span></span>'}</div></div>`,0,'night',1);
 window.scrollTo(0,0);
 const cv=$('cv'),c=cv.getContext('2d'),W=360,H=Math.max(500,Math.min(820,Math.round(360*innerHeight/innerWidth)));cv.width=W;cv.height=H;
 const img=(s,w,h)=>{const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s.replace('<svg ',`<svg width="${w}" height="${h}" `));return i};
 const shI=img(shipSvg(it(p.eq.s)||IT[0],{mood:'happy',h:p.eq.h}),130,140),mI=img(monsterSvg(k),200,190),peI=f&&it(f)?img(petSvg(f,'pet'),100,80):null;
 const LX=[W/6,W/2,W*5/6],MY=H-110,T=Math.min(70,40+6*k),SY=150,CAP=12;
 const me={x:LX[1],l:1,h:mh,inv:0,sh:f=='f4'||ivs,tilt:0},bs={x:W/2,y:66,t:0},ab={cd:0,max:15};
 let t=0,v=190+k*10,sc=0,nxt=380,got=0,hits=0,done=0,dy=0,dyt=0,shk=0,heal=0,last=performance.now();
 let jp=0,sl=0,air=0,boost=0,slowT=0,mag=0,gate=null,ng=8,fw=0,h1=0,b1=0,sw=0,px=0,py=0;
 const ob=[],st=[],pc=[],sf=Array.from({length:36},()=>({x:R(0,W),y:R(0,H),z:R(1,3)}));
 const msg=s=>{const m=$('bm');if(!m)return;m.textContent=s;m.style.opacity=1;clearTimeout(msg.t);msg.t=setTimeout(()=>{if(m)m.style.opacity=0},2200)};
 msg('اضغط على المسار الذي تريده 👆');
 const burst=(x,y,col,n)=>{for(let i=0;i<n;i++)pc.push({x,y,vx:R(-140,140),vy:R(-160,60),l:1,r:R(2,5),c:col})};
 const fin=ok=>{done=1;clearInterval(IV[0]);if(ok){B.x=got;bwin('run')}else blose(null,'run')};
 const die=()=>{dy=1;sfx('bossdie');hpat([0,120,40,160,40,220,40,320]);shk=.8;ob.length=0;st.length=0;gate=null;
  const cs=['#ffd23f','#ff6b35','#fff','#ff4d6d','#4cc9f0'];for(let i=0;i<46;i++)pc.push({x:bs.x,y:bs.y+55,vx:R(-240,240),vy:R(-300,120),l:1,r:R(3,8),c:cs[R(0,4)]})};
 const hurt=()=>{if(me.inv<=0){if(me.sh){me.sh=false;hv(60,120)}else{me.h--;hits++;hpat([0,90,40,140])}me.inv=1.4;sfx('bad');shk=.35}};
 const nearL=()=>Math.max(0,Math.min(2,Math.round((me.x-LX[0])/(LX[1]-LX[0]))));
 /* صف جديد: بوابة جواب كل ~١٢ث، حاجز قفز/انزلاق نادر (٢–٤ مرات)، وإلا صخور بمسار فارغ دائماً ونجوم */
 const spawn=()=>{
  if(t>=ng&&T-t>6&&!gate){const q=gen(p,2),w=q.c.filter(x=>x!=q.a).sort(()=>Math.random()-.5).slice(0,2);
   gate={q,vals:[q.a,...w].sort(()=>Math.random()-.5),y:SY,done:0};ng=t+R(11,14);nxt=330;return}
  if(t>10&&T-t>8&&fw<2+Math.min(2,k)&&Math.random()<.12){const hu=Math.random()<.5;fw++;ob.push({kind:hu?'h':'b',x:W/2,y:SY,s:0,a:0,vr:0});
   if(hu&&!h1){h1=1;msg('اسحب لأعلى للقفز ⬆')}else if(!hu&&!b1){b1=1;msg('اسحب لأسفل للانزلاق ⬇')}nxt=330;return}
  const ls=[0,1,2].sort(()=>Math.random()-.5),n=Math.random()<Math.min(.6,.15+k*.08)?2:1,bl=ls.slice(0,n),fr=ls.slice(n);
  bl.forEach(l=>ob.push({kind:'r',x:LX[l],y:SY,a:Math.random()*6,vr:(Math.random()-.5)*2.4,s:28+R(0,8)}));
  const sl2=fr[R(0,fr.length-1)];for(let i=0;i<3&&got+st.length<CAP;i++)st.push({x:LX[sl2],y:SY-55*i-30})};
 const sc2=y=>.45+.55*Math.max(0,Math.min(1,(y-SY)/(MY-SY)));
 const mv=e=>{if(done||dy)return;const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*W,l=Math.max(0,Math.min(2,Math.floor(x/(W/3))));if(l!=me.l){me.l=l;sfx('tap')}};
 const jump=()=>{if(done||dy||jp>0||air>0)return;jp=.75;sfx('tap');hv(10,60)};
 const slide=()=>{if(done||dy||sl>0)return;sl=.7;sfx('tap');hv(10,60)};
 cv.style.touchAction='none';cv.onpointerdown=e=>{px=e.clientX;py=e.clientY;sw=0;mv(e)};
 cv.onpointermove=e=>{if(!e.buttons||sw)return;const dx=e.clientX-px,d2=e.clientY-py;if(Math.abs(d2)>38&&Math.abs(d2)>Math.abs(dx)*1.3){sw=1;d2<0?jump():slide();return}mv(e)};
 if(f&&$('bp'))$('bp').onclick=()=>{if(ab.cd>0||done||dy)return;ab.cd=ab.max;sfx('pet');animal(f);let s='';
  if(f=='f1'){mag=6;s='🧲 النجوم تأتي إليك!'}
  else if(f=='f2'){slowT=5;s='👃 الوقت تباطأ!'}
  else if(f=='f3'){me.h=Math.min(mh,me.h+1);s='❤ قلب إضافي!'}
  else if(f=='f4'){me.sh=true;s='🛡 درع جاهز!'}
  else if(f=='f5'){me.inv=2.5;s='🐺 اختفاء مؤقت!'}
  else if(f=='f6'){air=1.6;s='🐸 قفزة عالية!'}
  else if(f=='f7'){me.h=mh;s='🦁 شفاء كامل!'}
  else if(f=='f8'){ob.forEach(o=>burst(o.kind=='r'?o.x:W/2,o.y,'#b9b2c9',8));ob.length=0;s='🐻 ضربة الدب! تحطّمت العوائق'}
  msg(s)};
 const upd=dt=>{t+=dt;boost=Math.max(0,boost-dt);slowT=Math.max(0,slowT-dt);mag=Math.max(0,mag-dt);jp=Math.max(0,jp-dt);sl=Math.max(0,sl-dt);air=Math.max(0,air-dt);
  ab.cd=Math.max(0,ab.cd-dt);me.inv=Math.max(0,me.inv-dt);shk=Math.max(0,shk-dt);
  v=Math.min(330,190+k*10+t*2.2);const vv=v*(boost>0?1.35:1)*(slowT>0?.6:1);sc+=vv*dt;
  me.x+=(LX[me.l]-me.x)*Math.min(1,dt*13);me.tilt=(LX[me.l]-me.x)/90*.5;
  bs.t+=dt;bs.x+=(me.x-bs.x)*Math.min(1,dt*1.6);bs.y=66+Math.min(42,hits*14)+Math.sin(bs.t*3)*4;
  if(f=='f7'){heal+=dt;if(heal>=15&&me.h<mh){me.h++;heal=0}}
  nxt-=vv*dt;if(nxt<=0&&T-t>2.6){spawn();if(nxt<=0)nxt=250-Math.min(60,k*6)+R(0,50)}
  sf.forEach(s=>{s.y+=vv*dt*.25*s.z;if(s.y>H){s.y=-5;s.x=R(0,W)}});
  for(let i=ob.length-1;i>=0;i--){const o=ob[i];o.y+=vv*dt;o.a+=o.vr*dt;
   if(Math.abs(o.y-MY)<(o.kind=='r'?44:26)&&(o.kind!='r'||(Math.abs(o.x-me.x)<40&&Math.abs(me.x-LX[me.l])<28))){
    const imm=air>0||(o.kind=='h'&&jp>0)||(o.kind=='b'&&sl>0);
    if(!imm){ob.splice(i,1);const bx=o.kind=='r'?o.x:me.x;burst(bx,o.y,'#b9b2c9',10);burst(bx,o.y,'#ff9f1c',6);hurt();continue}}
   if(o.y>H+50)ob.splice(i,1)}
  for(let i=st.length-1;i>=0;i--){const s=st[i];s.y+=vv*dt;if(mag>0)s.x+=(me.x-s.x)*Math.min(1,dt*6);
   if(Math.abs(s.x-me.x)<34&&Math.abs(s.y-MY)<44){st.splice(i,1);got++;sfx('star');hv(8,50);burst(s.x,s.y,'#ffd23f',6)}
   else if(s.y>H+30)st.splice(i,1)}
  if(gate){gate.y+=vv*dt;
   if(!gate.done&&gate.y>=MY-6){gate.done=1;const q=gate.q,ok=gate.vals[nearL()]==q.a;p.ws=p.ws||{};
    if(ok){got=Math.min(CAP,got+3);boost=1.2;sfx('ok');hv(25,120);burst(me.x,MY,'#ffd23f',14);msg('صحيح! 🚀 ⭐⭐⭐');p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1)}
    else{p.ws[q.o]=(p.ws[q.o]||0)+1;msg('الإجابة هي '+q.a+' 💡');hurt()}
    save()}
   if(gate&&gate.y>H+80)gate=null}
  for(let i=pc.length-1;i>=0;i--){const q=pc[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=300*dt;q.l-=dt*2.2;if(q.l<=0)pc.splice(i,1)}};
 const rr=(x,y,w,h,r)=>{c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()};
 const rock=(x,y,s,a,vr)=>{c.save();c.translate(x,y);c.rotate(a);const g=c.createRadialGradient(-s*.3,-s*.3,2,0,0,s*1.1);g.addColorStop(0,'#b9b2c9');g.addColorStop(.6,'#6f6788');g.addColorStop(1,'#3a3350');
  c.fillStyle=g;c.shadowColor='rgba(255,120,60,.55)';c.shadowBlur=12;c.beginPath();for(let i=0;i<9;i++){const an=i/9*6.2832,r=s*(.82+.18*Math.sin(i*2.7+vr*5));c.lineTo(Math.cos(an)*r,Math.sin(an)*r)}
  c.closePath();c.fill();c.shadowBlur=0;c.fillStyle='rgba(30,20,50,.35)';c.beginPath();c.arc(-s*.25,-s*.1,s*.2,0,7);c.fill();c.beginPath();c.arc(s*.28,s*.25,s*.14,0,7);c.fill();c.restore()};
 const bar=(y,hu,s)=>{const th=22*s;c.save();c.shadowColor=hu?'#ffd23f':'#ff4d6d';c.shadowBlur=14;
  if(hu){c.fillStyle='#ffd23f';c.fillRect(0,y-th/2,W,th);c.fillStyle='#2a1a12';for(let x=-20+(sc%40);x<W;x+=40){c.beginPath();c.moveTo(x,y-th/2);c.lineTo(x+20,y-th/2);c.lineTo(x+8,y+th/2);c.lineTo(x-12,y+th/2);c.closePath();c.fill()}}
  else{c.fillStyle='#ff4d6d';c.fillRect(0,y-th/2,W,th*.6);c.fillStyle='rgba(255,255,255,.7)';c.fillRect(0,y-th/2,W,3)}
  c.shadowBlur=0;c.font=(Math.round(18*s)+6)+'px sans-serif';c.textAlign='center';c.fillStyle='#fff';c.fillText(hu?'⬆':'⬇',W/2,y+8*s);c.restore()};
 const star=(x,y,r)=>{c.save();c.translate(x,y);c.shadowColor='#ffd23f';c.shadowBlur=10;c.fillStyle='#ffd23f';c.beginPath();for(let i=0;i<10;i++){const rr2=i%2?r*.45:r,a=i*Math.PI/5;c.lineTo(Math.sin(a)*rr2,-Math.cos(a)*rr2)}c.closePath();c.fill();c.restore()};
 const gt=()=>{if(!gate)return;const s=sc2(gate.y);c.save();c.globalAlpha=gate.done?.35:1;
  gate.vals.forEach((val,i)=>{const w=88*s,h=58*s,x=LX[i]-w/2,y=gate.y-h/2,g=c.createLinearGradient(0,y,0,y+h);g.addColorStop(0,'#4cc9f0');g.addColorStop(1,'#7b6cf0');
   c.shadowColor='#7df9ff';c.shadowBlur=16;c.fillStyle=g;rr(x,y,w,h,14*s);c.fill();c.shadowBlur=0;c.strokeStyle='#fff';c.lineWidth=3;c.stroke();
   c.fillStyle='#fff';c.font='bold '+Math.round(30*s)+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(val,LX[i],gate.y+1)});c.restore()};
 const draw=()=>{c.clearRect(0,0,W,H);c.direction='ltr';c.save();if(shk>0)c.translate(R(-5,5)*shk*3,R(-5,5)*shk*3);
  c.fillStyle='rgba(120,100,255,.10)';c.fillRect(0,0,W/3,H);c.fillRect(2*W/3,0,W/3,H);
  c.fillStyle='rgba(255,255,255,.55)';sf.forEach(s=>c.fillRect(s.x,s.y,1.5,s.z*(boost>0?9:4)));
  c.setLineDash([18,16]);c.lineDashOffset=-(sc%34);c.strokeStyle='rgba(180,170,255,.45)';c.lineWidth=2;
  [W/3,2*W/3].forEach(x=>{c.beginPath();c.moveTo(x,0);c.lineTo(x,H);c.stroke()});c.setLineDash([]);
  st.forEach(s=>star(s.x,s.y,12*sc2(s.y)));
  ob.forEach(o=>o.kind=='r'?rock(o.x,o.y,o.s*sc2(o.y),o.a,o.vr):bar(o.y,o.kind=='h',sc2(o.y)));gt();
  c.globalAlpha=dy?Math.max(0,1-dyt/.9):1;c.drawImage(mI,bs.x-56+(dy?Math.sin(dyt*60)*6:0),bs.y-10,112,106);c.globalAlpha=1;
  c.shadowBlur=0;pc.forEach(q=>{if(q.l<=0)return;c.globalAlpha=Math.max(0,q.l);c.fillStyle=q.c;c.beginPath();c.arc(q.x,q.y,q.r,0,7);c.fill()});c.globalAlpha=1;
  const up=air>0?28*Math.sin(Math.min(1,(1.6-air)/1.6)*Math.PI):jp>0?22*Math.sin(Math.min(1,(.75-jp)/.75)*Math.PI):0,ky=sl>0?.62:1,kz=up>0?1+up/90:1;
  if(up>0){c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(me.x,MY+30,22,7,0,0,7);c.fill()}
  if(me.inv<=0||Math.floor(me.inv*10)%2){c.save();c.translate(me.x,MY-up+(sl>0?10:0));c.rotate(me.tilt);c.scale(kz,kz*ky);c.drawImage(shI,-30,-32,60,64);c.restore()}
  if(me.sh){c.strokeStyle='#7df9ff';c.lineWidth=3;c.beginPath();c.arc(me.x,MY-up,36,0,7);c.stroke()}
  if(peI)c.drawImage(peI,Math.max(4,Math.min(W-54,me.x+22)),MY-2,50,40);
  c.fillStyle='rgba(0,0,0,.5)';c.fillRect(20,44,W-40,12);c.fillStyle='#7df9ff';c.fillRect(20,44,(W-40)*Math.min(1,t/T),12);
  c.font='20px sans-serif';c.fillStyle='#fff';c.textAlign='right';c.fillText('❤'.repeat(Math.max(0,me.h)),W-10,30);c.textAlign='left';c.fillText('⭐ '+got,10,30);
  if(gate&&!gate.done){c.fillStyle='rgba(10,10,40,.8)';rr(W/2-110,62,220,42,16);c.fill();c.strokeStyle='#7df9ff';c.lineWidth=2;c.stroke();
   c.fillStyle='#fff';c.font='bold 28px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(gate.q.t,W/2,84);c.textBaseline='alphabetic'}
  const cd=$('bp');if(cd)cd.querySelector('.cdv').style.height=(ab.cd/ab.max*100)+'%';
  c.restore()};
 IV[0]=setInterval(()=>{if(done)return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
  if(!dy)upd(dt);else{dyt+=dt;pc.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=420*dt;q.l-=dt*.9});if(dyt>1.3){draw();return fin(1)}}
  draw();if(!dy){if(me.h<=0)fin(0);else if(t>=T)die()}},16)}
