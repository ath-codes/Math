/* ===== المؤثرات: صوت واقعي (WebAudio بلا ملفات) + أصوات الحيوانات + إعدادات + برق متفرّع =====
   يُحمَّل قبل game.js؛ يعتمد وقت التشغيل على: S, AC, au(), WXK, rr, R, $ , hv, sfx من game.js */
const fxOn=()=>!!S.m&&S.fx!==0, muOn=()=>!!S.m&&S.mu!==0;
let NBF=null,AMB=null;
function nbuf(){const c=AC;if(NBF&&NBF.sampleRate==c.sampleRate)return NBF;const n=(c.sampleRate*2)|0,b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;return NBF=b}

/* ضوضاء مفلترة متواصلة (للمطر والريح) */
function nz(ty,f,q,v,A){const c=AC,s=c.createBufferSource();s.buffer=nbuf();s.loop=true;const fl=c.createBiquadFilter();fl.type=ty;fl.frequency.value=f;fl.Q.value=q;const g=c.createGain();g.gain.value=v;s.connect(fl);fl.connect(g);g.connect(A.g);s.start(c.currentTime,Math.random()*1.5);A.n.push(s);return{fl,g}}
function lfo(hz,depth,param,A,ty){const c=AC,o=c.createOscillator(),g=c.createGain();o.type=ty||'sine';o.frequency.value=hz;g.gain.value=depth;o.connect(g);g.connect(param);o.start();A.n.push(o);return o}
/* نغمة قصيرة: pts=[[زمن,تردد],...]، bp=[تردد,Q]، am=[هرتز,عمق] */
function vo(o){const c=au();if(!c)return;const t=c.currentTime+(o.t||0),os=c.createOscillator(),g=c.createGain();os.type=o.ty||'sine';
 o.pts.forEach((p,i)=>{if(i)os.frequency.linearRampToValueAtTime(p[1],t+p[0]);else os.frequency.setValueAtTime(p[1],t)});
 let n=os;if(o.bp){const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=o.bp[0];f.Q.value=o.bp[1];n.connect(f);n=f}
 if(o.am){const m=c.createGain();m.gain.value=1-o.am[1];const l=c.createOscillator(),lg=c.createGain();l.frequency.value=o.am[0];lg.gain.value=o.am[1];l.connect(lg);lg.connect(m.gain);l.start(t);l.stop(t+o.d+.05);n.connect(m);n=m}
 const v=o.v||.1,a=o.a||.02;g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(v,t+a);g.gain.setValueAtTime(v,t+Math.max(a,o.d*.6));g.gain.linearRampToValueAtTime(0,t+o.d);
 n.connect(g);g.connect(o.out||c.destination);os.start(t);os.stop(t+o.d+.05)}
/* دفعة ضوضاء قصيرة */
function nb(o){const c=au();if(!c)return;const t=c.currentTime+(o.t||0),s=c.createBufferSource();s.buffer=nbuf();const f=c.createBiquadFilter();f.type=o.ty||'bandpass';f.frequency.setValueAtTime(o.f,t);if(o.f2)f.frequency.exponentialRampToValueAtTime(o.f2,t+o.d);f.Q.value=o.q||1;
 const g=c.createGain(),v=o.v||.1;g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(v,t+(o.a||.01));g.gain.exponentialRampToValueAtTime(0.0001,t+o.d);s.connect(f);f.connect(g);g.connect(o.out||c.destination);s.start(t,Math.random()*1.5);s.stop(t+o.d+.05)}
function loopr(A,fn,a,b){const go=()=>{if(A.dead)return;try{if(AC.state=='running')fn()}catch(e){}A.tm=setTimeout(go,rr(a,b)*1000)};A.tm=setTimeout(go,rr(a,b)*400)}

/* ---- أصوات الطقس ---- */
const chirp=A=>{const n=R(2,4);for(let i=0;i<n;i++)vo({t:i*.13,pts:[[0,rr(2400,3200)],[.04,rr(3600,4600)],[.09,rr(2800,3400)]],d:.1,v:.04,out:A.g})};
const flutter=A=>{for(let i=0;i<7;i++)nb({t:i*.05,d:.035,f:rr(2200,3200),q:3,v:.035,out:A.g})};
const bell=(A,v)=>vo({pts:[[0,[1568,1760,2093,2349,2637][R(0,4)]]],d:.9,v:v||.025,out:A.g});
const AMBF={
 rain(A,storm){const b=nz('bandpass',3200,.45,storm?.3:.2,A);lfo(.18,storm?.08:.04,b.g.gain,A);nz('highpass',5500,.3,storm?.09:.05,A);const w=nz('lowpass',storm?380:500,.5,storm?.12:.04,A);if(storm)lfo(.12,.06,w.g.gain,A);
  loopr(A,()=>nb({d:.04,f:rr(2500,5200),q:3,v:storm?.07:.05,out:A.g}),.07,.28)},
 storm(A){AMBF.rain(A,1)},
 wind(A){const w=nz('bandpass',450,1.3,.28,A);lfo(.13,300,w.fl.frequency,A);lfo(.09,.12,w.g.gain,A);const x=nz('bandpass',1100,2,.07,A);lfo(.21,500,x.fl.frequency,A);
  loopr(A,()=>nb({d:.14,f:rr(2500,4500),q:2,v:.05,out:A.g}),.2,.7)},
 snow(A){const w=nz('lowpass',380,.7,.07,A);lfo(.1,.03,w.g.gain,A);loopr(A,()=>bell(A,.022),2,4.5)},
 cloud(A){const w=nz('bandpass',420,1,.12,A);lfo(.11,.05,w.g.gain,A)},
 sun(A){nz('lowpass',500,.6,.03,A);loopr(A,()=>chirp(A),1.6,4.5);loopr(A,()=>flutter(A),3,6)},
 night(A){const c=AC;[[4300,13,.011],[4700,9,.008]].forEach(([f,h,v])=>{const o=c.createOscillator(),g=c.createGain();o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(A.g);o.start();A.n.push(o);lfo(h,v,g.gain,A,'square')});
  nz('lowpass',300,.7,.025,A);loopr(A,()=>{vo({pts:[[0,430],[.28,380]],d:.45,v:.06,out:A.g});vo({t:.6,pts:[[0,430],[.28,370]],d:.5,v:.06,out:A.g})},7,13)},
 rainbow(A){nz('lowpass',450,.6,.02,A);loopr(A,()=>bell(A,.035),1.1,2.4);loopr(A,()=>flutter(A),2.5,5)}};
function ambStop(){const A=AMB;if(!A)return;AMB=null;A.dead=true;clearTimeout(A.tm);try{const t=AC.currentTime;A.g.gain.cancelScheduledValues(t);A.g.gain.setValueAtTime(A.g.gain.value,t);A.g.gain.linearRampToValueAtTime(0,t+.4)}catch(e){}
 setTimeout(()=>{A.n.forEach(s=>{try{s.stop()}catch(e){}});try{A.g.disconnect()}catch(e){}},550)}
function ambSync(){ambStop();if(typeof WXK=='undefined'||!WXK||!fxOn()||document.hidden||!AMBF[WXK])return;const c=au();if(!c)return;
 const A={n:[],dead:false};A.g=c.createGain();A.g.gain.setValueAtTime(0,c.currentTime);A.g.gain.linearRampToValueAtTime(.9,c.currentTime+1.2);A.g.connect(c.destination);AMB=A;
 try{AMBF[WXK](A)}catch(e){console.log('amb',e)}}
function thunderSnd(){if(!fxOn())return;if(!au())return;try{nb({d:.18,ty:'highpass',f:2500,q:.5,v:.16,a:.005});nb({t:.05,d:3.2,ty:'lowpass',f:220,f2:50,q:.8,v:.5,a:.15});nb({t:.9,d:2.2,ty:'lowpass',f:160,f2:45,q:.8,v:.28,a:.3});vo({t:.04,pts:[[0,70],[2.5,35]],d:2.8,v:.16})}catch(e){}}

/* ---- أصوات الحيوانات ---- */
const ANI={
 f1:()=>{vo({pts:[[0,480],[.12,780],[.4,640],[.6,430]],d:.65,ty:'sawtooth',v:.12,bp:[1300,3],am:[7,.25]});vo({pts:[[0,960],[.12,1560],[.4,1280],[.6,860]],d:.65,v:.03})},
 f2:()=>[0,.26].forEach(t=>{vo({t,pts:[[0,420],[.05,330],[.14,200]],d:.17,ty:'sawtooth',v:.14,bp:[900,1.4]});nb({t,d:.1,f:1200,q:1,v:.1})}),
 f3:()=>{[0,.1].forEach(t=>vo({t,pts:[[0,1500],[.07,2100]],d:.09,v:.07}));nb({t:.22,d:.03,f:3000,v:.05})},
 f4:()=>vo({pts:[[0,340],[.3,300],[.55,260]],d:.6,ty:'sawtooth',v:.09,bp:[800,2],am:[28,.5]}),
 f5:()=>{vo({pts:[[0,900],[.08,1500],[.22,1050]],d:.26,ty:'sawtooth',v:.07,bp:[1800,2.5]});vo({t:.3,pts:[[0,1100],[.08,1800],[.2,1250]],d:.24,ty:'sawtooth',v:.07,bp:[1900,2.5]})},
 f6:()=>[0,.17].forEach(t=>vo({t,pts:[[0,170],[.07,260],[.14,190]],d:.15,ty:'square',v:.06,bp:[500,3],am:[45,.6]})),
 f7:()=>{vo({pts:[[0,95],[.3,130],[1.1,60]],d:1.2,ty:'sawtooth',v:.16,bp:[500,.8],am:[22,.45],a:.15});nb({d:1.1,ty:'lowpass',f:300,f2:120,q:.7,v:.1})},
 f8:()=>{vo({pts:[[0,85],[.5,70],[.9,55]],d:.95,ty:'sawtooth',v:.14,bp:[420,.9],am:[16,.5],a:.1});nb({d:.9,ty:'lowpass',f:250,q:.7,v:.06})}};
/* تسجيلات حقيقية: assets/snd/<name>.mp3 — إن غاب الملف (مثل الباندا) يُستعمل الصوت المركّب ANI */
const SNDF={f1:'cat',f2:'dog',f3:'rabbit',f4:'panda',f5:'wolf',f6:'frog',f7:'lion',f8:'bear'},SA={};
Object.keys(SNDF).forEach(id=>{try{const a=new Audio('snd/'+SNDF[id]+'.mp3');a.preload='auto';a.onerror=()=>{a.bad=1};SA[id]=a;a.load()}catch(e){}});
const animal=id=>{if(!fxOn())return;try{const a=SA[id],syn=()=>{if(ANI[id])ANI[id]()};
 if(!a||a.bad||(a.error&&a.error.code)){syn();return}
 Object.keys(SA).forEach(k=>{if(k!=id){try{SA[k].pause()}catch(e){}}});
 a.currentTime=0;a.volume=1;const pr=a.play();if(pr&&pr.catch)pr.catch(syn)}catch(e){}};
document.addEventListener('visibilitychange',()=>{if(document.hidden)Object.keys(SA).forEach(k=>{try{SA[k].pause()}catch(e){}})});

/* ---- برق متفرّع ---- */
function boltSvg(){let x=60,y=0;const pts=[[x,y]];while(y<285){y+=rr(16,30);x=Math.max(14,Math.min(106,x+rr(-20,20)));pts.push([x,y])}
 const P=a=>'M'+a.map(p=>p[0].toFixed(0)+' '+p[1].toFixed(0)).join('L');let br='';
 for(let k=0;k<3;k++){const i=R(2,Math.max(2,pts.length-4)),dr=Math.random()<.5?-1:1;let bx=pts[i][0],by=pts[i][1];const b=[[bx,by]];for(let j=0;j<4;j++){by+=rr(12,22);bx+=dr*rr(8,18);b.push([bx,by])}br+=`<path d="${P(b)}" stroke="#fff" stroke-width="1.8" fill="none" stroke-linejoin="round"/>`}
 return `<svg viewBox="0 0 120 300" preserveAspectRatio="none"><path d="${P(pts)}" stroke="#9ad0ff" stroke-width="9" opacity=".35" fill="none" stroke-linejoin="round"/><path d="${P(pts)}" stroke="#fff" stroke-width="3" fill="none" stroke-linejoin="round"/>${br}</svg>`}

/* ---- فراشات ---- */
const BFC=['#ff7eb6','#ffd23f','#7ee8fa','#b388ff','#ff9f1c'];
const bflyHtml=n=>{let s='';for(let i=0;i<n;i++){const c=BFC[i%5];s+=`<span class="bf" style="top:${rr(10,70).toFixed(0)}%;animation-duration:${rr(16,26).toFixed(0)}s;animation-delay:-${rr(0,20).toFixed(0)}s"><svg viewBox="0 0 40 30"><g class="bwl"><path d="M20 15Q4 -2 3 10Q3 20 20 17Z" fill="${c}"/><path d="M20 17Q6 30 13 22Q20 22 20 17Z" fill="${c}" opacity=".85"/><circle cx="9" cy="10" r="2.5" fill="#fff" opacity=".7"/></g><g class="bwr"><path d="M20 15Q36 -2 37 10Q37 20 20 17Z" fill="${c}"/><path d="M20 17Q34 30 27 22Q20 22 20 17Z" fill="${c}" opacity=".85"/><circle cx="31" cy="10" r="2.5" fill="#fff" opacity=".7"/></g><rect x="19" y="9" width="2" height="14" rx="1" fill="#3a2418"/><path d="M20 10Q17 4 14 3M20 10Q23 4 26 3" stroke="#3a2418" stroke-width=".8" fill="none"/></svg></span>`}return s};

/* ---- إعدادات الصوت ---- */
function openSet(){let d=$('stp');if(d){d.remove();return}d=document.createElement('div');d.id='stp';d.className='stp';
 const rows=[['mu','🎵','الموسيقى'],['fx','🔊','المؤثرات وأصوات الطبيعة'],['v','📳','الاهتزاز']];
 const draw=()=>{d.innerHTML='<div class="stc"><h3>⚙️ الإعدادات</h3>'+rows.map(r=>`<button class="stb ${S[r[0]]===0?'off':'on'}" data-k="${r[0]}"><span>${r[1]} ${r[2]}</span><b>${S[r[0]]===0?'متوقف':'يعمل'}</b></button>`).join('')+'<button class="big" id="stx">تم ✔</button></div>'};
 draw();d.onclick=e=>{const b=e.target.closest('.stb');if(b){const k=b.dataset.k;S[k]=S[k]===0?1:0;try{localStorage.setItem('mhs',JSON.stringify(S))}catch(x){}$('vb').textContent=S.v===0?'📴':'📳';ambSync();if(k=='v'&&S.v!==0)hv(40,180);sfx('tap');draw();return}
  if(e.target.id=='stx'||e.target==d){d.remove();sfx('tap')}};document.body.appendChild(d)}

document.addEventListener('pointerdown',()=>setTimeout(ambSync,60),{once:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden)ambStop();else ambSync()});
document.addEventListener('click',e=>{const s=e.target.closest&&e.target.closest('.hero svg.pet');if(s&&s.dataset.pid){animal(s.dataset.pid);s.classList.add('hop');setTimeout(()=>s.classList.remove('hop'),520)}});
