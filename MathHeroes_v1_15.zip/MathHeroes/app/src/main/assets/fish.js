/* السمكة الجائعة (Feeding Frenzy) — نمط الزعيم الثالث. المرحلة 9 (نواة). يُحمَّل بعد boss2.js.
   v1.12: فقاعة السؤال (ابتلاع الصحيحة = نمو ×٠.٦ شريط + ٣ نجوم) + قرش زعيم يظهر من المرحلة ٣؛ امتلاء الشريط الأخير يجعله أخضر قابلاً للأكل ولدغته تهزمه.
   اسحب إصبعك: سمكتك تسبح نحوه. كُل الأصغر منك فتكبر (٥ مراحل)، وتجنّب الأكبر. هالة خضراء = كُله، حمراء = تجنّبه.
   الفوز: امتلاء شريط النمو في المرحلة الأخيرة. الخسارة: نفاد القلوب. يعيد استخدام .bxw/.bmsg/.bhud (لا CSS جديد). */
function bossFish(){SC='b';
 const k=Math.max(1,Math.floor((p.planet-1)/3)),f=p.eq.f,iv=p.inv||{},mh=3+(f=='f3'?1:0)+(iv.hp?1:0),ivs=!!iv.sh;
 p.inv={hp:0,sh:0};save();B={k,f,x:0};sfx('tap');
 show(`<div class="bxw full"><canvas id="cv"></canvas><div class="bmsg" id="bm"></div><div class="bhud"><span></span>${f&&it(f)?`<button id="bp">${it(f)[2]}<small>مساعدة</small><i class="cdv" style="height:0"></i></button>`:'<span></span>'}</div></div>`,0,'night',1);
 window.scrollTo(0,0);
 const cv=$('cv'),c=cv.getContext('2d'),W=360,H=Math.max(500,Math.min(820,Math.round(360*innerHeight/innerWidth)));cv.width=W;cv.height=H;
 const col=(it(p.eq.s)||[0,0,0,'#ffd23f'])[3]||'#ffd23f';
 const RS=[14,19,25,32,40],CL=[9,15,22,31,42,56],MAXF=14,NEED=40,TOP=84,BOT=H-44;
 const me={x:W/2,y:H*.6,r:RS[0],h:mh,inv:0,sh:f=='f4'||ivs,st:0,g:0,face:1},ab={cd:0,max:15};
 let qb=null,ng=7,shark=null,rdy=0,t=0,done=0,shk=0,nx=.4,eaten=0,slowT=0,mag=0,hid=0,last=performance.now(),tx=me.x,ty=me.y,hint=0,bite1=0;
 const fi=[],pc=[],bb=Array.from({length:22},()=>({x:R(0,W),y:R(0,H),r:R(1,4),v:R(12,40)}));
 const msg=s=>{const m=$('bm');if(!m)return;m.textContent=s;m.style.opacity=1;clearTimeout(msg.t);msg.t=setTimeout(()=>{if(m)m.style.opacity=0},2200)};
 msg('اسحب إصبعك لتسبح السمكة 👆 كُل الأخضر!');
 const burst=(x,y,cl,n)=>{for(let i=0;i<n;i++)pc.push({x,y,vx:R(-120,120),vy:R(-140,40),l:1,r:R(2,5),c:cl})};
 const fin=ok=>{done=1;clearInterval(IV[0]);if(ok){B.x=Math.min(10,eaten);bwin('fish')}else blose(null,'fish')};
 const hurt=(fx,fy)=>{if(me.inv>0)return;if(me.sh){me.sh=false;hv(60,120)}else{me.h--;hpat([0,90,40,140])}
  me.inv=1.5;sfx('bad');shk=.35;burst(me.x,me.y,'#ff4d6d',10);const a=Math.atan2(me.y-fy,me.x-fx);tx=me.x=Math.max(me.r,Math.min(W-me.r,me.x+Math.cos(a)*50));ty=me.y=Math.max(TOP,Math.min(BOT,me.y+Math.sin(a)*50))};
 const mv=e=>{if(done)return;const r=cv.getBoundingClientRect();tx=(e.clientX-r.left)/r.width*W;ty=(e.clientY-r.top)/r.height*H-34;tx=Math.max(me.r,Math.min(W-me.r,tx));ty=Math.max(TOP,Math.min(BOT,ty))};
 cv.style.touchAction='none';cv.onpointerdown=mv;cv.onpointermove=e=>{if(e.buttons)mv(e)};
 /* سمكة جديدة: ٦٥٪ أصغر منك (طعام) وإلا أكبر (خطر)؛ لا تُولد على بعد قريب من سمكتك */
 const spawn=()=>{if(fi.length>=MAXF)return;
  const sm=CL.filter(r=>r<me.r*.85),bg=CL.filter(r=>r>me.r*1.15);let r;
  if(bg.length&&(Math.random()>.65||!sm.length))r=bg[R(0,Math.min(bg.length-1,1+(k>2?1:0)))];else r=sm.length?sm[R(0,sm.length-1)]:CL[0];
  const dir=Math.random()<.5?1:-1,y=R(TOP,BOT);
  fi.push({x:dir>0?-r*2:W+r*2,y,r,vx:dir*(35+R(0,45)+k*4)*(r>me.r?1.1:1),ph:Math.random()*6,c:`hsl(${R(0,330)},70%,58%)`,big:r>me.r*1.12})};
 const ABIL={
  f1:()=>{mag=6;return'🧲 الأسماك الصغيرة تأتي إليك!'},
  f2:()=>{slowT=5;return'👃 الأسماك تباطأت!'},
  f3:()=>{me.h=Math.min(mh,me.h+1);return'❤ قلب إضافي!'},
  f4:()=>{me.sh=true;return'🛡 درع جاهز!'},
  f5:()=>{hid=2.5;me.inv=2.5;return'🐺 اختفاء مؤقت!'},
  f6:()=>{me.inv=1.8;return'🐸 قفزة فوق الماء! لا أحد يؤذيك'},
  f7:()=>{me.h=mh;return'🦁 شفاء كامل!'},
  f8:()=>{let n=0;for(let i=fi.length-1;i>=0;i--)if(fi[i].big){burst(fi[i].x,fi[i].y,'#fff',8);fi.splice(i,1);n++}return'🐻 هرب الكبار!'}};
 if(f&&$('bp'))$('bp').onclick=()=>{if(ab.cd>0||done||!ABIL[f])return;ab.cd=ab.max;sfx('pet');animal(f);msg(ABIL[f]())};
 const grow=pts=>{me.g+=pts;if(me.g>=NEED){if(me.st>=RS.length-1){me.g=NEED;return 1}me.st++;me.g-=NEED;sfx('win');hv(40,140);burst(me.x,me.y,'#7df9ff',16);msg('كبرت! 🐟 المرحلة '+(me.st+1))}return 0};
 const ready=()=>{if(rdy)return;rdy=1;sfx('win');hv(60,200);msg('القرش ضعيف! كُله الآن! 🦈💚');burst(shark.x,shark.y,'#5dff7a',20)};
 const askQ=()=>{const q=gen(p,2),w=q.c.filter(x=>x!=q.a).sort(()=>Math.random()-.5).slice(0,2),vals=[q.a,...w].sort(()=>Math.random()-.5);
  qb={q,life:13,bs:vals.map((v,i)=>({v,x:W/6+i*W/3+R(-14,14),y:BOT-R(0,30),ph:Math.random()*6}))}};
 const upd=dt=>{t+=dt;me.inv=Math.max(0,me.inv-dt);shk=Math.max(0,shk-dt);slowT=Math.max(0,slowT-dt);mag=Math.max(0,mag-dt);hid=Math.max(0,hid-dt);ab.cd=Math.max(0,ab.cd-dt);
  me.r+=(RS[me.st]-me.r)*Math.min(1,dt*5);
  const ox=me.x;me.x+=(tx-me.x)*Math.min(1,dt*7);me.y+=(ty-me.y)*Math.min(1,dt*7);if(Math.abs(me.x-ox)>.3)me.face=me.x>ox?1:-1;
  if(!shark&&me.st>=3){shark={x:Math.random()<.5?-90:W+90,y:H*.35,r:68,ph:0};msg('🦈 القرش قادم! ابتعد عنه حتى تكبر')}
  if(shark){const dx=me.x-shark.x,dy=me.y-shark.y,d=Math.hypot(dx,dy)||1,sp=(rdy?0:26+k*2)*(slowT>0?.55:1),rt=shark.pz>0;shark.pz=Math.max(0,(shark.pz||0)-dt);if(rt){shark.x-=dx/d*95*dt;shark.y-=dy/d*95*dt;shark.x=Math.max(-60,Math.min(W+60,shark.x));shark.y=Math.max(TOP,Math.min(BOT,shark.y))}else{shark.x+=dx/d*sp*dt;shark.y+=dy/d*sp*dt}shark.ph+=dt*3;
   if(d<me.r*.6+shark.r*.55){if(rdy){fin(1);return}else if(hid<=0&&me.inv<=0){hurt(shark.x,shark.y);shark.pz=2.4;me.inv=2.2}}}
  if(!qb&&!rdy&&t>=ng)askQ()
  if(qb){qb.life-=dt;let hit=null;qb.bs.forEach(b=>{b.y-=26*dt*(slowT>0?.55:1);b.ph+=dt*2;if(!hit&&Math.hypot(b.x-me.x,b.y-me.y)<me.r*.7+24)hit=b});
   if(hit){const q=qb.q,ok=hit.v==q.a;p.ws=p.ws||{};qb=null;ng=t+R(13,16);
    if(ok){sfx('ok');hv(25,120);eaten+=3;burst(hit.x,hit.y,'#ffd23f',14);msg('صحيح! نمو كبير 🫧⭐⭐⭐');p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);if(grow(NEED*.6))ready()}
    else{sfx('bad');msg('الإجابة هي '+q.a+' 💡');p.ws[q.o]=(p.ws[q.o]||0)+1;burst(hit.x,hit.y,'#fff',8)}save()}
   else if(qb.life<=0||qb.bs.every(b=>b.y<TOP-30)){qb=null;ng=t+8}}
  nx-=dt;if(nx<=0){spawn();nx=.55+Math.random()*.5}
  bb.forEach(b=>{b.y-=b.v*dt;if(b.y<-5){b.y=H+5;b.x=R(0,W)}});
  for(let i=fi.length-1;i>=0;i--){const o=fi[i];o.x+=o.vx*dt*(slowT>0?.55:1);o.ph+=dt*4;
   if(mag>0&&!o.big){o.x+=(me.x-o.x)*Math.min(1,dt*1.6);o.y+=(me.y-o.y)*Math.min(1,dt*1.6)}
   if(o.x<-o.r*3||o.x>W+o.r*3){fi.splice(i,1);continue}
   const d=Math.hypot(o.x-me.x,o.y-me.y);
   if(d<me.r*.75+o.r*.6){
    if(o.r<me.r*.88){fi.splice(i,1);eaten++;sfx('star');hv(10,60);burst(o.x,o.y,o.c,8);if(grow(o.r*.7))ready()}
    else if(o.r>me.r*1.12&&hid<=0){if(!bite1){bite1=1;msg('الأحمر أكبر منك! ابتعد عنه 🔴')}hurt(o.x,o.y)}}}
  for(let i=pc.length-1;i>=0;i--){const q=pc[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=200*dt;q.l-=dt*2;if(q.l<=0)pc.splice(i,1)}};
 /* رسم سمكة: جسم بيضاوي + ذيل + عين؛ halo: 1 أخضر (كُله) / 2 أحمر (تجنّبه) + عيون غاضبة */
 const fish=(x,y,r,cl,dir,halo,ph,angry)=>{c.save();c.translate(x,y);c.scale(dir,1);
  if(halo){c.shadowColor=halo==1?'#5dff7a':'#ff3b3b';c.shadowBlur=18;c.strokeStyle=halo==1?'rgba(93,255,122,.9)':'rgba(255,59,59,.9)';c.lineWidth=3;c.beginPath();c.ellipse(0,0,r*1.35,r*.95,0,0,7);c.stroke()}
  const w=Math.sin(ph)*r*.18;c.shadowBlur=0;c.fillStyle=cl;c.beginPath();c.moveTo(-r*.9,0);c.lineTo(-r*1.5,-r*.6+w);c.lineTo(-r*1.5,r*.6+w);c.closePath();c.fill();
  c.beginPath();c.ellipse(0,0,r,r*.7,0,0,7);c.fill();c.fillStyle='rgba(255,255,255,.28)';c.beginPath();c.ellipse(r*.05,-r*.25,r*.6,r*.22,0,0,7);c.fill();
  c.fillStyle='#fff';c.beginPath();c.arc(r*.5,-r*.15,r*.2,0,7);c.fill();c.fillStyle='#111';c.beginPath();c.arc(r*.56,-r*.15,r*.1,0,7);c.fill();
  if(angry){c.strokeStyle='#111';c.lineWidth=Math.max(2,r*.07);c.beginPath();c.moveTo(r*.25,-r*.45);c.lineTo(r*.75,-r*.28);c.stroke()}
  else{c.strokeStyle='#111';c.lineWidth=Math.max(1.5,r*.05);c.beginPath();c.arc(r*.62,r*.12,r*.18,.2,1.5);c.stroke()}c.restore()};
 const draw=()=>{c.clearRect(0,0,W,H);c.direction='ltr';c.save();if(shk>0)c.translate(R(-5,5)*shk*3,R(-5,5)*shk*3);
  const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'#1fa2d8');g.addColorStop(1,'#07345a');c.fillStyle=g;c.fillRect(0,0,W,H);
  c.fillStyle='rgba(255,255,255,.07)';[40,150,260].forEach((x,i)=>{c.beginPath();c.moveTo(x+Math.sin(t*.5+i)*14,0);c.lineTo(x+60,0);c.lineTo(x+150,H);c.lineTo(x+60,H);c.closePath();c.fill()});
  c.fillStyle='#d9b36c';c.fillRect(0,H-26,W,26);c.fillStyle='#2f9e5b';[20,95,200,300,340].forEach((x,i)=>{const s=Math.sin(t*1.5+i)*5;c.beginPath();c.moveTo(x-6,H-26);c.quadraticCurveTo(x+s,H-50,x+s*1.5,H-70-i*4);c.quadraticCurveTo(x+s+8,H-48,x+6,H-26);c.fill()});
  c.fillStyle='rgba(255,255,255,.35)';bb.forEach(b=>{c.beginPath();c.arc(b.x+Math.sin(t*2+b.y*.05)*3,b.y,b.r,0,7);c.fill()});
  fi.forEach(o=>fish(o.x,o.y+Math.sin(o.ph)*3,o.r,o.c,o.vx>0?1:-1,o.r<me.r*.88?1:o.big?2:0,o.ph,o.big));
  if(me.inv<=0||Math.floor(me.inv*10)%2){c.globalAlpha=hid>0?.35:1;fish(me.x,me.y,me.r,col,me.face,0,t*8,0);c.globalAlpha=1}
  if(me.sh){c.strokeStyle='#7df9ff';c.lineWidth=3;c.beginPath();c.arc(me.x,me.y,me.r*1.5,0,7);c.stroke()}
  if(shark){c.save();c.translate(shark.x,shark.y);const dir=me.x>shark.x?1:-1;c.scale(dir,1);c.fillStyle=rdy?'#3ddc84':'#59697a';c.beginPath();c.moveTo(-8,-shark.r*.62);c.lineTo(14,-shark.r*1.1);c.lineTo(34,-shark.r*.6);c.closePath();c.fill();c.restore();
   fish(shark.x,shark.y,shark.r,rdy?'#59697a':'#59697a',dir,rdy?1:2,shark.ph,!rdy);
   c.save();c.translate(shark.x,shark.y);c.scale(dir,1);c.fillStyle='#fff';for(let i=0;i<4;i++){c.beginPath();c.moveTo(shark.r*(.5+i*.1),shark.r*.22);c.lineTo(shark.r*(.55+i*.1),shark.r*.4);c.lineTo(shark.r*(.6+i*.1),shark.r*.22);c.fill()}c.restore()}
  if(qb){qb.bs.forEach(b=>{const x=b.x+Math.sin(b.ph)*6;c.fillStyle='rgba(180,240,255,.35)';c.strokeStyle='#e8fbff';c.lineWidth=3;c.beginPath();c.arc(x,b.y,26,0,7);c.fill();c.stroke();c.fillStyle='#fff';c.font='bold 26px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(b.v,x,b.y+1);c.textBaseline='alphabetic'});
   c.fillStyle='rgba(10,10,40,.8)';c.fillRect(W/2-100,60,200,40);c.strokeStyle='#7df9ff';c.lineWidth=2;c.strokeRect(W/2-100,60,200,40);c.fillStyle='#fff';c.font='bold 26px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(qb.q.t,W/2,81);c.textBaseline='alphabetic'}
  pc.forEach(q=>{c.globalAlpha=Math.max(0,q.l);c.fillStyle=q.c;c.beginPath();c.arc(q.x,q.y,q.r,0,7);c.fill()});c.globalAlpha=1;
  c.fillStyle='rgba(0,0,0,.5)';c.fillRect(20,44,W-40,12);c.fillStyle=rdy||me.g>NEED*.8?'#5dff7a':'#ffd23f';c.fillRect(20,44,(W-40)*Math.min(1,me.g/NEED),12);
  c.font='20px sans-serif';c.fillStyle='#fff';c.textAlign='right';c.fillText('❤'.repeat(Math.max(0,me.h)),W-10,30);c.textAlign='left';c.fillText('🐟 '+(me.st+1)+'/'+RS.length,10,30);
  const cd=$('bp');if(cd)cd.querySelector('.cdv').style.height=(ab.cd/ab.max*100)+'%';c.restore()};
 IV[0]=setInterval(()=>{if(done)return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;upd(dt);draw();
  if(me.h<=0)fin(0)},16)}
