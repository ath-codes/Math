/* رفيق الهجوم المشترك + خلفية فضائية (v2.0). يُحمَّل بعد game.js وقبل boss2.js.
   PetGun(id): حيوانك يرمي النار/القذائف على الزعيم تلقائياً مساعدةً لك (يُستعمل في معركة الإطلاق وسباق العوائق).
   كل حيوان له قذيفة مختلفة: قطة/كلب/ذئب نار، أرنب جزرة صاروخية، باندا قذيفة خيزران، ضفدع كرة لزجة، أسد كرة نار ضخمة، دب صخرة مدفعية. */
const PETGUN={
 f1:{k:'fire',c:'#ff9f1c',d:1,cd:1.9},f2:{k:'fire',c:'#ff5a3a',d:1,cd:1.8},f3:{k:'carrot',c:'#ff9f1c',d:1.1,cd:2.1},f4:{k:'bamboo',c:'#7bd957',d:1,cd:2},
 f5:{k:'blue',c:'#4cc9f0',d:1.1,cd:1.8},f6:{k:'slime',c:'#9be564',d:1,cd:1.6},f7:{k:'mega',c:'#ffb703',d:1.6,cd:2.4},f8:{k:'boulder',c:'#b9b2c9',d:1.5,cd:2.5}};
const PGTR={fire:'#ff9f1c',blue:'#7de3ff',mega:'#ffd23f',carrot:'#ffd23f',bamboo:'#b6f58a',slime:'#9be564',boulder:'rgba(210,205,225,.75)'};
function pgDraw(c,k,s){const r=s.r,a=s.a||-1.57;c.save();c.translate(s.x,s.y);
 if(k=='fire'||k=='blue'||k=='mega'){c.rotate(a);const bl=k=='blue',L=r*3.6,g=c.createLinearGradient(-L,0,r,0);
  g.addColorStop(0,bl?'rgba(40,120,255,0)':'rgba(255,50,0,0)');g.addColorStop(.55,bl?'#3a9bff':'#ff7a00');g.addColorStop(1,bl?'#bff3ff':'#ffd23f');
  c.fillStyle=g;c.beginPath();c.arc(0,0,r,-Math.PI/2,Math.PI/2);c.quadraticCurveTo(-r*.5,r*.95+Math.sin(s.t*50)*r*.18,-L,0);c.quadraticCurveTo(-r*.5,-r*.95-Math.sin(s.t*47)*r*.18,0,-r);c.fill();
  const g2=c.createRadialGradient(0,0,0,0,0,r);g2.addColorStop(0,'#fff');g2.addColorStop(.6,bl?'#d6f6ff':'#fff2a8');g2.addColorStop(1,'rgba(255,200,60,0)');c.fillStyle=g2;c.beginPath();c.arc(0,0,r*.95,0,7);c.fill()}
 else if(k=='carrot'){c.rotate(a);c.fillStyle='#ff9f1c';c.beginPath();c.moveTo(r*1.7,0);c.lineTo(-r,-r*.75);c.lineTo(-r,r*.75);c.closePath();c.fill();
  c.strokeStyle='#d9560f';c.lineWidth=1.5;c.beginPath();c.moveTo(r*.4,-r*.3);c.lineTo(r*.1,-r*.1);c.moveTo(-r*.2,r*.4);c.lineTo(-r*.5,r*.2);c.stroke();
  c.fillStyle='#4caf50';c.beginPath();c.ellipse(-r*1.15,-r*.12,r*.55,r*.24,.5,0,7);c.fill();c.beginPath();c.ellipse(-r*1.15,r*.12,r*.55,r*.24,-.5,0,7);c.fill();
  c.fillStyle='#ffd23f';c.beginPath();c.ellipse(-r*1.9,0,r*.75+Math.sin(s.t*60)*r*.15,r*.28,0,0,7);c.fill()}
 else if(k=='bamboo'){c.rotate(a);const g=c.createLinearGradient(0,-r*.6,0,r*.6);g.addColorStop(0,'#c8f7a0');g.addColorStop(1,'#3e8e2e');c.fillStyle=g;c.beginPath();c.ellipse(0,0,r*1.5,r*.62,0,0,7);c.fill();
  c.strokeStyle='#2a6a1d';c.lineWidth=1.6;[-.7,0,.7].forEach(x=>{c.beginPath();c.moveTo(x*r,-r*.55);c.lineTo(x*r,r*.55);c.stroke()});
  c.strokeStyle='rgba(170,255,120,.65)';c.lineWidth=2;c.beginPath();c.arc(0,0,r*1.45+Math.sin(s.t*30)*2,0,7);c.stroke()}
 else if(k=='slime'){const w=1+Math.sin(s.t*30)*.12;c.scale(w,2-w);const g=c.createRadialGradient(-r*.3,-r*.3,1,0,0,r*1.2);g.addColorStop(0,'#e4ffb0');g.addColorStop(.6,'#7bd957');g.addColorStop(1,'#2e7d32');
  c.fillStyle=g;c.beginPath();c.arc(0,0,r*1.1,0,7);c.fill();c.fillStyle='rgba(255,255,255,.7)';c.beginPath();c.ellipse(-r*.4,-r*.4,r*.3,r*.18,-.6,0,7);c.fill()}
 else{c.rotate(s.t*9);const g=c.createRadialGradient(-r*.3,-r*.3,1,0,0,r*1.2);g.addColorStop(0,'#d9d3e6');g.addColorStop(.6,'#7a7290');g.addColorStop(1,'#3a3350');
  c.fillStyle=g;c.beginPath();for(let i=0;i<9;i++){const an=i/9*6.283,rr=r*(1+.12*Math.sin(i*2.9));c.lineTo(Math.cos(an)*rr,Math.sin(an)*rr)}c.closePath();c.fill();
  c.fillStyle='rgba(30,20,50,.4)';c.beginPath();c.arc(-r*.3,-r*.1,r*.25,0,7);c.fill();c.beginPath();c.arc(r*.35,r*.3,r*.16,0,7);c.fill()}
 c.restore()}
function pgBurst(pc,rg,x,y,k){const big=k=='mega'||k=='boulder'?1.5:1,cl={fire:['#fff6c0','#ffb703','#ff5a1f'],blue:['#fff','#9be7ff','#3a9bff'],mega:['#fff6c0','#ffb703','#ff3c00'],carrot:['#ffd23f','#ff9f1c','#4caf50'],bamboo:['#e4ffb0','#7bd957','#2e7d32'],slime:['#e4ffb0','#7bd957','#9be564'],boulder:['#d9d3e6','#8a82a3','#ff9f1c']}[k]||['#fff','#ffb703','#ff5a1f'];
 for(let i=0,n=Math.round(14*big);i<n;i++)pc.push({x,y,vx:R(-170,170)*big,vy:R(-200,70)*big,l:1,r:R(2,5)*big,c:cl[i%3]});
 if(rg)rg.push({x,y,r:8,l:1,c:cl[1]})}
function PetGun(id){const d=PETGUN[id]||PETGUN.f1;
 return{id,d,cd:1.3,mouth:0,sh:[],
  fire(mx,my,mul,dur){this.sh.push({x0:mx,y0:my,x:mx,y:my,u:0,dur:dur||.6,mul:mul||1,t:0,r:10,a:-1.5});this.mouth=.22;sfx('pfire');hv(6,40)},
  step(dt,mx,my,tg,on,pc,auto,rs){this.mouth=Math.max(0,this.mouth-dt);
   if(auto){this.cd-=dt;if(this.cd<=0){this.cd=d.cd*(.9+Math.random()*.2);this.fire(mx,my)}}
   const T=tg();
   for(let i=this.sh.length-1;i>=0;i--){const s=this.sh[i];s.t+=dt;s.u+=dt/s.dur;const e=Math.min(1,s.u),px=s.x,py=s.y;
    s.x=s.x0+(T.x-s.x0)*e;s.y=s.y0+(T.y-s.y0)*e-Math.sin(Math.PI*e)*26;
    s.r=(s.mul>1.3?15:11)*(1-.4*e)*(rs||1);s.a=Math.atan2(s.y-py,s.x-px);
    if(pc.length<260)pc.push({x:s.x+R(-3,3),y:s.y+R(-3,3),vx:R(-18,18),vy:R(-10,30),l:.55,r:Math.max(2,s.r*.38),c:PGTR[d.k],g:0,fd:2.6});
    if(s.u>=1){this.sh.splice(i,1);on(s,s.x,s.y)}}},
  draw(c){this.sh.forEach(s=>pgDraw(c,d.k,s))},
  muzzle(c,x,y){if(this.mouth<=0)return;const a=this.mouth/.22,g=c.createRadialGradient(x,y,1,x,y,22*a+6);g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.4,d.c);g.addColorStop(1,'rgba(255,120,0,0)');c.fillStyle=g;c.beginPath();c.arc(x,y,22*a+6,0,7);c.fill()}}}
function mkNeb(W,H){try{const o=document.createElement('canvas');o.width=W;o.height=H;const x=o.getContext('2d');
 let g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,'#04061c');g.addColorStop(.45,'#1a0f4a');g.addColorStop(1,'#0b0a2a');x.fillStyle=g;x.fillRect(0,0,W,H);
 [[.2,.16,150,'120,60,255'],[.86,.3,130,'255,80,150'],[.5,.42,180,'40,160,255']].forEach(a=>{const q=x.createRadialGradient(W*a[0],H*a[1],5,W*a[0],H*a[1],a[2]);q.addColorStop(0,`rgba(${a[3]},.30)`);q.addColorStop(1,`rgba(${a[3]},0)`);x.fillStyle=q;x.fillRect(0,0,W,H)});return o}catch(e){return null}}
Object.assign(SF,{pfire:()=>{tn(300,0,.12,'sawtooth',.03);tn(560,.04,.14,'triangle',.035)},pboom:()=>{tn(140,0,.14,'square',.06);tn(80,.05,.2,'sawtooth',.05)},
 jump:()=>{tn(440,0,.08,'triangle',.08);tn(660,.06,.1,'triangle',.08);tn(880,.12,.14,'triangle',.07)},land:()=>tn(150,0,.09,'sine',.1),
 gate:()=>[392,523,659].forEach((f,i)=>tn(f,i*.08,.2,'triangle',.08))});
