/* v2.1 — صقل: أصوات ومؤثرات إضافية + دعم الكمبيوتر (فأرة ولوحة مفاتيح). يُحمَّل بعد minigames.js. */
(function(){
 const N=o=>{try{if(fxOn())nb(o)}catch(e){}};
 Object.assign(SF,{
  /* أكل سمكة: قضمة + فقاعة */
  chomp:()=>{tn(420,0,.06,'square',.07);tn(300,.05,.08,'triangle',.08);N({f:900,f2:300,d:.12,q:2,v:.06})},
  /* فقاعة تنفجر */
  pop:()=>{tn(900+Math.random()*500,0,.05,'sine',.12);N({f:3000,f2:900,d:.07,q:1.5,v:.07,ty:'highpass'})},
  /* رذاذ ماء */
  splash:()=>{N({f:1800,f2:500,d:.35,q:.8,v:.09});N({f:900,f2:300,d:.3,q:.8,v:.06,t:.05})},
  /* نمو: سلّم صاعد لامع */
  grow:()=>[392,494,587,784,988,1175].forEach((f,i)=>tn(f,i*.07,.22,'triangle',.1)),
  /* سلسلة: نغمة تعلو مع كل أكلة */
  combo:()=>[784,988,1319,1760].forEach((f,i)=>tn(f,i*.05,.16,'sine',.1)),
  /* القرش قادم */
  shark:()=>{[110,104,98].forEach((f,i)=>tn(f,i*.22,.3,'sawtooth',.07));N({f:200,f2:80,d:.7,q:1,v:.08,ty:'lowpass'})},
  /* قطع سريع */
  slice:()=>{N({f:3500,f2:900,d:.14,q:1.2,v:.1,ty:'highpass'});tn(1568,0,.06,'sawtooth',.03)},
  /* قلب بطاقة */
  flip:()=>{tn(520,0,.04,'square',.05);N({f:2200,f2:1200,d:.06,q:1,v:.05})},
  /* مطرقة / ضربة فضائي */
  whack:()=>{tn(180,0,.1,'square',.12);tn(90,.02,.16,'sine',.14);N({f:1200,f2:300,d:.1,q:1,v:.08})},
  /* أكل رفيق */
  munch:()=>{[0,.11,.22].forEach(t=>{tn(260,t,.07,'square',.06);N({f:700,f2:300,d:.08,q:1.5,v:.05,t})})},
  /* نجمة تتجمع */
  sparkle:()=>[1568,2093,2637].forEach((f,i)=>tn(f,i*.045,.14,'sine',.07)),
  /* عدّاد الوقت يقرب */
  tick:()=>tn(1000,0,.04,'square',.05)
 });
 /* مؤثر عائم: نص يطفو للأعلى فوق عنصر DOM */
 window.floatTxt=(el,s,cl)=>{try{const r=el.getBoundingClientRect(),d=document.createElement('div');d.className='fl-t';d.textContent=s;d.style.left=(r.left+r.width/2)+'px';d.style.top=(r.top+r.height/2)+'px';if(cl)d.style.color=cl;document.body.appendChild(d);setTimeout(()=>d.remove(),900)}catch(e){}};
 /* كونفيتي بسيط على الشاشة كلها */
 window.confetti=(n)=>{try{const cs=['#ffd23f','#ff6b9d','#4cc9f0','#5dff7a','#b388ff','#ff9f1c'];for(let i=0;i<(n||26);i++){const d=document.createElement('i');d.className='cf';d.style.left=(Math.random()*100)+'vw';d.style.background=cs[i%cs.length];d.style.animationDuration=(1.4+Math.random()*1.2)+'s';d.style.animationDelay=(Math.random()*.3)+'s';d.style.setProperty('--dx',((Math.random()-.5)*160)+'px');document.body.appendChild(d);setTimeout(()=>d.remove(),3000)}}catch(e){}};
 /* فضائي لطيف بالـSVG بدل الإيموجي */
 window.alienSvg=(cl)=>{cl=cl||'#7dff9b';return `<svg viewBox="0 0 80 90" width="64" height="72"><defs><radialGradient id="ag${cl.slice(1)}" cx=".35" cy=".3"><stop offset="0" stop-color="#fff" stop-opacity=".7"/><stop offset=".4" stop-color="${cl}"/><stop offset="1" stop-color="#1e8f4f"/></radialGradient></defs>
  <line x1="28" y1="14" x2="22" y2="3" stroke="${cl}" stroke-width="3" stroke-linecap="round"/><circle cx="21" cy="3.5" r="4" fill="#ffd23f"/>
  <line x1="52" y1="14" x2="58" y2="3" stroke="${cl}" stroke-width="3" stroke-linecap="round"/><circle cx="59" cy="3.5" r="4" fill="#ffd23f"/>
  <ellipse cx="40" cy="48" rx="32" ry="34" fill="url(#ag${cl.slice(1)})"/>
  <ellipse cx="28" cy="42" rx="9" ry="12" fill="#fff"/><ellipse cx="52" cy="42" rx="9" ry="12" fill="#fff"/>
  <circle cx="29" cy="44" r="5" fill="#222"/><circle cx="53" cy="44" r="5" fill="#222"/><circle cx="31" cy="42" r="1.8" fill="#fff"/><circle cx="55" cy="42" r="1.8" fill="#fff"/>
  <path d="M28 64 Q40 76 52 64" stroke="#1b5a35" stroke-width="3.5" fill="none" stroke-linecap="round"/><circle cx="18" cy="58" r="4" fill="#ff9ec7" opacity=".6"/><circle cx="62" cy="58" r="4" fill="#ff9ec7" opacity=".6"/></svg>`};
 window.ASP=()=>document.body.classList.contains('desk')?1.62:innerHeight/innerWidth;
 /* === دعم الكمبيوتر: لوحة المفاتيح تُحاكي اللمس على لوحة اللعب === */
 const cvx=()=>document.getElementById('cv');
 document.addEventListener('keydown',e=>{
  const k=e.key,jb=document.getElementById('jb'),bp=document.getElementById('bp');
  if(k==' '||k=='ArrowUp'||k=='w'){if(jb){e.preventDefault();jb.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true}))}}
  else if(k=='Enter'||k=='e'||k=='E'){if(bp)bp.click()}
 });
 /* تكبير مناسب للكمبيوتر */
 const isDesk=()=>innerWidth>=800&&innerWidth>innerHeight*1.15;
 const mark=()=>document.body.classList.toggle('desk',isDesk());addEventListener('resize',mark);mark();
})();
