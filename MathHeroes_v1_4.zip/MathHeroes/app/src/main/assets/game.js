const $=id=>document.getElementById(id);
const R=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const esc=s=>s.replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
let P=[],p=null,G=null,S={m:1},AC,TAB='s',SC='p',PV={},TT,IV=[];
try{P=JSON.parse(localStorage.getItem('mh')||'[]')}catch(e){}
try{S=JSON.parse(localStorage.getItem('mhs')||'{"m":1}')}catch(e){}
const save=()=>{try{chk()}catch(e){}try{localStorage.setItem('mh',JSON.stringify(P))}catch(e){}};
const AGES=['5-6','7-8','9'];
const NAMES=['نورا','لمعان','سديم','هلال','شعاع','ضياء','مجرّة','نيزك','قمر','سنا','ريان','بريق','أُفق','سحر','وميض','زُهرة','نجمة','بدر','رحاب','فجر'];
const EM=['🍎','⭐','👾','🍉','🪐','🍪','🐟','🎈'];
const pname=n=>'كوكب '+NAMES[(n-1)%20]+' '+n;
const PR=['أحسنت يا بطل!','رائع!','ممتاز!','عبقري!','مذهل!'];
const FACTS=['الشمس نجمة وليست كوكباً ☀️','في الفضاء لا يوجد صوت، لأنه لا يوجد هواء 🤫','زحل له حلقات جميلة من الجليد والصخور 🪐','يتسع داخل الشمس أكثر من مليون كوكب أرض!','القمر يبتعد عن الأرض قليلاً كل عام 🌙'];
const IT=[
['s0','s','🚀','#ffd23f',0,'الذهبي'],['s1','s','🛸','#2ec4b6',5,'الطبق'],['s2','s','🛰️','#ff6b9d',8,'القمر'],['s3','s','🚁','#7bd957',10,'المروحية'],['s4','s','🚀','#9b5de5',12,'البنفسجي'],['s5','s','✈️','#00bbf9',15,'النفاثة'],['s6','s','🛸','#f15bb5',20,'الوردي'],['s7','s','🚀','#ff9f1c',25,'الناري'],
['h1','h','🎀','',5,'فيونكة'],['h2','h','🧢','',6,'كاب'],['h3','h','🕶️','',8,'نظارة'],['h4','h','🎧','',10,'سماعات'],['h5','h','🎩','',12,'قبعة'],['h6','h','👑','',25,'تاج'],
['f1','f','🐱','',6,'قطة'],['f2','f','🐶','',6,'كلب'],['f3','f','🐰','',8,'أرنب'],['f4','f','🐼','',10,'باندا'],['f5','f','🦊','',12,'ثعلب'],['f6','f','🐸','',12,'ضفدع'],['f7','f','🦁','',20,'أسد'],['f8','f','🐻','',30,'دب'],
['b1','b','🌌','#3a0ca3,#f72585',8,'غروب'],['b2','b','🌊','#023e8a,#00b4d8',8,'محيط'],['b3','b','🌳','#1b4332,#52b788',10,'غابة'],['b4','b','🍭','#ff70a6,#ff9770',12,'حلوى'],['b5','b','🏆','#7f5539,#ffb703',18,'ذهب'],
['t1','t','✨','',8,'بريق'],['t2','t','💖','',10,'قلوب'],['t3','t','🔥','',12,'نار'],['t4','t','🌈','',15,'قوس قزح'],['t5','t','❄️','',15,'ثلج'],
['w0','w','🔫','',0,'مسدس الليزر'],['w1','w','⚡','',6,'صاعقة'],['w2','w','🏹','',12,'قوس النجوم'],['w3','w','🔱','',20,'رمح البلازما'],['w4','w','☄️','',32,'مدفع النيزك'],['w5','w','🚀','',50,'صاروخ المجرة']];
const WD={w0:2,w1:3,w2:4,w3:6,w4:9,w5:14};
const WP={w0:{n:1,st:'dot',sp:540},w1:{n:2,st:'bolt',sp:560,gap:11},w2:{n:3,st:'star',sp:500,fan:.2},w3:{n:4,st:'spear',sp:700,fan:.06,gap:6},w4:{n:1,st:'fire',sp:420,splash:1},w5:{n:3,st:'miss',sp:400,fan:.5,home:1,splash:1}};
const SH={w0:[8,40],w1:[12,60],w2:[16,80],w3:[20,110],w4:[28,160],w5:[34,200]};
const wn=n=>n==1?'طلقة':n==2?'طلقتان':n+' طلقات';
const PA={f1:'🎯 كل 5 طلقات ضربة قوية',f2:'🐌 يُبطئ طلقات الزعيم',f3:'❤️ قلب إضافي لك',f4:'🛡️ يحميك من إصابة واحدة',f5:'⭐ نجوم أكثر بعد الفوز',f6:'⚡ تطلق أسرع',f7:'💚 يعيد لك قلباً كل 15 ثانية',f8:'💪 ضربات أقوى'};
const CATS=[['s','🚀','السفن'],['h','🎩','أزياء'],['f','🦁','رفاق'],['b','🌌','خلفيات'],['t','✨','مؤثرات'],['w','🔫','أسلحة']];
const it=id=>IT.find(x=>x[0]==id);
function norm(x){x.own=(x.own||['s0']).map(o=>typeof o=='number'?'s'+o:o);const e=x.eq||{};if(!e.s)e.s=typeof x.ship=='number'?'s'+x.ship:(x.ship||'s0');if(!x.own.includes('w0'))x.own.push('w0');if(!e.w)e.w='w0';x.eq=e;return x}
P.forEach(norm);
const eqv=()=>Object.assign({},p.eq,PV);
const bgc=()=>{const e=p?eqv():{},b=e.b&&it(e.b);return b?b[3]:'#0b1033,#2a1b6e'};
const show=(h,t,k,keep)=>{document.body.classList.remove('qz');const y=window.scrollY;setWx(k);document.body.style.background=k?`linear-gradient(${WX[k].bg}) fixed`:(p?`linear-gradient(${bgc()}) fixed`:'');$('app').innerHTML='<div class="pg'+(keep?' nf':'')+'"><div class="pi'+(t?' ptop':'')+'">'+h+'</div></div>';window.scrollTo(0,keep?y:0)};
const td=()=>new Date().toDateString();

/* ===== الطقس: لكل كوكب طقس مختلف (يتكرر كل 8 كواكب) ===== */
const WX={sun:{n:'مشمس',e:'☀️',bg:'#1e78d6,#6cc3f5'},cloud:{n:'غائم',e:'☁️',bg:'#3b4a6b,#8794ad'},rain:{n:'ماطر',e:'🌧️',bg:'#15233f,#35507c'},storm:{n:'رعد وبرق',e:'⛈️',bg:'#0a0a1f,#2b2250'},snow:{n:'ثلجي',e:'❄️',bg:'#2a4d8f,#a9d6f5'},wind:{n:'رياح وأوراق',e:'🍂',bg:'#7a3e12,#e0a040'},night:{n:'ليل وشهب',e:'🌠',bg:'#050520,#1a1050'},rainbow:{n:'قوس قزح',e:'🌈',bg:'#5b3fb0,#f5a6d6'}};
const WK=['sun','cloud','rain','storm','snow','wind','night','rainbow'];
const wk=n=>WK[((n||1)-1)%8];
let WXK=null,WXT=null;
const rr=(a,b)=>a+Math.random()*(b-a);
const parts=(n,f)=>{let s='';for(let i=0;i<n;i++)s+=f(i);return s};
const LF=()=>`left:${rr(0,100).toFixed(1)}%`;
function wxHtml(k){
 if(k=='sun')return '<div class="sunb">☀️</div>'+parts(3,i=>`<span class="cl" style="top:${8+i*14}%;animation-duration:${30+i*12}s;animation-delay:-${i*11}s">☁️</span>`);
 if(k=='cloud')return parts(5,i=>`<span class="cl big" style="top:${i*16}%;animation-duration:${26+i*7}s;animation-delay:-${i*9}s">☁️</span>`);
 if(k=='rain'||k=='storm')return parts(k=='storm'?60:46,()=>`<i class="dr" style="${LF()};animation-duration:${rr(.45,.85).toFixed(2)}s;animation-delay:-${rr(0,1).toFixed(2)}s"></i>`)+(k=='storm'?'<div class="fl2"></div><svg class="bolt" viewBox="0 0 40 120"><path d="M24 0L6 64h14L10 120 36 48H22L34 0Z" fill="#fff6a8"/></svg>':'');
 if(k=='snow')return parts(32,()=>`<span class="sn" style="${LF()};font-size:${rr(12,26).toFixed(0)}px;animation-duration:${rr(5,10).toFixed(1)}s;animation-delay:-${rr(0,8).toFixed(1)}s">❄</span>`);
 if(k=='wind')return parts(14,i=>`<span class="lf" style="top:${rr(0,90).toFixed(0)}%;animation-duration:${rr(3,6).toFixed(1)}s;animation-delay:-${rr(0,6).toFixed(1)}s;font-size:${rr(20,34).toFixed(0)}px">${['🍂','🍁','🍃'][i%3]}</span>`);
 if(k=='night')return parts(34,()=>`<i class="stt" style="${LF()};top:${rr(0,95).toFixed(0)}%;animation-delay:-${rr(0,3).toFixed(1)}s"></i>`)+parts(3,i=>`<i class="sh" style="left:${rr(40,100).toFixed(0)}%;top:${rr(0,30).toFixed(0)}%;animation-delay:${i*2.3}s"></i>`);
 if(k=='rainbow')return '<div class="rbw"></div>'+parts(14,()=>`<span class="spk" style="${LF()};animation-duration:${rr(5,9).toFixed(1)}s;animation-delay:-${rr(0,8).toFixed(1)}s">✨</span>`);
 return ''}
function thunder(){const d=$('wx');if(!d||WXK!='storm')return;const b=d.querySelector('.bolt');if(b)b.style.left=R(5,80)+'%';
 d.classList.add('zap');setTimeout(()=>d.classList.remove('zap'),450);setTimeout(()=>{tn(55,0,1.2,'sawtooth',.12);tn(80,.06,.9,'square',.05)},500)}
function setWx(k){if(k==WXK)return;WXK=k;clearInterval(WXT);let d=$('wx');
 if(!k){if(d)d.remove();return}
 if(!d){d=document.createElement('div');d.id='wx';document.body.appendChild(d)}
 d.className='wx '+k;d.innerHTML=wxHtml(k);
 if(k=='storm'){setTimeout(thunder,1500);WXT=setInterval(thunder,5000)}}

/* الأصوات: مولّدة برمجياً */
function au(){try{if(!AC)AC=new(window.AudioContext||window.webkitAudioContext)();if(AC.state=='suspended')AC.resume()}catch(e){}return AC}
function tn(f,t,d,ty,v){const c=au();if(!c||!S.m)return;const o=c.createOscillator(),g=c.createGain(),s=c.currentTime+t;
 o.type=ty||'sine';o.frequency.value=f;g.gain.setValueAtTime(v||.15,s);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g);g.connect(c.destination);o.start(s);o.stop(s+d)}
const SF={tap:()=>tn(660,0,.07,'triangle',.1),
 ok:()=>[523,659,784,1046].forEach((f,i)=>tn(f,i*.09,.25,'triangle')),
 bad:()=>{tn(330,0,.2,'sine',.12);tn(262,.18,.3,'sine',.1)},
 star:()=>{tn(1319,0,.12,'sine');tn(1760,.08,.2,'sine')},
 win:()=>[523,659,784,659,784,1046,1319].forEach((f,i)=>tn(f,i*.12,.3,'square',.07)),
 buy:()=>[880,1175,1568].forEach((f,i)=>tn(f,i*.07,.15,'triangle')),
  shoot:()=>{tn(1250,0,.05,'sawtooth',.022);tn(720,.025,.06,'sawtooth',.018)},
  hit:()=>tn(170,0,.07,'square',.05),
  pet:()=>[660,880,1320,1760].forEach((f,i)=>tn(f,i*.06,.18,'triangle',.12)),
  bossdie:()=>{[240,200,160,120,90,60].forEach((f,i)=>tn(f,i*.11,.32,'sawtooth',.13));tn(50,0,1,'square',.1);[523,659,784,1046,1319,1568].forEach((f,i)=>tn(f,.75+i*.1,.35,'triangle',.12))}};
const sfx=k=>{try{SF[k]()}catch(e){}};
const PEN=[262,294,330,392,440,523];
setInterval(()=>{if(S.m&&AC&&document.visibilityState=='visible')tn(PEN[R(0,5)],0,.8,'sine',.03)},700);
document.addEventListener('pointerdown',()=>au(),{once:true});
const hv=(ms,amp)=>{try{if(S.v===0)return;if(window.Android&&Android.v)Android.v(ms,amp||150);else if(navigator.vibrate)navigator.vibrate(ms)}catch(e){}};
const hpat=a=>{try{if(S.v===0)return;if(window.Android&&Android.pat)Android.pat(a.join(','));else if(navigator.vibrate)navigator.vibrate(a)}catch(e){}};
function vibt(){S.v=S.v===0?1:0;try{localStorage.setItem('mhs',JSON.stringify(S))}catch(e){}$('vb').textContent=S.v===0?'📴':'📳';if(S.v!==0)hv(40,180);sfx('tap')}
function mute(){S.m=S.m?0:1;try{localStorage.setItem('mhs',JSON.stringify(S))}catch(e){}$('mt').textContent=S.m?'🔊':'🔇';sfx('tap')}
function say(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ar-SA';u.rate=.85;speechSynthesis.speak(u)}catch(e){}}
const sp=()=>say(G.q.t.replace('+','زائد').replace('\u2212','ناقص').replace('×','ضرب').replace('= ?','يساوي كم؟'));

function boom(n=8){const e=(p&&p.eq.t&&it(p.eq.t)[2])||'⭐',a=[e,'🎉','⭐','✨'];
 for(let i=0;i<n*2;i++){const s=document.createElement('span');s.className='cf';s.textContent=a[R(0,3)];s.style.left=R(0,95)+'%';s.style.animationDelay=R(0,400)+'ms';document.body.appendChild(s);setTimeout(()=>s.remove(),2300)}}
const mas=(m='h',h)=>kid({mood:{h:'happy',t:'think'}[m]||m,h:h===undefined?(p&&eqv().h):h});
function hero(pv,sm){const e=Object.assign({},p.eq,pv||{}),sh=it(e.s)||IT[0];
 return `<div class="hero${sm?' sm':''}"><span class="tr">${e.t?it(e.t)[2].repeat(3):''}</span><div class="hs">${shipSvg(sh)}</div><div class="hk">${kid({mood:'happy',h:e.h})}</div>${e.f?petSvg(e.f,'pet'):''}</div>`}

const dots=(n,c)=>{const i='<i class="'+c+'"></i>';return ('<span class="tn">'+i.repeat(10)+'</span>').repeat(Math.floor(n/10))+i.repeat(n%10)};
const vis=(n,em)=>n<10?em.repeat(n):('<span class="tn e">'+em.repeat(10)+'</span>').repeat(Math.floor(n/10))+em.repeat(n%10);
function nl(a,b,op){const pl=op=='+',lo=pl?a:a-b,hi=pl?a+b:a,sp=hi-lo,X0=22,X1=278,xs=v=>X0+(v-lo)/sp*(X1-X0),sm=sp<=12,ink='#3a2200';
 let s=`<svg class="nl" viewBox="0 0 300 84"><path d="M8 52H292" stroke="${ink}" stroke-width="3"/>`;
 const tx=(x,t,b)=>`<text x="${x}" y="76" fill="${ink}" font-size="${b?18:14}" font-weight="${b?900:400}" text-anchor="middle">${t}</text>`;
 const hop=(x1,x2)=>`<path d="M${x1} 46Q${(x1+x2)/2} 6 ${x2} 46" stroke="#fff" stroke-width="3.5" fill="none" stroke-linecap="round"/>`;
 const st=pl?lo:hi,en=pl?hi:lo;
 if(sm){for(let v=lo;v<=hi;v++)s+=`<path d="M${xs(v)} 46V58" stroke="${ink}" stroke-width="2"/>`+tx(xs(v),v==en?'?':v,v==st);
  for(let i=0;i<b;i++){const f=pl?lo+i:hi-i;s+=hop(xs(f),xs(pl?f+1:f-1))}}
 else{s+=`<path d="M${xs(lo)} 46V58M${xs(hi)} 46V58" stroke="${ink}" stroke-width="2"/>`+tx(xs(st),st,1)+tx(xs(en),'?')+hop(xs(st),xs(en))+`<text x="150" y="16" fill="${ink}" font-size="13" text-anchor="middle">${b}</text>`}
 return s+'</svg>'}
function mk(p,qi){const g=p.g;p.ws=p.ws||{};const ops=(g==0||p.planet<(g==1?3:2))?['+','\u2212']:['+','\u2212','×'],base=g==0?[6,4]:[35,30,35];
 const wt=ops.map((o,i)=>base[i]*(1+Math.min(3,p.ws[o]||0)*.5));let r=Math.random()*wt.reduce((x,y)=>x+y,0),op=ops[ops.length-1];
 for(let i=0;i<ops.length;i++){if(r<wt[i]){op=ops[i];break}r-=wt[i]}
 const L=Math.max(0,(p.planet-1)*.7+(qi||0)*.15+(p.d-3)*.5-((p.ws[op]||0)>=2?1.2:0)),cl=(v,lo,hi)=>Math.max(lo,Math.min(hi,Math.round(v)));let a,b,ans,e=null;
 const em=EM[R(0,7)],em2=EM[R(0,7)];
 if(g==0){const m=cl(5+L,5,20);
  if(op=='+'){a=R(1,m-1);b=R(1,m-a);ans=a+b;e=vis(a,em)+' ➕ '+vis(b,em2)}
  else{a=R(2,m);b=R(1,a-1);ans=a-b;e=vis(a-b,em)+'<span style="opacity:.3">'+vis(b,em)+'</span>'}}
 else{const am=g==1?cl(15+L*3.5,15,100):cl(80+L*35,80,1000);
  if(op=='+'){a=R(2,am-2);b=R(1,am-a);ans=a+b;if(ans<=100)e='<div class="tw">'+dots(a,'c1')+' ➕ '+dots(b,'c2')+'</div>'}
  else if(op=='\u2212'){a=R(3,am);b=R(1,a-1);ans=a-b;if(a<=100)e='<div class="tw">'+dots(ans,'c1')+dots(b,'c3')+'</div>'}
  else{const tm=g==1?cl(3+L*.5,3,10):cl(5+L*.6,5,12);
   a=R(2,tm);b=R(2,g==1?Math.min(tm,5):tm);ans=a*b;
   if(g==1&&ans<=30)e=Array.from({length:a},()=>em.repeat(b)).join(' ┃ ')}}
 const h=op=='+'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الأمام.`:
  op=='\u2212'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الخلف.`:
  `${a} مجموعات، في كل مجموعة ${b}. اجمع ${b} في كل مرة: `+Array.from({length:a},(_,i)=>b*(i+1)).join('، ');
 const s=new Set([ans]);const sp=Math.max(3,Math.round(ans*.2));let n=0;
 while(s.size<4&&n++<200){const v=ans+R(-sp,sp);if(v>=0)s.add(v)}
 let k=0;while(s.size<4)s.add(ans+(++k));
 return{k:a+op+b,t:`${a} ${op} ${b} = ?`,a:ans,e,h,o:op,nl:op=='×'?'':nl(a,b,op),c:[...s].sort(()=>Math.random()-.5)}}
function gen(p,qi){p.recent=p.recent||[];let q;
 for(let t=0;t<30;t++){q=mk(p,qi);if(!p.recent.includes(q.k))break}
 p.recent.push(q.k);if(p.recent.length>40)p.recent.shift();return q}

function profiles(){SC='p';p=null;let h=`<h1>🚀 أبطال كوكب الأرقام</h1>${mas()}<p>من سيلعب اليوم؟</p>`;
 P.forEach((x,i)=>h+=`<button onclick="sel(${i})">${esc(x.name)} ⭐${x.stars}</button><br>`);
 h+='<div class="card"><p>لاعب جديد</p><input id="nm" maxlength="12" placeholder="الاسم" style="font-size:22px;padding:10px;border-radius:14px;border:0;text-align:center"><br><p>العمر:</p>';
 AGES.forEach((a,i)=>h+=`<button class="alt" onclick="add(${i})"><span dir="ltr">${a}</span></button>`);
 show(h+'</div>')}
function add(g){const name=($('nm').value||'').trim()||'بطل';P.push(norm({name,g,stars:0,planet:1,d:1,own:['s0'],eq:{s:'s0'},recent:[],st:0,wr:0}));save();sel(P.length-1)}
function sel(i){p=P[i];sfx('tap');home()}
function home(){SC='h';PV={};clearTimeout(TT);IV.forEach(clearInterval);IV=[];if(p.bp)return boss();const w=p.wish&&it(p.wish);let wh='';{const iv=p.inv||{},t=[iv.hp?'❤️ قلب إضافي':'',iv.sh?'🛡️ درع':'',p.x2?'⭐×2 للكوكب القادم':''].filter(Boolean).join(' · ');if(t)wh+=`<div class="card">🎒 جاهز لك: ${t}</div>`}
 if(w&&!p.own.includes(w[0]))wh+=`<div class="card">🎯 أمنيتي: ${w[2]} ${w[5]}<div class="bar"><i style="width:${Math.min(100,p.stars/w[4]*100)}%"></i></div><p>${p.stars>=w[4]?'تقدر تشتريها الآن! 🎉':'باقي '+(w[4]-p.stars)+' ⭐'}</p></div>`;
 show(`${hero()}<h2>${esc(p.name)}</h2><p class="st">⭐ ${p.stars}</p><p>المهمة: ${pname(p.planet)}</p>${wh}${p.day!=td()?'<button class="gift" onclick="daily()">🎁 هدية اليوم</button><br>':''}<button class="big" onclick="start()">ابدأ المهمة 🌍</button><br><button class="alt" onclick="shop()">المتجر 🛒</button><button class="alt" onclick="badges()">أوسمتي 🏅</button><button class="alt" onclick="profiles()">تبديل اللاعب 👦</button>`)}
function daily(){SC='d';const y=new Date(Date.now()-864e5).toDateString();p.streak=p.day==y?(p.streak||0)+1:1;p.day=td();p.bs=Math.max(p.bs||0,p.streak);const n=p.streak%7==0?10:2+Math.min(p.streak%7,4);p.stars+=n;save();sfx('win');boom();
 show(`<h1>🎁 هدية اليوم!</h1>${mas('cheer')}<div class="card"><p>حصلت على ${n} ⭐</p><p>أيام متتالية: ${p.streak} 🔥<br>باقي ${7-p.streak%7} أيام للهدية الكبرى</p></div><button onclick="home()">رائع!</button>`)}
function start(){SC='q';G={i:0,ok:0,tr:0,lock:0,cb:0,q:gen(p,0)};sfx('tap');ask()}
function ask(){const q=G.q,pd=[0,1,2,3,4].map(i=>`<i class="${i<G.i?'d':i==G.i?'c':''}"></i>`).join('');
 let h=`<div class="qs"><div class="qh"><button class="alt qbk" onclick="home()">⬅</button><span class="qpn">${WX[wk(p.planet)].e} ${pname(p.planet)}</span><span class="qdt">${pd}</span>${G.cb>=2?'<span class="qcb">🔥'+G.cb+'</span>':''}</div>${p.d>=4?'<div class="tmr" id="tmr"><i id="tmi"></i></div>':''}<div class="qm" id="qm"><div id="kd" class="kd">${mas('think')}</div>`;
 if(q.e)h+=`<div class="card emo">${q.e}</div>`;
 h+=`<div class="q">${q.t}</div>${window.speechSynthesis?'<button class="alt" onclick="sp()">🔊</button>':''}<div id="fb"></div></div><div class="ans">`;
 q.c.forEach(v=>h+=`<button id="b${v}" onclick="ans(${v})">${v}</button>`);
 show(h+'</div></div>',0,wk(p.planet));document.body.classList.add('qz');qtimer()}
function qtimer(){clearInterval(IV[2]);if(p.d<4)return;let t=30;IV[2]=setInterval(()=>{t--;const i=$('tmi');if(!i){clearInterval(IV[2]);return}
 i.style.width=(t/30*100)+'%';if(t<=8)$('tmr').classList.add('lo');
 if(t<=0){clearInterval(IV[2]);if(!G.lock&&$('fb')){$('qm').classList.add('hs');$('fb').innerHTML='<div class="hint">⏰ لا بأس، خذ وقتك! 💡 '+G.q.h+'</div>'}}},1000)}
function ans(v){const q=G.q;if(G.lock)return;
 if(v==q.a){G.lock=1;clearInterval(IV[2]);const f=G.tr==0;let g=0;
  if(f){G.ok++;G.cb++;p.tot=(p.tot||0)+1;p.ws=p.ws||{};p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);g=G.cb>=3?2:1;p.stars+=g;p.st=(p.st||0)+1;if(p.st>=3&&p.d<5){p.d++;p.st=0}}
  hv(22,90);$('b'+v).classList.add('ok');$('kd').innerHTML=mas(f?'cheer':'happy');sfx(f?'ok':'star');if(f)boom(g>1?6:2);
  $('fb').innerHTML=`<div class="hint ok">${f?PR[R(0,4)]+' '+'⭐'.repeat(g):'جميل! وصلت للإجابة 👏'}</div>`;setTimeout(next,1100)}
 else{G.tr++;G.cb=0;p.ws=p.ws||{};p.ws[q.o]=(p.ws[q.o]||0)+1;p.st=0;p.wr=(p.wr||0)+1;if(p.wr>=2&&p.d>1){p.d--;p.wr=0}sfx('bad');hpat([0,35,50,35]);
  $('kd').innerHTML=mas('oops');const b=$('b'+v);b.style.opacity=.35;b.disabled=true;
  if(G.tr==1){$('qm').classList.add('hs');$('fb').innerHTML=`<div class="hint">حاول مرة أخرى، أنت تستطيع! 💪<br>${q.h}${q.nl}</div>`}
  else{$('qm').classList.add('hs');G.lock=1;clearInterval(IV[2]);$('b'+q.a).classList.add('ok');$('fb').innerHTML=`<div class="hint">الإجابة هي ${q.a} — في المرة القادمة ستنجح! 🌟</div><button onclick="next()">التالي ➡</button>`}}
 save()}
function next(){if(G.nx)return;G.nx=1;const pg=document.querySelector('.pg');if(pg)pg.classList.add('fo');setTimeout(()=>{if(SC!='q')return;G.i++;if(G.i>=5)return end();G.q=gen(p,G.i);G.tr=0;G.lock=0;G.nx=0;ask()},230)}
function end(){SC='e';const w=G.ok>=3,pf=G.ok==5;if(w){let bn=3+(pf?2:0);if(p.x2){bn*=2;p.x2=0}p.stars+=bn;p.planet++;if(pf)p.pf=(p.pf||0)+1}save();sfx(w?'win':'tap');if(w)boom(12);
 const mg=w&&(p.planet-1)%3==0;
 if(mg){p.bp=1;save();return show(`<h1>🎉 أنقذت الكوكب!</h1>${mas('cheer')}<div class="card"><p>أجبت ${G.ok} من 5 من أول محاولة</p></div><h1>👹 الزعيم يقترب!</h1><p>استعد للمعركة! 🔫</p>`),TT=setTimeout(boss,2800)}
 show(`<h1>${w?'🎉 أنقذت الكوكب!':'🌙 اقتربت!'}</h1>${mas(w?'cheer':'oops')}<div class="card"><p>أجبت ${G.ok} من 5 من أول محاولة</p><p>${w?(pf?'كوكب مثالي! 5 نجوم ⭐⭐⭐⭐⭐':'حصلت على 3 نجوم ⭐⭐⭐'):'لنحاول من جديد بأسئلة جديدة'}</p></div><button class="big" onclick="${w?'trip()':'start()'}">${w?'الكوكب التالي 🚀':'حاول مرة أخرى'}</button><button class="alt" onclick="home()">الرئيسية</button>`)}
function trip(){SC='t';sfx('star');const e=p.eq,sh=it(e.s)||IT[0],w=WX[wk(p.planet)];
 show(`<div class="trip"><h2>🚀 في الطريق إلى ${pname(p.planet)}</h2><p>${w.e} الطقس هناك: ${w.n}</p><div class="card">💡 ${FACTS[R(0,FACTS.length-1)]}</div><div class="rs"><div class="rk">${kid({mood:'cheer',h:e.h})}</div>${shipSvg(sh)}<div class="rt">${e.t?it(e.t)[2].repeat(3):''}</div>${e.f?petSvg(e.f,'pet'):''}</div></div>`,0,wk(p.planet));
 TT=setTimeout(start,3200)}
function mini(){SC='m';let n=0,t=15;show(`<h2>🌟 اصطد النجوم!</h2><p>الوقت: <b id="tm">15</b> &nbsp; ⭐ <b id="mc">0</b></p><div id="ar" class="ar"></div>`);
 const iv=IV[0]=setInterval(()=>{const s=document.createElement('span');s.textContent='⭐';s.className='mst';s.style.left=R(5,80)+'%';s.style.top=R(5,82)+'%';
  s.onpointerdown=()=>{n++;$('mc').textContent=n;sfx('star');s.remove()};$('ar').appendChild(s);setTimeout(()=>s.remove(),1500)},550);
 const tk=IV[1]=setInterval(()=>{t--;$('tm').textContent=t;if(t<=0){clearInterval(iv);clearInterval(tk);const g=Math.min(5,Math.floor(n/2));p.stars+=g;save();sfx('win');boom(10);
  show(`<h1>🎉 برافو!</h1><div class="card"><p>التقطت ${n} نجمة</p><p>مكافأتك ${g} ⭐</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button>`)}},1000)}
function pv(i){PV[it(i)[1]]=i;sfx('tap');shop()}
const pvw=x=>x[1]=='s'?shipSvg(x):x[1]=='h'?kid({crop:1,h:x[0]}):x[1]=='f'?petSvg(x[0],'pet'):x[1]=='w'?wpSvg(x[0]):`<span class="fxv">${x[2]}</span>`;
function shop(m=''){const re=SC=='s';SC='s';const e=p.eq;
 let h=`<div class="stk"><div class="top"><button class="alt bk" onclick="home()">⬅ رجوع</button><span class="st">⭐ ${p.stars}</span></div>${hero(PV,1)}</div><p class="msg">${m||'اضغط على أي غرض لتجربته 👀'}</p><div class="tabs">`+CATS.map(c=>`<button class="tb ${c[0]==TAB?'':'alt'}" onclick="TAB='${c[0]}';sfx('tap');shop()">${c[1]}<br><small>${c[2]}</small></button>`).join('')+'</div><div class="ig">';
 IT.filter(x=>x[1]==TAB).forEach(x=>{const own=p.own.includes(x[0]),on=e[TAB]==x[0];
  h+=`<div class="card it"><div class="pvw${PV[TAB]==x[0]?' try':''}" style="${TAB=='b'?'background:linear-gradient('+x[3]+')':''}" onclick="pv('${x[0]}')">${pvw(x)}</div><b>${x[5]}</b><br>${x[1]=='w'?'<small>💥 '+WD[x[0]]+' · '+wn(WP[x[0]].n)+'</small><br>':''}${x[1]=='f'?'<small>'+PA[x[0]]+'</small><br>':''}`+(own?`<button class="${on?'ok':''}" onclick="eq('${x[0]}')">${on?'مستخدم ✔':'استخدم'}</button>`:`<button class="${p.stars<x[4]?'alt':''}" onclick="buy('${x[0]}')">اشترِ ⭐${x[4]}</button>`)+'</div>'});
 show(h+`<div class="card it"><div class="pvw"><span class="fxv">🎁</span></div><b>صندوق مفاجآت</b><br><button onclick="box()">${p.fbd!=td()?'افتح مجاناً 🎁':'افتح ⭐10'}</button></div></div><button class="alt" onclick="home()">⬅ رجوع</button>`,1,undefined,re)}
function buy(i){const x=it(i);if(p.stars<x[4]){sfx('bad');return shop('اجمع المزيد من النجوم ⭐')}p.stars-=x[4];p.own.push(i);p.eq[x[1]]=i;delete PV[x[1]];if(p.wish==i)p.wish=null;save();sfx('buy');boom(8);shop('🎉 مبروك! '+x[5])}
function eq(i){const c=it(i)[1];delete PV[c];p.eq[c]=(p.eq[c]==i&&c!='s'&&c!='w')?null:i;save();sfx('tap');shop()}
function wish(i){p.wish=p.wish==i?null:i;save();sfx('tap');shop()}
const RAR={c:{n:'هدية عادية',col:'#9ad1ff'},u:{n:'هدية مميزة',col:'#c77dff'},r:{n:'هدية نادرة',col:'#ffd23f'}};
function prize(r){p.inv=p.inv||{hp:0,sh:0};
 if(r=='c'){if(Math.random()<.5){const n=R(6,12);p.stars+=n;return{e:'⭐',t:n+' نجمة',d:'أضيفت إلى رصيدك'}}p.inv.hp=1;return{e:'❤️',t:'قلب إضافي',d:'يحميك أكثر في معركة الزعيم القادمة'}}
 if(r=='u'){const x=Math.random();if(x<.4){p.inv.sh=1;return{e:'🛡️',t:'درع',d:'يصدّ إصابة واحدة في معركة الزعيم القادمة'}}if(x<.75){p.x2=1;return{e:'⭐',t:'نجوم مضاعفة',d:'مكافأة الكوكب القادم ×2'}}const n=R(15,25);p.stars+=n;return{e:'🌟',t:n+' نجمة',d:'أضيفت إلى رصيدك'}}
 const l=IT.filter(x=>!p.own.includes(x[0])&&x[4]>0&&x[4]<=30);
 if(l.length){const x=l[R(0,l.length-1)];p.own.push(x[0]);return{it:x,t:x[5],d:'غرض جديد في متجرك! ابحث عنه في «'+CATS.find(c=>c[0]==x[1])[2]+'»'}}
 const n=R(30,40);p.stars+=n;return{e:'💎',t:n+' نجمة',d:'جائزة كبرى!'}}
function box(){const free=p.fbd!=td();if(!free&&p.stars<10){sfx('bad');return shop('تحتاج 10 نجوم ⭐')}
 if(free)p.fbd=td();else p.stars-=10;
 const x=Math.random(),r=x<.07?'r':x<.35?'u':'c',z=prize(r),R_=RAR[r];save();SC='g';
 show('<div class="gbx"><div class="gb shake" id="gb">🎁</div><p id="gm">يُفتح الصندوق...</p></div>');sfx('tap');hpat([0,40,60,40,60,40,60,40,60,40]);
 setTimeout(()=>{if(SC!='g')return;sfx(r=='c'?'star':'win');boom(r=='r'?16:r=='u'?10:6);hv(r=='r'?220:r=='u'?140:70,r=='r'?255:r=='u'?180:120);
  show(`<div class="gbx"><div class="gr" style="--c:${R_.col}"><span class="rb">${R_.n}</span>${z.it?`<div class="pvw">${pvw(z.it)}</div>`:`<div class="gi">${z.e}</div>`}<h2>${z.t}</h2><p>${z.d}</p></div><button class="big" onclick="shop()">رائع!</button></div>`)},1300)}

/* ===== الأوسمة ===== */
const BD=[['🔥','بطل 7 أيام','7 أيام متتالية',p=>(p.bs||0)>=7],['⚡','سريع البديهة','كوكب بلا أخطاء',p=>(p.pf||0)>=1],['🧠','عبقري','5 كواكب مثالية',p=>(p.pf||0)>=5],['🪐','مستكشف','أنقذ 10 كواكب',p=>p.planet>10],['👹','قاهر الوحوش','اهزم زعيماً',p=>(p.bw||0)>=1],['🏆','صائد الزعماء','اهزم 5 زعماء',p=>(p.bw||0)>=5],['🛍️','جامع','امتلك 10 أغراض',p=>p.own.length>=10],['🔢','حاسب ماهر','100 إجابة صحيحة',p=>(p.tot||0)>=100]];
function chk(){if(!p)return;const e=BD.map(b=>b[3](p));
 if(!p.bd){p.bd=e.map((v,i)=>v?i:-1).filter(i=>i>=0);return}
 BD.forEach((b,i)=>{if(e[i]&&!p.bd.includes(i)){p.bd.push(i);toast(b)}})}
function toast(b){sfx('win');const d=document.createElement('div');d.className='bt';d.style.top=(14+document.querySelectorAll('.bt').length*62)+'px';
 d.innerHTML='<b>'+b[0]+'</b>وسام جديد: '+b[1];document.body.appendChild(d);setTimeout(()=>d.remove(),3500)}
function badges(){SC='a';show('<h1>🏅 أوسمتي</h1><div class="bgs">'+BD.map(b=>`<div class="card bd${b[3](p)?'':' lk'}"><span>${b[0]}</span><b>${b[1]}</b><small>${b[2]}</small></div>`).join('')+'</div><button onclick="home()">⬅ رجوع</button>',1)}

/* ===== معركة الزعيم (لعبة أركيد) ===== */
let B=null;
const WC={w0:'#4cc9f0',w1:'#ffe066',w2:'#7bd957',w3:'#c77dff',w4:'#ff9f1c',w5:'#ff4d6d'};
function boss(){SC='b';const k=Math.max(1,Math.floor((p.planet-1)/3)),f=p.eq.f;let wid=p.eq.w||'w0';const iv=p.inv||{},mh=3+(f=='f3'?1:0)+(iv.hp?1:0),ivs=!!iv.sh;p.inv={hp:0,sh:0};save();B={k,f};sfx('tap');
 const owned=IT.filter(x=>x[1]=='w'&&p.own.includes(x[0]));
 show(`<div class="bxw full"><canvas id="cv"></canvas><div class="bmsg" id="bm"></div><div class="bhud"><button class="alt" id="bw"></button>${f?`<button id="bp">${it(f)[2]}<small>مساعدة</small><i class="cdv" style="height:0"></i></button>`:'<span></span>'}</div></div>`,0,'night',1);
 window.scrollTo(0,0);
 const cv=$('cv'),c=cv.getContext('2d'),W=360,H=Math.max(500,Math.min(820,Math.round(360*innerHeight/innerWidth)));cv.width=W;cv.height=H;
 const img=(s,w,h)=>{const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s.replace('<svg ',`<svg width="${w}" height="${h}" `));return i};
 const shI=img(shipSvg(it(p.eq.s)||IT[0]),130,140),mI=img(monsterSvg(k),200,190);
 const dm=()=>WD[wid]+(f=='f8'?3:0),tier=()=>+wid[1],pe=f&&it(f)?it(f)[2]:'',MY=H-130;
 const me={x:180,tx:180,h:mh,inv:2,sh:f=='f4'||ivs,cd:0,n:0,crit:0,rf:0,slow:0},bs={x:180,y:105,hp:100+60*k,max:100+60*k,t:0,cd:1.5,fl:0},bl=[],eb=[],pc=[],ab={cd:0,max:15};
 let last=performance.now(),heal=0,done=0,dy=0,dyt=0,lh=0,shk=0;const fx=[];
 const msg=t=>{const m=$('bm');if(!m)return;m.textContent=t;m.style.opacity=1;clearTimeout(msg.t);msg.t=setTimeout(()=>{if(m)m.style.opacity=0},1500)};
 const updW=()=>{$('bw').innerHTML=`${it(wid)[2]}<small>💥${dm()}</small>`};updW();
 $('bw').onclick=()=>{if(done||dy)return;if(owned.length<2){msg('اشترِ سلاحاً آخر من المتجر 🛒');return sfx('bad')}
  const i=owned.findIndex(x=>x[0]==wid);wid=owned[(i+1)%owned.length][0];p.eq.w=wid;save();sfx('tap');updW();msg(it(wid)[2]+' '+it(wid)[5])};
 if(f)$('bp').onclick=()=>{if(ab.cd>0||done||dy)return;ab.cd=ab.max;sfx('pet');let t='';
  if(f=='f1'){me.crit=6;t='🎯 الطلقات القادمة ×3!'}
  else if(f=='f2'){me.slow=5;t='👃 الزعيم تباطأ!'}
  else if(f=='f3'){me.h=Math.min(mh,me.h+1);t='❤ قلب إضافي!'}
  else if(f=='f4'){me.sh=true;t='🛡 درع جاهز!'}
  else if(f=='f5'){eb.length=0;me.inv=2.5;t='🦊 اختفاء مؤقت!'}
  else if(f=='f6'){me.rf=5;t='⚡ إطلاق سريع!'}
  else if(f=='f7'){me.h=mh;t='🦁 شفاء كامل!'}
  else if(f=='f8'){bs.hp-=dm()*10;bs.fl=.3;t='🐻 ضربة الدب!'}
  msg(t)};
 const mv=e=>{const r=cv.getBoundingClientRect();me.tx=Math.max(28,Math.min(W-28,(e.clientX-r.left)/r.width*W))};
 cv.style.touchAction='none';cv.onpointerdown=mv;cv.onpointermove=mv;
 const fin=ok=>{done=1;clearInterval(IV[0]);ok?bwin():blose(wid)};
 const die=()=>{dy=1;sfx('bossdie');hpat([0,120,40,160,40,220,40,320]);shk=.8;eb.length=0;bl.length=0;const cs=['#ffd23f','#ff6b35','#fff','#ff4d6d','#4cc9f0'];for(let i=0;i<46;i++)pc.push({x:bs.x,y:bs.y+55,vx:R(-240,240),vy:R(-300,120),l:1,r:R(3,8),c:cs[R(0,4)]})};
 const hitfx=t=>{const T=+t.w[1],w=WP[t.w],now=performance.now();
   for(let i=0;i<3+T*2;i++)pc.push({x:t.x,y:t.y,vx:R(-130,130),vy:R(-170,40),l:1,r:R(2,4)+T*.4,c:WC[t.w]});
   if(w.splash){fx.push({x:t.x,y:t.y,r:10,l:1,c:WC[t.w]});shk=T>=5?.4:.25}
   if(now-lh>110){lh=now;sfx('hit');hv(14+T*7,60+T*34)}};
  const upd=dt=>{const sf=me.slow>0?.35:1;
  me.x+=(me.tx-me.x)*Math.min(1,dt*14);me.inv=Math.max(0,me.inv-dt);bs.fl=Math.max(0,bs.fl-dt);me.slow=Math.max(0,me.slow-dt);me.rf=Math.max(0,me.rf-dt);ab.cd=Math.max(0,ab.cd-dt);
  me.cd-=dt;if(me.cd<=0){me.cd=(f=='f6'?.22:.32)*(me.rf>0?.5:1);me.n++;const cr=(f=='f1'&&me.n%5==0)||me.crit>0;if(me.crit>0)me.crit--;
    {const w=WP[wid],n=w.n,per=(cr?dm()*3:dm())/n;for(let i=0;i<n;i++){const o=i-(n-1)/2,an=o*(w.fan||0);bl.push({x:me.x+o*(w.gap||0),y:MY-30,vx:Math.sin(an)*w.sp,vy:-Math.cos(an)*w.sp,d:per,cr,st:w.st,w:wid,a:0,h:w.home})}
     const hh=SH[wid];hv(hh[0],hh[1])}sfx('shoot')}
  if(f=='f7'){heal+=dt;if(heal>=15&&me.h<mh){me.h++;heal=0}}
  bs.t+=dt*sf;const sp=1+(1-bs.hp/bs.max)*.8;bs.x=180+Math.sin(bs.t*.9*sp)*110;bs.y=105+Math.sin(bs.t*1.7)*10;
  bs.cd-=dt*sf;if(bs.cd<=0){const ph=bs.hp<bs.max*.5;bs.cd=(ph?.8:1.1)*(f=='f2'?1.35:1)/sp;const v=190+k*8,n=ph?3:1;
   const kk=k%3;
    if(kk==0){for(let i=0;i<n;i++){const an=(i-(n-1)/2)*.4;eb.push({x:bs.x,y:bs.y+55,vx:n==1?(me.x-bs.x)*.3:Math.sin(an)*v,vy:Math.cos(an)*v})}}
    else if(kk==1){const m=ph?5:3;for(let i=0;i<m;i++){const an=(i-(m-1)/2)*.32;eb.push({x:bs.x,y:bs.y+55,vx:Math.sin(an)*v,vy:Math.cos(an)*v*.85})}}
    else{eb.push({x:bs.x,y:bs.y+55,vx:(me.x-bs.x)*.3,vy:v});for(let i=0;i<(ph?3:2);i++)eb.push({x:R(30,W-30),y:bs.y+40,vx:0,vy:v*.8})}}
  for(let i=bl.length-1;i>=0;i--){const t=bl[i];
    if(t.h&&bs.hp>0){t.vx+=((bs.x-t.x)*3-t.vx)*Math.min(1,dt*4)}
    t.x+=t.vx*dt;t.y+=t.vy*dt;t.a+=dt*9;
    if(t.st=='miss'&&Math.random()<.7)pc.push({x:t.x,y:t.y+14,vx:R(-15,15),vy:40,l:.6,r:R(3,5),c:'rgba(225,225,225,.65)',g:0,fd:1.6});
    if(t.st=='fire'&&Math.random()<.8)pc.push({x:t.x+R(-6,6),y:t.y+12,vx:R(-20,20),vy:60,l:.5,r:R(2,5),c:'#ff9f1c',g:0,fd:2});
    if(Math.abs(t.x-bs.x)<62&&t.y<bs.y+70&&t.y>bs.y-10){bs.hp-=t.d;bs.fl=.1;bl.splice(i,1);hitfx(t)}else if(t.y<-30||t.x<-30||t.x>W+30)bl.splice(i,1)}
   for(let i=pc.length-1;i>=0;i--){const q=pc[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=(q.g===undefined?300:q.g)*dt;q.l-=dt*(q.fd||2.2);if(q.l<=0)pc.splice(i,1)}
   for(let i=fx.length-1;i>=0;i--){const r=fx[i];r.r+=dt*260;r.l-=dt*2.2;if(r.l<=0)fx.splice(i,1)}
   shk=Math.max(0,shk-dt);
   for(let i=eb.length-1;i>=0;i--){const t=eb[i];t.x+=t.vx*dt*sf;t.y+=t.vy*dt*sf;
   if(Math.abs(t.x-me.x)<24&&Math.abs(t.y-MY)<28){eb.splice(i,1);if(me.inv<=0){if(me.sh){me.sh=false;hv(60,120)}else{me.h--;hpat([0,90,40,140])}me.inv=1.5;sfx('bad')}}
   else if(t.y>H+10||t.x<-10||t.x>W+10)eb.splice(i,1)}};
 const draw=()=>{c.clearRect(0,0,W,H);c.save();if(shk>0)c.translate(R(-5,5)*shk*3,R(-5,5)*shk*3);
  const sk=dy?Math.sin(dyt*60)*6:0;c.globalAlpha=dy?Math.max(0,1-dyt/.9):bs.fl>0?.55:1;c.drawImage(mI,bs.x-62+sk,bs.y-10,124,118);c.globalAlpha=1;
  bl.forEach(t=>{const col=WC[t.w],T=+t.w[1],x=t.x,y=t.y;c.shadowColor=col;c.shadowBlur=10+T*2;c.fillStyle=t.cr?'#fff':col;c.strokeStyle=t.cr?'#fff':col;
    if(t.st=='dot'){c.beginPath();c.ellipse(x,y,3+(t.cr?3:0),10,0,0,7);c.fill()}
    else if(t.st=='bolt'){c.lineWidth=3.5;c.lineJoin='round';c.beginPath();c.moveTo(x+2,y+14);c.lineTo(x-4,y+5);c.lineTo(x+3,y+1);c.lineTo(x-4,y-8);c.lineTo(x+1,y-15);c.stroke()}
    else if(t.st=='star'){c.save();c.translate(x,y);c.rotate(t.a);c.beginPath();for(let i=0;i<10;i++){const r=i%2?4:10,a=i*Math.PI/5;c.lineTo(Math.sin(a)*r,-Math.cos(a)*r)}c.closePath();c.fill();c.restore()}
    else if(t.st=='spear'){c.beginPath();c.moveTo(x,y-22);c.lineTo(x+4,y-4);c.lineTo(x,y+24);c.lineTo(x-4,y-4);c.closePath();c.fill();c.globalAlpha=.35;c.fillRect(x-1.5,y+24,3,26);c.globalAlpha=1}
    else if(t.st=='fire'){const r=15+R(-2,2),g=c.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,'#fff6c0');g.addColorStop(.45,'#ffb703');g.addColorStop(1,'rgba(255,60,0,.9)');c.fillStyle=t.cr?'#fff':g;c.beginPath();c.arc(x,y,r,0,7);c.fill()}
    else if(t.st=='miss'){c.save();c.translate(x,y);c.rotate(Math.atan2(t.vx,-t.vy));c.fillStyle=t.cr?'#fff':'#e8ecf5';c.beginPath();c.ellipse(0,0,5,13,0,0,7);c.fill();c.fillStyle=col;c.beginPath();c.moveTo(-5,6);c.lineTo(-10,15);c.lineTo(-3,11);c.closePath();c.fill();c.beginPath();c.moveTo(5,6);c.lineTo(10,15);c.lineTo(3,11);c.closePath();c.fill();c.beginPath();c.arc(0,-11,3,0,7);c.fill();c.fillStyle='#ffb703';c.beginPath();c.ellipse(0,17+R(0,3),3,5,0,0,7);c.fill();c.restore()}});
   fx.forEach(r=>{c.globalAlpha=Math.max(0,r.l);c.strokeStyle=r.c;c.lineWidth=4;c.shadowColor=r.c;c.shadowBlur=12;c.beginPath();c.arc(r.x,r.y,r.r,0,7);c.stroke()});c.globalAlpha=1;
  eb.forEach(t=>{c.fillStyle='#ff3b3b';c.shadowColor='#f00';c.shadowBlur=10;c.beginPath();c.arc(t.x,t.y,7,0,7);c.fill();c.fillStyle='#ffd0d0';c.beginPath();c.arc(t.x,t.y,3,0,7);c.fill()});
  c.shadowBlur=0;pc.forEach(q=>{if(q.l<=0)return;c.globalAlpha=Math.max(0,q.l);c.fillStyle=q.c;c.beginPath();c.arc(q.x,q.y,q.r,0,7);c.fill()});c.globalAlpha=1;
  if(me.inv<=0||Math.floor(me.inv*10)%2)c.drawImage(shI,me.x-30,MY-32,60,64);
  if(me.sh){c.strokeStyle='#7df9ff';c.lineWidth=3;c.beginPath();c.arc(me.x,MY,36,0,7);c.stroke()}
  c.font='24px sans-serif';c.textAlign='center';if(pe)c.fillText(pe,Math.max(20,Math.min(W-20,me.x+44)),MY+22);
  c.fillStyle='rgba(0,0,0,.5)';c.fillRect(20,50,W-40,14);c.fillStyle='#ff4d4d';c.fillRect(20,50,Math.max(0,(W-40)*bs.hp/bs.max),14);
  c.textAlign='right';c.font='20px sans-serif';c.fillText('❤'.repeat(Math.max(0,me.h)),W-10,34);
  const cd=$('bp');if(cd)cd.querySelector('.cdv').style.height=(ab.cd/ab.max*100)+'%';c.restore()};
 IV[0]=setInterval(()=>{if(done)return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
  if(!dy)upd(dt);else{dyt+=dt;pc.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=420*dt;q.l-=dt*.9});if(dyt>1.3){draw();return fin(1)}}
  draw();if(!dy){if(bs.hp<=0)die();else if(me.h<=0)fin(0)}},16)}
function bwin(){SC='e';hpat([0,60,60,60,60,180]);const n=8+B.k,r=Math.round(B.f=='f5'?n*1.5:n);p.stars+=r;p.bw=(p.bw||0)+1;p.bp=0;save();sfx('win');boom(14);
 show(`<h1>🏆 هزمت الزعيم!</h1>${mas('cheer')}<div class="card"><p>حصلت على ${r} ⭐</p><p>🔫 الزعماء القادمون أقوى — اشترِ سلاحاً أقوى!</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button><button class="alt" onclick="mini()">🎮 لعبة النجوم</button><button class="alt" onclick="shop()">المتجر 🛒</button>`)}
function blose(wid){SC='e';sfx('bad');const nx=IT.filter(x=>x[1]=='w'&&!p.own.includes(x[0])).sort((x,y)=>x[4]-y[4])[0];
 const tip=nx?(p.stars>=nx[4]?`عندك نجوم كافية لشراء ${nx[2]} ${nx[5]} بـ ${nx[4]} ⭐ — سلاح أقوى!`:`اجمع ${nx[4]-p.stars} ⭐ لتشتري ${nx[2]} ${nx[5]} وهو أقوى من سلاحك`):'سلاحك هو الأقوى! جرّب رفيقاً مناسباً 🐾';
 show(`<h1>👹 الزعيم قوي!</h1>${mas('oops')}<div class="card"><p>💡 ${tip}</p></div><button class="big" onclick="boss()">حاول مرة أخرى</button><button class="alt" onclick="shop()">🛒 المتجر</button>`)}
$('mt').textContent=S.m?'🔊':'🔇';$('vb').textContent=S.v===0?'📴':'📳';
profiles();
window.onBack=()=>{if(SC=='p')return false;if(p&&p.bp&&SC!='s')return true;clearTimeout(TT);if(SC=='h'){profiles();return true}home();return true};
