package com.mathheroes.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private Vibrator vib;

    /** جسر الاهتزاز: يُستدعى من اللعبة عبر Android.v(مدة، شدّة) و Android.pat("0,30,40,30"). */
    private class Bridge {
        @JavascriptInterface
        public void v(int ms, int amp) {
            if (vib == null || ms <= 0) return;
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    int a = Math.max(1, Math.min(255, amp));
                    vib.vibrate(VibrationEffect.createOneShot(ms, vib.hasAmplitudeControl() ? a : VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(ms);
                }
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public void pat(String csv) {
            if (vib == null || csv == null) return;
            try {
                String[] p = csv.split(",");
                long[] t = new long[p.length];
                for (int i = 0; i < p.length; i++) t[i] = Long.parseLong(p[i].trim());
                if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(t, -1));
                else vib.vibrate(t, -1);
            } catch (Exception e) { }
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#0b1033"));
        getWindow().setNavigationBarColor(Color.parseColor("#0b1033"));
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0b1033")));

        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0b1033"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                return true; // no external links for kids
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    /** الرجوع: نسأل اللعبة أولاً؛ إن عالجته (true) لا نغلق التطبيق. */
    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(function(){try{return window.onBack?window.onBack():false}catch(e){return false}})()",
                value -> {
                    if (!"true".equals(value)) {
                        finish();
                    }
                });
    }
}
