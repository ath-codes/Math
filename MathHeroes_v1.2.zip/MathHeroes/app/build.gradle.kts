plugins { id("com.android.application") }
android {
    namespace = "com.mathheroes.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mathheroes.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
