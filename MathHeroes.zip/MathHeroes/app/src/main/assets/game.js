const $=id=>document.getElementById(id);
const R=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const esc=s=>s.replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
let P=[],p=null,G=null,S={m:1},AC,TAB='s';
try{P=JSON.parse(localStorage.getItem('mh')||'[]')}catch(e){}
try{S=JSON.parse(localStorage.getItem('mhs')||'{"m":1}')}catch(e){}
const save=()=>{try{localStorage.setItem('mh',JSON.stringify(P))}catch(e){}};
const AGES=['5-6','7-8','9'];
const NAMES=['نورا','لمعان','سديم','هلال','شعاع','ضياء','مجرّة','نيزك','قمر','سنا','ريان','بريق','أُفق','سحر','وميض','زُهرة','نجمة','بدر','رحاب','فجر'];
const EM=['🍎','⭐','👾','🍉','🪐','🍪','🐟','🎈'];
const pname=n=>'كوكب '+NAMES[(n-1)%20]+' '+n;
const PR=['أحسنت يا بطل!','رائع!','ممتاز!','عبقري!','مذهل!'];
const FACTS=['الشمس نجمة وليست كوكباً ☀️','في الفضاء لا يوجد صوت، لأنه لا يوجد هواء 🤫','زحل له حلقات جميلة من الجليد والصخور 🪐','يتسع داخل الشمس أكثر من مليون كوكب أرض!','القمر يبتعد عن الأرض قليلاً كل عام 🌙'];
const IT=[
['s0','s','🚀','#ffd23f',0,'الذهبي'],['s1','s','🛸','#2ec4b6',5,'الطبق'],['s2','s','🛰️','#ff6b9d',8,'القمر'],['s3','s','🚁','#7bd957',10,'المروحية'],['s4','s','🚀','#9b5de5',12,'البنفسجي'],['s5','s','✈️','#00bbf9',15,'النفاثة'],['s6','s','🛸','#f15bb5',20,'الوردي'],['s7','s','🚀','#ff9f1c',25,'الناري'],
['h1','h','🎀','',5,'فيونكة'],['h2','h','🧢','',6,'كاب'],['h3','h','🕶️','',8,'نظارة'],['h4','h','🎧','',10,'سماعات'],['h5','h','🎩','',12,'قبعة'],['h6','h','👑','',25,'تاج'],
['f1','f','🐱','',6,'قطة'],['f2','f','🐶','',6,'كلب'],['f3','f','🐰','',8,'أرنب'],['f4','f','🐼','',10,'باندا'],['f5','f','🦊','',12,'ثعلب'],['f6','f','🐸','',12,'ضفدع'],['f7','f','🦄','',20,'حصان سحري'],['f8','f','🐲','',30,'تنين'],
['b1','b','🌌','#3a0ca3,#f72585',8,'غروب'],['b2','b','🌊','#023e8a,#00b4d8',8,'محيط'],['b3','b','🌳','#1b4332,#52b788',10,'غابة'],['b4','b','🍭','#ff70a6,#ff9770',12,'حلوى'],['b5','b','🏆','#7f5539,#ffb703',18,'ذهب'],
['t1','t','✨','',8,'بريق'],['t2','t','💖','',10,'قلوب'],['t3','t','🔥','',12,'نار'],['t4','t','🌈','',15,'قوس قزح'],['t5','t','❄️','',15,'ثلج']];
const CATS=[['s','🚀','السفن'],['h','🎩','أزياء'],['f','🐾','رفاق'],['b','🌌','خلفيات'],['t','✨','مؤثرات']];
const it=id=>IT.find(x=>x[0]==id);
function norm(x){x.own=(x.own||['s0']).map(o=>typeof o=='number'?'s'+o:o);const e=x.eq||{};if(!e.s)e.s=typeof x.ship=='number'?'s'+x.ship:(x.ship||'s0');x.eq=e;return x}
P.forEach(norm);
const bgc=()=>{const b=p.eq.b&&it(p.eq.b);return b?b[3]:'#0b1033,#2a1b6e'};
const show=h=>{document.body.style.background=p?`linear-gradient(${bgc()}) fixed`:'';$('app').innerHTML='<div class="pg">'+h+'</div>'};
const td=()=>new Date().toDateString();

/* الأصوات: مولّدة برمجياً */
function au(){try{if(!AC)AC=new(window.AudioContext||window.webkitAudioContext)();if(AC.state=='suspended')AC.resume()}catch(e){}return AC}
function tn(f,t,d,ty,v){const c=au();if(!c||!S.m)return;const o=c.createOscillator(),g=c.createGain(),s=c.currentTime+t;
 o.type=ty||'sine';o.frequency.value=f;g.gain.setValueAtTime(v||.15,s);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g);g.connect(c.destination);o.start(s);o.stop(s+d)}
const SF={tap:()=>tn(660,0,.07,'triangle',.1),
 ok:()=>[523,659,784,1046].forEach((f,i)=>tn(f,i*.09,.25,'triangle')),
 bad:()=>{tn(330,0,.2,'sine',.12);tn(262,.18,.3,'sine',.1)},
 star:()=>{tn(1319,0,.12,'sine');tn(1760,.08,.2,'sine')},
 win:()=>[523,659,784,659,784,1046,1319].forEach((f,i)=>tn(f,i*.12,.3,'square',.07)),
 buy:()=>[880,1175,1568].forEach((f,i)=>tn(f,i*.07,.15,'triangle'))};
const sfx=k=>{try{SF[k]()}catch(e){}};
const PEN=[262,294,330,392,440,523];
setInterval(()=>{if(S.m&&AC&&document.visibilityState=='visible')tn(PEN[R(0,5)],0,.8,'sine',.03)},700);
document.addEventListener('pointerdown',()=>au(),{once:true});
function mute(){S.m=S.m?0:1;try{localStorage.setItem('mhs',JSON.stringify(S))}catch(e){}$('mt').textContent=S.m?'🔊':'🔇';sfx('tap')}
function say(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ar-SA';u.rate=.85;speechSynthesis.speak(u)}catch(e){}}
const sp=()=>say(G.q.t.replace('+','زائد').replace('\u2212','ناقص').replace('×','ضرب').replace('= ?','يساوي كم؟'));

function boom(n=8){const e=(p&&p.eq.t&&it(p.eq.t)[2])||'⭐',a=[e,'🎉','⭐','✨'];
 for(let i=0;i<n*2;i++){const s=document.createElement('span');s.className='cf';s.textContent=a[R(0,3)];s.style.left=R(0,95)+'%';s.style.animationDelay=R(0,400)+'ms';document.body.appendChild(s);setTimeout(()=>s.remove(),2300)}}
const mas=(m='h')=>`<svg class="mas" viewBox="0 0 100 100" width="100" height="100"><line x1="50" y1="12" x2="50" y2="24" stroke="#fff" stroke-width="4"/><circle cx="50" cy="10" r="6" fill="#ff6b9d"/><circle cx="50" cy="56" r="38" fill="#fff4d6"/><rect x="22" y="38" width="56" height="34" rx="17" fill="#2b2a6b"/><circle cx="38" cy="54" r="${m=='t'?4:6}" fill="#7df9ff"/><circle cx="62" cy="54" r="${m=='t'?4:6}" fill="#7df9ff"/><path d="${m=='t'?'M40 66q10-6 20 0':'M40 64q10 9 20 0'}" stroke="#7df9ff" stroke-width="3" fill="none"/></svg>`;
function hero(){const e=p.eq,sh=it(e.s)||IT[0];
 return `<div class="hero"><span class="tr">${e.t?it(e.t)[2].repeat(2):''}</span><div class="ship" style="background:${sh[3]}">${sh[2]}</div><div class="avw">${e.h?`<span class="hat">${it(e.h)[2]}</span>`:''}${mas()}</div>${e.f?`<span class="pet">${it(e.f)[2]}</span>`:''}</div>`}

function mk(p){const g=p.g,d=p.d;let op,a,b,ans,e=null;
 const em=EM[R(0,7)],em2=EM[R(0,7)];
 if(g==0){const m=[5,8,10,15,20][d-1];
  if(Math.random()<.6){op='+';a=R(1,m-1);b=R(1,m-a);ans=a+b;e=em.repeat(a)+' ➕ '+em2.repeat(b)}
  else{op='−';a=R(2,m);b=R(1,a-1);ans=a-b;e=em.repeat(a-b)+'<span style="opacity:.3">'+em.repeat(b)+'</span>'}}
 else{const r=Math.random();
  const am=g==1?[20,30,50,80,100][d-1]:[100,200,300,500,1000][d-1];
  if(r<.35){op='+';a=R(2,am-2);b=R(1,am-a);ans=a+b}
  else if(r<.65){op='−';a=R(3,am);b=R(1,a-1);ans=a-b}
  else{op='×';const tm=g==1?[3,5,6,8,10][d-1]:[6,8,10,12,12][d-1];
   a=R(2,tm);b=R(2,g==1?Math.min(tm,5):tm);ans=a*b;
   if(g==1&&ans<=30)e=Array.from({length:a},()=>em.repeat(b)).join(' ┃ ')}}
 const h=op=='+'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الأمام.`:
  op=='−'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الخلف.`:
  `${a} مجموعات، في كل مجموعة ${b}. اجمع ${b} في كل مرة: `+Array.from({length:a},(_,i)=>b*(i+1)).join('، ');
 const s=new Set([ans]);const sp=Math.max(3,Math.round(ans*.2));let n=0;
 while(s.size<4&&n++<200){const v=ans+R(-sp,sp);if(v>=0)s.add(v)}
 let k=0;while(s.size<4)s.add(ans+(++k));
 return{k:a+op+b,t:`${a} ${op} ${b} = ?`,a:ans,e,h,c:[...s].sort(()=>Math.random()-.5)}}
function gen(p){p.recent=p.recent||[];let q;
 for(let t=0;t<30;t++){q=mk(p);if(!p.recent.includes(q.k))break}
 p.recent.push(q.k);if(p.recent.length>40)p.recent.shift();return q}

function profiles(){p=null;let h=`<h1>🚀 أبطال كوكب الأرقام</h1>${mas()}<p>من سيلعب اليوم؟</p>`;
 P.forEach((x,i)=>h+=`<button onclick="sel(${i})">${esc(x.name)} ⭐${x.stars}</button><br>`);
 h+='<div class="card"><p>لاعب جديد</p><input id="nm" maxlength="12" placeholder="الاسم" style="font-size:22px;padding:10px;border-radius:14px;border:0;text-align:center"><br><p>العمر:</p>';
 AGES.forEach((a,i)=>h+=`<button class="alt" onclick="add(${i})"><span dir="ltr">${a}</span></button>`);
 show(h+'</div>')}
function add(g){const name=($('nm').value||'').trim()||'بطل';P.push(norm({name,g,stars:0,planet:1,d:1,own:['s0'],eq:{s:'s0'},recent:[],st:0,wr:0}));save();sel(P.length-1)}
function sel(i){p=P[i];sfx('tap');home()}
function home(){const w=p.wish&&it(p.wish);let wh='';
 if(w&&!p.own.includes(w[0]))wh=`<div class="card">🎯 أمنيتي: ${w[2]} ${w[5]}<div class="bar"><i style="width:${Math.min(100,p.stars/w[4]*100)}%"></i></div><p>${p.stars>=w[4]?'تقدر تشتريها الآن! 🎉':'باقي '+(w[4]-p.stars)+' ⭐'}</p></div>`;
 show(`${hero()}<h2>${esc(p.name)}</h2><p class="st">⭐ ${p.stars}</p><p>المهمة: ${pname(p.planet)}</p>${wh}${p.day!=td()?'<button class="gift" onclick="daily()">🎁 هدية اليوم</button><br>':''}<button class="big" onclick="start()">ابدأ المهمة 🌍</button><br><button class="alt" onclick="shop()">المتجر 🛒</button><button class="alt" onclick="profiles()">تبديل اللاعب 👦</button>`)}
function daily(){const y=new Date(Date.now()-864e5).toDateString();p.streak=p.day==y?(p.streak||0)+1:1;p.day=td();const n=p.streak%7==0?10:2+Math.min(p.streak%7,4);p.stars+=n;save();sfx('win');boom();
 show(`<h1>🎁 هدية اليوم!</h1>${mas()}<div class="card"><p>حصلت على ${n} ⭐</p><p>أيام متتالية: ${p.streak} 🔥<br>باقي ${7-p.streak%7} أيام للهدية الكبرى</p></div><button onclick="home()">رائع!</button>`)}
function start(){G={i:0,ok:0,tr:0,lock:0,cb:0,q:gen(p)};sfx('tap');ask()}
function ask(){const q=G.q;let h=`<p>${pname(p.planet)} ${G.cb>=2?'🔥×'+G.cb:''}</p><div class="bar"><i style="width:${G.i*20}%"></i></div><p>سؤال ${G.i+1} من 5</p>`;
 if(q.e)h+=`<div class="card emo">${q.e}</div>`;
 h+=`<div class="q">${q.t}</div>${window.speechSynthesis?'<button class="alt" onclick="sp()">🔊</button>':''}<div id="fb"></div><div class="ans">`;
 q.c.forEach(v=>h+=`<button id="b${v}" onclick="ans(${v})">${v}</button>`);
 show(h+'</div><p><button class="alt" onclick="home()">⬅ رجوع</button></p>')}
function ans(v){const q=G.q;if(G.lock)return;
 if(v==q.a){G.lock=1;const f=G.tr==0;let g=0;
  if(f){G.ok++;G.cb++;g=G.cb>=3?2:1;p.stars+=g;p.st=(p.st||0)+1;if(p.st>=3&&p.d<5){p.d++;p.st=0}}
  $('b'+v).classList.add('ok');sfx(f?'ok':'star');if(f)boom(g>1?6:2);
  $('fb').innerHTML=`<div class="hint ok">${f?PR[R(0,4)]+' '+'⭐'.repeat(g):'جميل! وصلت للإجابة 👏'}</div>`;setTimeout(next,1100)}
 else{G.tr++;G.cb=0;p.st=0;p.wr=(p.wr||0)+1;if(p.wr>=2&&p.d>1){p.d--;p.wr=0}sfx('bad');
  const b=$('b'+v);b.style.opacity=.35;b.disabled=true;
  if(G.tr==1)$('fb').innerHTML=`<div class="hint">حاول مرة أخرى، أنت تستطيع! 💪<br>${q.h}</div>`;
  else{G.lock=1;$('b'+q.a).classList.add('ok');$('fb').innerHTML=`<div class="hint">الإجابة هي ${q.a} — في المرة القادمة ستنجح! 🌟</div><button onclick="next()">التالي ➡</button>`}}
 save()}
function next(){G.i++;if(G.i>=5)return end();G.q=gen(p);G.tr=0;G.lock=0;ask()}
function end(){const w=G.ok>=3,pf=G.ok==5;if(w){p.stars+=3+(pf?2:0);p.planet++}save();sfx(w?'win':'tap');if(w)boom(12);
 const mg=w&&(p.planet-1)%3==0;
 show(`<h1>${w?'🎉 أنقذت الكوكب!':'🌙 اقتربت!'}</h1>${mas(w?'h':'t')}<div class="card"><p>أجبت ${G.ok} من 5 من أول محاولة</p><p>${w?(pf?'كوكب مثالي! 5 نجوم ⭐⭐⭐⭐⭐':'حصلت على 3 نجوم ⭐⭐⭐'):'لنحاول من جديد بأسئلة جديدة'}</p></div>${mg?'<button class="gift" onclick="mini()">🎮 لعبة الاستراحة</button><br>':''}<button class="big" onclick="${w?'trip()':'start()'}">${w?'الكوكب التالي 🚀':'حاول مرة أخرى'}</button><button class="alt" onclick="home()">الرئيسية</button>`)}
function trip(){sfx('star');show(`<h2>🚀 في الطريق إلى ${pname(p.planet)}</h2><div class="sky"><span class="fly">🚀</span></div><div class="card">💡 ${FACTS[R(0,FACTS.length-1)]}</div>`);setTimeout(start,2600)}
function mini(){let n=0,t=15;show(`<h2>🌟 اصطد النجوم!</h2><p>الوقت: <b id="tm">15</b> &nbsp; ⭐ <b id="mc">0</b></p><div id="ar" class="ar"></div>`);
 const iv=setInterval(()=>{const s=document.createElement('span');s.textContent='⭐';s.className='mst';s.style.left=R(5,80)+'%';s.style.top=R(5,82)+'%';
  s.onpointerdown=()=>{n++;$('mc').textContent=n;sfx('star');s.remove()};$('ar').appendChild(s);setTimeout(()=>s.remove(),1500)},550);
 const tk=setInterval(()=>{t--;$('tm').textContent=t;if(t<=0){clearInterval(iv);clearInterval(tk);const g=Math.min(5,Math.floor(n/2));p.stars+=g;save();sfx('win');boom(10);
  show(`<h1>🎉 برافو!</h1><div class="card"><p>التقطت ${n} نجمة</p><p>مكافأتك ${g} ⭐</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button>`)}},1000)}
function shop(m=''){const e=p.eq;let h=`<h2>🛒 المتجر</h2><p class="st">⭐ ${p.stars}</p><p>${m}</p><div class="tabs">`+CATS.map(c=>`<button class="tb ${c[0]==TAB?'':'alt'}" onclick="TAB='${c[0]}';sfx('tap');shop()">${c[1]}<br><small>${c[2]}</small></button>`).join('')+'</div>';
 IT.filter(x=>x[1]==TAB).forEach(x=>{const own=p.own.includes(x[0]),on=e[TAB]==x[0];
  h+=`<div class="card it"><div class="ship" style="background:${TAB=='b'?'linear-gradient('+x[3]+')':(x[3]||'rgba(255,255,255,.2)')}">${x[2]}</div><br><b>${x[5]}</b><br>`+(own?`<button class="${on?'ok':''}" onclick="eq('${x[0]}')">${on?'مستخدم ✔':'استخدم'}</button>`:`<button class="${p.stars<x[4]?'alt':''}" onclick="buy('${x[0]}')">اشترِ ⭐${x[4]}</button><button class="alt" onclick="wish('${x[0]}')">${p.wish==x[0]?'🎯':'🤍'}</button>`)+'</div>'});
 show(h+`<div class="card"><div class="ship">🎁</div><br><b>صندوق مفاجآت</b><br><button onclick="box()">افتح ⭐10</button></div><button class="alt" onclick="home()">⬅ رجوع</button>`)}
function buy(i){const x=it(i);if(p.stars<x[4]){sfx('bad');return shop('اجمع المزيد من النجوم ⭐')}p.stars-=x[4];p.own.push(i);p.eq[x[1]]=i;if(p.wish==i)p.wish=null;save();sfx('buy');boom(8);shop('🎉 مبروك! '+x[5])}
function eq(i){const c=it(i)[1];p.eq[c]=(p.eq[c]==i&&c!='s')?null:i;save();sfx('tap');shop()}
function wish(i){p.wish=p.wish==i?null:i;save();sfx('tap');shop()}
function box(){if(p.stars<10){sfx('bad');return shop('تحتاج 10 نجوم ⭐')}p.stars-=10;const l=IT.filter(x=>!p.own.includes(x[0])&&x[4]<=25);let m;
 if(l.length&&Math.random()<.8){const x=l[R(0,l.length-1)];p.own.push(x[0]);m='🎁 حصلت على '+x[2]+' '+x[5]+'!'}else{const g=R(5,15);p.stars+=g;m='🎁 نجوم إضافية: '+g+' ⭐'}
 save();sfx('win');boom(10);shop(m)}
$('mt').textContent=S.m?'🔊':'🔇';
profiles();
