const $=id=>document.getElementById(id);
const R=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const esc=s=>s.replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
let P=[],p=null,G=null,S={m:1},AC,TAB='s',SC='p',PV={},TT,IV=[];
try{P=JSON.parse(localStorage.getItem('mh')||'[]')}catch(e){}
try{S=JSON.parse(localStorage.getItem('mhs')||'{"m":1}')}catch(e){}
const save=()=>{try{localStorage.setItem('mh',JSON.stringify(P))}catch(e){}};
const AGES=['5-6','7-8','9'];
const NAMES=['نورا','لمعان','سديم','هلال','شعاع','ضياء','مجرّة','نيزك','قمر','سنا','ريان','بريق','أُفق','سحر','وميض','زُهرة','نجمة','بدر','رحاب','فجر'];
const EM=['🍎','⭐','👾','🍉','🪐','🍪','🐟','🎈'];
const pname=n=>'كوكب '+NAMES[(n-1)%20]+' '+n;
const PR=['أحسنت يا بطل!','رائع!','ممتاز!','عبقري!','مذهل!'];
const FACTS=['الشمس نجمة وليست كوكباً ☀️','في الفضاء لا يوجد صوت، لأنه لا يوجد هواء 🤫','زحل له حلقات جميلة من الجليد والصخور 🪐','يتسع داخل الشمس أكثر من مليون كوكب أرض!','القمر يبتعد عن الأرض قليلاً كل عام 🌙'];
const IT=[
['s0','s','🚀','#ffd23f',0,'الذهبي'],['s1','s','🛸','#2ec4b6',5,'الطبق'],['s2','s','🛰️','#ff6b9d',8,'القمر'],['s3','s','🚁','#7bd957',10,'المروحية'],['s4','s','🚀','#9b5de5',12,'البنفسجي'],['s5','s','✈️','#00bbf9',15,'النفاثة'],['s6','s','🛸','#f15bb5',20,'الوردي'],['s7','s','🚀','#ff9f1c',25,'الناري'],
['h1','h','🎀','',5,'فيونكة'],['h2','h','🧢','',6,'كاب'],['h3','h','🕶️','',8,'نظارة'],['h4','h','🎧','',10,'سماعات'],['h5','h','🎩','',12,'قبعة'],['h6','h','👑','',25,'تاج'],
['f1','f','🐱','',6,'قطة'],['f2','f','🐶','',6,'كلب'],['f3','f','🐰','',8,'أرنب'],['f4','f','🐼','',10,'باندا'],['f5','f','🦊','',12,'ثعلب'],['f6','f','🐸','',12,'ضفدع'],['f7','f','🦄','',20,'حصان سحري'],['f8','f','🐲','',30,'تنين'],
['b1','b','🌌','#3a0ca3,#f72585',8,'غروب'],['b2','b','🌊','#023e8a,#00b4d8',8,'محيط'],['b3','b','🌳','#1b4332,#52b788',10,'غابة'],['b4','b','🍭','#ff70a6,#ff9770',12,'حلوى'],['b5','b','🏆','#7f5539,#ffb703',18,'ذهب'],
['t1','t','✨','',8,'بريق'],['t2','t','💖','',10,'قلوب'],['t3','t','🔥','',12,'نار'],['t4','t','🌈','',15,'قوس قزح'],['t5','t','❄️','',15,'ثلج'],
['w0','w','🔫','',0,'مسدس الليزر'],['w1','w','⚡','',6,'صاعقة'],['w2','w','🏹','',12,'قوس النجوم'],['w3','w','🔱','',20,'رمح البلازما'],['w4','w','☄️','',32,'مدفع النيزك'],['w5','w','🚀','',50,'صاروخ المجرة']];
const WD={w0:2,w1:3,w2:4,w3:6,w4:9,w5:14};
const PA={f1:'🎯 أول ضربة ×3',f2:'👃 يحذف إجابة خاطئة',f3:'❤️ قلب إضافي',f4:'🛡️ درع يصدّ خطأ',f5:'⭐ مكافأة +50%',f6:'💪 ضرر +1',f7:'✨ يشفي قلباً كل 3 إصابات',f8:'🔥 ضرر +3'};
const CATS=[['s','🚀','السفن'],['h','🎩','أزياء'],['f','🐾','رفاق'],['b','🌌','خلفيات'],['t','✨','مؤثرات'],['w','🔫','أسلحة']];
const it=id=>IT.find(x=>x[0]==id);
function norm(x){x.own=(x.own||['s0']).map(o=>typeof o=='number'?'s'+o:o);const e=x.eq||{};if(!e.s)e.s=typeof x.ship=='number'?'s'+x.ship:(x.ship||'s0');if(!x.own.includes('w0'))x.own.push('w0');if(!e.w)e.w='w0';x.eq=e;return x}
P.forEach(norm);
const eqv=()=>Object.assign({},p.eq,PV);
const bgc=()=>{const e=p?eqv():{},b=e.b&&it(e.b);return b?b[3]:'#0b1033,#2a1b6e'};
const show=(h,t,k)=>{setWx(k);document.body.style.background=k?`linear-gradient(${WX[k].bg}) fixed`:(p?`linear-gradient(${bgc()}) fixed`:'');$('app').innerHTML='<div class="pg"><div class="pi'+(t?' ptop':'')+'">'+h+'</div></div>';window.scrollTo(0,0)};
const td=()=>new Date().toDateString();

/* ===== الطقس: لكل كوكب طقس مختلف (يتكرر كل 8 كواكب) ===== */
const WX={sun:{n:'مشمس',e:'☀️',bg:'#1e78d6,#6cc3f5'},cloud:{n:'غائم',e:'☁️',bg:'#3b4a6b,#8794ad'},rain:{n:'ماطر',e:'🌧️',bg:'#15233f,#35507c'},storm:{n:'رعد وبرق',e:'⛈️',bg:'#0a0a1f,#2b2250'},snow:{n:'ثلجي',e:'❄️',bg:'#2a4d8f,#a9d6f5'},wind:{n:'رياح وأوراق',e:'🍂',bg:'#7a3e12,#e0a040'},night:{n:'ليل وشهب',e:'🌠',bg:'#050520,#1a1050'},rainbow:{n:'قوس قزح',e:'🌈',bg:'#5b3fb0,#f5a6d6'}};
const WK=['sun','cloud','rain','storm','snow','wind','night','rainbow'];
const wk=n=>WK[((n||1)-1)%8];
let WXK=null,WXT=null;
const rr=(a,b)=>a+Math.random()*(b-a);
const parts=(n,f)=>{let s='';for(let i=0;i<n;i++)s+=f(i);return s};
const LF=()=>`left:${rr(0,100).toFixed(1)}%`;
function wxHtml(k){
 if(k=='sun')return '<div class="sunb">☀️</div>'+parts(3,i=>`<span class="cl" style="top:${8+i*14}%;animation-duration:${30+i*12}s;animation-delay:-${i*11}s">☁️</span>`);
 if(k=='cloud')return parts(5,i=>`<span class="cl big" style="top:${i*16}%;animation-duration:${26+i*7}s;animation-delay:-${i*9}s">☁️</span>`);
 if(k=='rain'||k=='storm')return parts(k=='storm'?60:46,()=>`<i class="dr" style="${LF()};animation-duration:${rr(.45,.85).toFixed(2)}s;animation-delay:-${rr(0,1).toFixed(2)}s"></i>`)+(k=='storm'?'<div class="fl2"></div><svg class="bolt" viewBox="0 0 40 120"><path d="M24 0L6 64h14L10 120 36 48H22L34 0Z" fill="#fff6a8"/></svg>':'');
 if(k=='snow')return parts(32,()=>`<span class="sn" style="${LF()};font-size:${rr(12,26).toFixed(0)}px;animation-duration:${rr(5,10).toFixed(1)}s;animation-delay:-${rr(0,8).toFixed(1)}s">❄</span>`);
 if(k=='wind')return parts(14,i=>`<span class="lf" style="top:${rr(0,90).toFixed(0)}%;animation-duration:${rr(3,6).toFixed(1)}s;animation-delay:-${rr(0,6).toFixed(1)}s;font-size:${rr(20,34).toFixed(0)}px">${['🍂','🍁','🍃'][i%3]}</span>`);
 if(k=='night')return parts(34,()=>`<i class="stt" style="${LF()};top:${rr(0,95).toFixed(0)}%;animation-delay:-${rr(0,3).toFixed(1)}s"></i>`)+parts(3,i=>`<i class="sh" style="left:${rr(40,100).toFixed(0)}%;top:${rr(0,30).toFixed(0)}%;animation-delay:${i*2.3}s"></i>`);
 if(k=='rainbow')return '<div class="rbw"></div>'+parts(14,()=>`<span class="spk" style="${LF()};animation-duration:${rr(5,9).toFixed(1)}s;animation-delay:-${rr(0,8).toFixed(1)}s">✨</span>`);
 return ''}
function thunder(){const d=$('wx');if(!d||WXK!='storm')return;const b=d.querySelector('.bolt');if(b)b.style.left=R(5,80)+'%';
 d.classList.add('zap');setTimeout(()=>d.classList.remove('zap'),450);setTimeout(()=>{tn(55,0,1.2,'sawtooth',.12);tn(80,.06,.9,'square',.05)},500)}
function setWx(k){if(k==WXK)return;WXK=k;clearInterval(WXT);let d=$('wx');
 if(!k){if(d)d.remove();return}
 if(!d){d=document.createElement('div');d.id='wx';document.body.appendChild(d)}
 d.className='wx '+k;d.innerHTML=wxHtml(k);
 if(k=='storm'){setTimeout(thunder,1500);WXT=setInterval(thunder,5000)}}

/* الأصوات: مولّدة برمجياً */
function au(){try{if(!AC)AC=new(window.AudioContext||window.webkitAudioContext)();if(AC.state=='suspended')AC.resume()}catch(e){}return AC}
function tn(f,t,d,ty,v){const c=au();if(!c||!S.m)return;const o=c.createOscillator(),g=c.createGain(),s=c.currentTime+t;
 o.type=ty||'sine';o.frequency.value=f;g.gain.setValueAtTime(v||.15,s);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g);g.connect(c.destination);o.start(s);o.stop(s+d)}
const SF={tap:()=>tn(660,0,.07,'triangle',.1),
 ok:()=>[523,659,784,1046].forEach((f,i)=>tn(f,i*.09,.25,'triangle')),
 bad:()=>{tn(330,0,.2,'sine',.12);tn(262,.18,.3,'sine',.1)},
 star:()=>{tn(1319,0,.12,'sine');tn(1760,.08,.2,'sine')},
 win:()=>[523,659,784,659,784,1046,1319].forEach((f,i)=>tn(f,i*.12,.3,'square',.07)),
 buy:()=>[880,1175,1568].forEach((f,i)=>tn(f,i*.07,.15,'triangle'))};
const sfx=k=>{try{SF[k]()}catch(e){}};
const PEN=[262,294,330,392,440,523];
setInterval(()=>{if(S.m&&AC&&document.visibilityState=='visible')tn(PEN[R(0,5)],0,.8,'sine',.03)},700);
document.addEventListener('pointerdown',()=>au(),{once:true});
function mute(){S.m=S.m?0:1;try{localStorage.setItem('mhs',JSON.stringify(S))}catch(e){}$('mt').textContent=S.m?'🔊':'🔇';sfx('tap')}
function say(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ar-SA';u.rate=.85;speechSynthesis.speak(u)}catch(e){}}
const sp=()=>say(G.q.t.replace('+','زائد').replace('\u2212','ناقص').replace('×','ضرب').replace('= ?','يساوي كم؟'));

function boom(n=8){const e=(p&&p.eq.t&&it(p.eq.t)[2])||'⭐',a=[e,'🎉','⭐','✨'];
 for(let i=0;i<n*2;i++){const s=document.createElement('span');s.className='cf';s.textContent=a[R(0,3)];s.style.left=R(0,95)+'%';s.style.animationDelay=R(0,400)+'ms';document.body.appendChild(s);setTimeout(()=>s.remove(),2300)}}
const mas=(m='h',h)=>kid({mood:{h:'happy',t:'think'}[m]||m,h:h===undefined?(p&&eqv().h):h});
function hero(pv,sm){const e=Object.assign({},p.eq,pv||{}),sh=it(e.s)||IT[0];
 return `<div class="hero${sm?' sm':''}"><span class="tr">${e.t?it(e.t)[2].repeat(3):''}</span><div class="hs">${shipSvg(sh)}</div><div class="hk">${kid({mood:'happy',h:e.h})}</div>${e.f?petSvg(e.f,'pet'):''}</div>`}

const dots=(n,c)=>{const i='<i class="'+c+'"></i>';return ('<span class="tn">'+i.repeat(10)+'</span>').repeat(Math.floor(n/10))+i.repeat(n%10)};
const vis=(n,em)=>n<10?em.repeat(n):('<span class="tn e">'+em.repeat(10)+'</span>').repeat(Math.floor(n/10))+em.repeat(n%10);
function nl(a,b,op){const pl=op=='+',lo=pl?a:a-b,hi=pl?a+b:a,sp=hi-lo,X0=22,X1=278,xs=v=>X0+(v-lo)/sp*(X1-X0),sm=sp<=12,ink='#3a2200';
 let s=`<svg class="nl" viewBox="0 0 300 84"><path d="M8 52H292" stroke="${ink}" stroke-width="3"/>`;
 const tx=(x,t,b)=>`<text x="${x}" y="76" fill="${ink}" font-size="${b?18:14}" font-weight="${b?900:400}" text-anchor="middle">${t}</text>`;
 const hop=(x1,x2)=>`<path d="M${x1} 46Q${(x1+x2)/2} 6 ${x2} 46" stroke="#fff" stroke-width="3.5" fill="none" stroke-linecap="round"/>`;
 const st=pl?lo:hi,en=pl?hi:lo;
 if(sm){for(let v=lo;v<=hi;v++)s+=`<path d="M${xs(v)} 46V58" stroke="${ink}" stroke-width="2"/>`+tx(xs(v),v==en?'?':v,v==st);
  for(let i=0;i<b;i++){const f=pl?lo+i:hi-i;s+=hop(xs(f),xs(pl?f+1:f-1))}}
 else{s+=`<path d="M${xs(lo)} 46V58M${xs(hi)} 46V58" stroke="${ink}" stroke-width="2"/>`+tx(xs(st),st,1)+tx(xs(en),'?')+hop(xs(st),xs(en))+`<text x="150" y="16" fill="${ink}" font-size="13" text-anchor="middle">${b}</text>`}
 return s+'</svg>'}
function mk(p){const g=p.g;p.ws=p.ws||{};const ops=g==0?['+','\u2212']:['+','\u2212','×'],base=g==0?[6,4]:[35,30,35];
 const wt=ops.map((o,i)=>base[i]*(1+Math.min(3,p.ws[o]||0)*.5));let r=Math.random()*wt.reduce((x,y)=>x+y,0),op=ops[ops.length-1];
 for(let i=0;i<ops.length;i++){if(r<wt[i]){op=ops[i];break}r-=wt[i]}
 const d=(p.ws[op]||0)>=2?Math.max(1,p.d-1):p.d;let a,b,ans,e=null;
 const em=EM[R(0,7)],em2=EM[R(0,7)];
 if(g==0){const m=[5,8,10,15,20][d-1];
  if(op=='+'){a=R(1,m-1);b=R(1,m-a);ans=a+b;e=vis(a,em)+' ➕ '+vis(b,em2)}
  else{a=R(2,m);b=R(1,a-1);ans=a-b;e=vis(a-b,em)+'<span style="opacity:.3">'+vis(b,em)+'</span>'}}
 else{const am=g==1?[20,30,50,80,100][d-1]:[100,200,300,500,1000][d-1];
  if(op=='+'){a=R(2,am-2);b=R(1,am-a);ans=a+b;if(ans<=100)e='<div class="tw">'+dots(a,'c1')+' ➕ '+dots(b,'c2')+'</div>'}
  else if(op=='\u2212'){a=R(3,am);b=R(1,a-1);ans=a-b;if(a<=100)e='<div class="tw">'+dots(ans,'c1')+dots(b,'c3')+'</div>'}
  else{const tm=g==1?[3,5,6,8,10][d-1]:[6,8,10,12,12][d-1];
   a=R(2,tm);b=R(2,g==1?Math.min(tm,5):tm);ans=a*b;
   if(g==1&&ans<=30)e=Array.from({length:a},()=>em.repeat(b)).join(' ┃ ')}}
 const h=op=='+'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الأمام.`:
  op=='\u2212'?`ابدأ من ${a} ثم عُدّ ${b} خطوات إلى الخلف.`:
  `${a} مجموعات، في كل مجموعة ${b}. اجمع ${b} في كل مرة: `+Array.from({length:a},(_,i)=>b*(i+1)).join('، ');
 const s=new Set([ans]);const sp=Math.max(3,Math.round(ans*.2));let n=0;
 while(s.size<4&&n++<200){const v=ans+R(-sp,sp);if(v>=0)s.add(v)}
 let k=0;while(s.size<4)s.add(ans+(++k));
 return{k:a+op+b,t:`${a} ${op} ${b} = ?`,a:ans,e,h,o:op,nl:op=='×'?'':nl(a,b,op),c:[...s].sort(()=>Math.random()-.5)}}
function gen(p){p.recent=p.recent||[];let q;
 for(let t=0;t<30;t++){q=mk(p);if(!p.recent.includes(q.k))break}
 p.recent.push(q.k);if(p.recent.length>40)p.recent.shift();return q}

function profiles(){SC='p';p=null;let h=`<h1>🚀 أبطال كوكب الأرقام</h1>${mas()}<p>من سيلعب اليوم؟</p>`;
 P.forEach((x,i)=>h+=`<button onclick="sel(${i})">${esc(x.name)} ⭐${x.stars}</button><br>`);
 h+='<div class="card"><p>لاعب جديد</p><input id="nm" maxlength="12" placeholder="الاسم" style="font-size:22px;padding:10px;border-radius:14px;border:0;text-align:center"><br><p>العمر:</p>';
 AGES.forEach((a,i)=>h+=`<button class="alt" onclick="add(${i})"><span dir="ltr">${a}</span></button>`);
 show(h+'</div>')}
function add(g){const name=($('nm').value||'').trim()||'بطل';P.push(norm({name,g,stars:0,planet:1,d:1,own:['s0'],eq:{s:'s0'},recent:[],st:0,wr:0}));save();sel(P.length-1)}
function sel(i){p=P[i];sfx('tap');home()}
function home(){SC='h';PV={};clearTimeout(TT);IV.forEach(clearInterval);IV=[];const w=p.wish&&it(p.wish);let wh='';
 if(w&&!p.own.includes(w[0]))wh=`<div class="card">🎯 أمنيتي: ${w[2]} ${w[5]}<div class="bar"><i style="width:${Math.min(100,p.stars/w[4]*100)}%"></i></div><p>${p.stars>=w[4]?'تقدر تشتريها الآن! 🎉':'باقي '+(w[4]-p.stars)+' ⭐'}</p></div>`;
 show(`${hero()}<h2>${esc(p.name)}</h2><p class="st">⭐ ${p.stars}</p><p>المهمة: ${pname(p.planet)}</p>${wh}${p.day!=td()?'<button class="gift" onclick="daily()">🎁 هدية اليوم</button><br>':''}<button class="big" onclick="start()">ابدأ المهمة 🌍</button><br><button class="alt" onclick="shop()">المتجر 🛒</button><button class="alt" onclick="badges()">أوسمتي 🏅</button><button class="alt" onclick="profiles()">تبديل اللاعب 👦</button>`)}
function daily(){SC='d';const y=new Date(Date.now()-864e5).toDateString();p.streak=p.day==y?(p.streak||0)+1:1;p.day=td();p.bs=Math.max(p.bs||0,p.streak);const n=p.streak%7==0?10:2+Math.min(p.streak%7,4);p.stars+=n;save();sfx('win');boom();
 show(`<h1>🎁 هدية اليوم!</h1>${mas('cheer')}<div class="card"><p>حصلت على ${n} ⭐</p><p>أيام متتالية: ${p.streak} 🔥<br>باقي ${7-p.streak%7} أيام للهدية الكبرى</p></div><button onclick="home()">رائع!</button>`)}
function start(){SC='q';G={i:0,ok:0,tr:0,lock:0,cb:0,q:gen(p)};sfx('tap');ask()}
function ask(){const q=G.q;let h=`<div id="kd" class="kd">${mas('think')}</div><p>${pname(p.planet)} ${WX[wk(p.planet)].e} ${G.cb>=2?'🔥×'+G.cb:''}</p><div class="bar"><i style="width:${G.i*20}%"></i></div><p>سؤال ${G.i+1} من 5</p>`;
 if(q.e)h+=`<div class="card emo">${q.e}</div>`;
 h+=`<div class="q">${q.t}</div>${window.speechSynthesis?'<button class="alt" onclick="sp()">🔊</button>':''}<div id="fb"></div><div class="ans">`;
 q.c.forEach(v=>h+=`<button id="b${v}" onclick="ans(${v})">${v}</button>`);
 show(h+'</div><p><button class="alt" onclick="home()">⬅ رجوع</button></p>',0,wk(p.planet))}
function ans(v){const q=G.q;if(G.lock)return;
 if(v==q.a){G.lock=1;const f=G.tr==0;let g=0;
  if(f){G.ok++;G.cb++;p.tot=(p.tot||0)+1;p.ws=p.ws||{};p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);g=G.cb>=3?2:1;p.stars+=g;p.st=(p.st||0)+1;if(p.st>=3&&p.d<5){p.d++;p.st=0}}
  $('b'+v).classList.add('ok');$('kd').innerHTML=mas(f?'cheer':'happy');sfx(f?'ok':'star');if(f)boom(g>1?6:2);
  $('fb').innerHTML=`<div class="hint ok">${f?PR[R(0,4)]+' '+'⭐'.repeat(g):'جميل! وصلت للإجابة 👏'}</div>`;setTimeout(next,1100)}
 else{G.tr++;G.cb=0;p.ws=p.ws||{};p.ws[q.o]=(p.ws[q.o]||0)+1;p.st=0;p.wr=(p.wr||0)+1;if(p.wr>=2&&p.d>1){p.d--;p.wr=0}sfx('bad');
  $('kd').innerHTML=mas('oops');const b=$('b'+v);b.style.opacity=.35;b.disabled=true;
  if(G.tr==1)$('fb').innerHTML=`<div class="hint">حاول مرة أخرى، أنت تستطيع! 💪<br>${q.h}${q.nl}</div>`;
  else{G.lock=1;$('b'+q.a).classList.add('ok');$('fb').innerHTML=`<div class="hint">الإجابة هي ${q.a} — في المرة القادمة ستنجح! 🌟</div><button onclick="next()">التالي ➡</button>`}}
 save()}
function next(){G.i++;if(G.i>=5)return end();G.q=gen(p);G.tr=0;G.lock=0;ask()}
function end(){SC='e';const w=G.ok>=3,pf=G.ok==5;if(w){p.stars+=3+(pf?2:0);p.planet++;if(pf)p.pf=(p.pf||0)+1}save();sfx(w?'win':'tap');if(w)boom(12);
 const mg=w&&(p.planet-1)%3==0;
 show(`<h1>${w?'🎉 أنقذت الكوكب!':'🌙 اقتربت!'}</h1>${mas(w?'cheer':'oops')}<div class="card"><p>أجبت ${G.ok} من 5 من أول محاولة</p><p>${w?(pf?'كوكب مثالي! 5 نجوم ⭐⭐⭐⭐⭐':'حصلت على 3 نجوم ⭐⭐⭐'):'لنحاول من جديد بأسئلة جديدة'}</p></div>${mg?'<button class="gift" onclick="boss()">👹 معركة الزعيم</button><br><button class="alt" onclick="mini()">🎮 لعبة النجوم</button><br>':''}<button class="big" onclick="${w?'trip()':'start()'}">${w?'الكوكب التالي 🚀':'حاول مرة أخرى'}</button><button class="alt" onclick="home()">الرئيسية</button>`)}
function trip(){SC='t';sfx('star');const e=p.eq,sh=it(e.s)||IT[0],w=WX[wk(p.planet)];
 show(`<div class="trip"><h2>🚀 في الطريق إلى ${pname(p.planet)}</h2><p>${w.e} الطقس هناك: ${w.n}</p><div class="card">💡 ${FACTS[R(0,FACTS.length-1)]}</div><div class="rs"><div class="rk">${kid({mood:'cheer',h:e.h})}</div>${shipSvg(sh)}<div class="rt">${e.t?it(e.t)[2].repeat(3):''}</div>${e.f?petSvg(e.f,'pet'):''}</div></div>`,0,wk(p.planet));
 TT=setTimeout(start,3200)}
function mini(){SC='m';let n=0,t=15;show(`<h2>🌟 اصطد النجوم!</h2><p>الوقت: <b id="tm">15</b> &nbsp; ⭐ <b id="mc">0</b></p><div id="ar" class="ar"></div>`);
 const iv=IV[0]=setInterval(()=>{const s=document.createElement('span');s.textContent='⭐';s.className='mst';s.style.left=R(5,80)+'%';s.style.top=R(5,82)+'%';
  s.onpointerdown=()=>{n++;$('mc').textContent=n;sfx('star');s.remove()};$('ar').appendChild(s);setTimeout(()=>s.remove(),1500)},550);
 const tk=IV[1]=setInterval(()=>{t--;$('tm').textContent=t;if(t<=0){clearInterval(iv);clearInterval(tk);const g=Math.min(5,Math.floor(n/2));p.stars+=g;save();sfx('win');boom(10);
  show(`<h1>🎉 برافو!</h1><div class="card"><p>التقطت ${n} نجمة</p><p>مكافأتك ${g} ⭐</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button>`)}},1000)}
function pv(i){PV[it(i)[1]]=i;sfx('tap');shop()}
const pvw=x=>x[1]=='s'?shipSvg(x):x[1]=='h'?kid({crop:1,h:x[0]}):x[1]=='f'?petSvg(x[0],'pet'):`<span class="fxv">${x[2]}</span>`;
function shop(m=''){SC='s';const e=p.eq;
 let h=`<div class="stk"><div class="top"><button class="alt bk" onclick="home()">⬅ رجوع</button><span class="st">⭐ ${p.stars}</span></div>${hero(PV,1)}</div><p class="msg">${m||'اضغط على أي غرض لتجربته 👀'}</p><div class="tabs">`+CATS.map(c=>`<button class="tb ${c[0]==TAB?'':'alt'}" onclick="TAB='${c[0]}';sfx('tap');shop()">${c[1]}<br><small>${c[2]}</small></button>`).join('')+'</div>';
 IT.filter(x=>x[1]==TAB).forEach(x=>{const own=p.own.includes(x[0]),on=e[TAB]==x[0];
  h+=`<div class="card it"><div class="pvw${PV[TAB]==x[0]?' try':''}" style="${TAB=='b'?'background:linear-gradient('+x[3]+')':''}" onclick="pv('${x[0]}')">${pvw(x)}</div><b>${x[5]}</b><br>${x[1]=='w'?'<small>💥 '+WD[x[0]]+'</small><br>':''}${x[1]=='f'?'<small>'+PA[x[0]]+'</small><br>':''}`+(own?`<button class="${on?'ok':''}" onclick="eq('${x[0]}')">${on?'مستخدم ✔':'استخدم'}</button>`:`<button class="${p.stars<x[4]?'alt':''}" onclick="buy('${x[0]}')">اشترِ ⭐${x[4]}</button><button class="alt" onclick="wish('${x[0]}')">${p.wish==x[0]?'🎯':'🤍'}</button>`)+'</div>'});
 show(h+`<div class="card"><div class="pvw"><span class="fxv">🎁</span></div><b>صندوق مفاجآت</b><br><button onclick="box()">افتح ⭐10</button></div><button class="alt" onclick="home()">⬅ رجوع</button>`,1)}
function buy(i){const x=it(i);if(p.stars<x[4]){sfx('bad');return shop('اجمع المزيد من النجوم ⭐')}p.stars-=x[4];p.own.push(i);p.eq[x[1]]=i;delete PV[x[1]];if(p.wish==i)p.wish=null;save();sfx('buy');boom(8);shop('🎉 مبروك! '+x[5])}
function eq(i){const c=it(i)[1];delete PV[c];p.eq[c]=(p.eq[c]==i&&c!='s'&&c!='w')?null:i;save();sfx('tap');shop()}
function wish(i){p.wish=p.wish==i?null:i;save();sfx('tap');shop()}
function box(){if(p.stars<10){sfx('bad');return shop('تحتاج 10 نجوم ⭐')}p.stars-=10;const l=IT.filter(x=>!p.own.includes(x[0])&&x[4]<=25);let m;
 if(l.length&&Math.random()<.8){const x=l[R(0,l.length-1)];p.own.push(x[0]);m='🎁 حصلت على '+x[2]+' '+x[5]+'!'}else{const g=R(5,15);p.stars+=g;m='🎁 نجوم إضافية: '+g+' ⭐'}
 save();sfx('win');boom(10);shop(m)}

/* ===== الأوسمة ===== */
const BD=[['🔥','بطل 7 أيام','7 أيام متتالية',p=>(p.bs||0)>=7],['⚡','سريع البديهة','كوكب بلا أخطاء',p=>(p.pf||0)>=1],['🧠','عبقري','5 كواكب مثالية',p=>(p.pf||0)>=5],['🪐','مستكشف','أنقذ 10 كواكب',p=>p.planet>10],['👹','قاهر الوحوش','اهزم زعيماً',p=>(p.bw||0)>=1],['🏆','صائد الزعماء','اهزم 5 زعماء',p=>(p.bw||0)>=5],['🛍️','جامع','امتلك 10 أغراض',p=>p.own.length>=10],['🔢','حاسب ماهر','100 إجابة صحيحة',p=>(p.tot||0)>=100]];
function badges(){SC='a';show('<h1>🏅 أوسمتي</h1><div class="bgs">'+BD.map(b=>`<div class="card bd${b[3](p)?'':' lk'}"><span>${b[0]}</span><b>${b[1]}</b><small>${b[2]}</small></div>`).join('')+'</div><button onclick="home()">⬅ رجوع</button>',1)}

/* ===== معركة الزعيم ===== */
let B=null;
function boss(){SC='b';const k=Math.max(1,Math.floor((p.planet-1)/3)),f=p.eq.f,mh=3+(f=='f3'?1:0),mx=10+3*k;
 B={k,max:mx,hp:mx,h:mh,mh,sh:f=='f4',st:0,shots:0,lock:0,w:it(p.eq.w||'w0')||it('w0'),f};sfx('tap');bask()}
function bask(){B.q=gen(p);B.lock=0;const q=B.q;let c=q.c.slice();
 if(B.f=='f2'){const wr=c.filter(v=>v!=q.a);c=c.filter(v=>v!=wr[R(0,wr.length-1)])}
 let h=`<h2>👹 الزعيم ${B.k}</h2><div id="bx" class="bx">${monsterSvg(B.k)}</div><div class="hpb"><i id="hp" style="width:${B.hp/B.max*100}%"></i></div>
 <p>${'❤️'.repeat(B.h)}${'🖤'.repeat(B.mh-B.h)}${B.sh?' 🛡️':''} &nbsp; ${B.w[2]} 💥${WD[B.w[0]]}${B.f&&it(B.f)?' &nbsp; '+it(B.f)[2]:''}</p>
 <div class="q">${q.t}</div><div id="fb"></div><div class="ans">`;
 c.forEach(v=>h+=`<button id="b${v}" onclick="bans(${v})">${v}</button>`);
 show(h+'</div><p><button class="alt" onclick="home()">⬅ هروب</button></p>',0,'night')}
function bans(v){if(B.lock)return;B.lock=1;const q=B.q,f=B.f;p.ws=p.ws||{};
 if(v==q.a){B.st++;B.shots++;p.tot=(p.tot||0)+1;p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1);
  let d=WD[B.w[0]]+(f=='f6'?1:0)+(f=='f8'?3:0);if(f=='f1'&&B.shots==1)d*=3;
  let m='';if(f=='f7'&&B.st%3==0&&B.h<B.mh){B.h++;m=' ✨❤️'}
  B.hp=Math.max(0,B.hp-d);sfx('ok');const bx=$('bx');bx.insertAdjacentHTML('beforeend','<span class="bolt2"></span>');bx.classList.add('hit');
  $('hp').style.width=B.hp/B.max*100+'%';$('b'+v).classList.add('ok');$('fb').innerHTML=`<div class="hint ok">💥 −${d}${m}</div>`;
  setTimeout(B.hp<=0?bwin:bask,1000)}
 else{B.st=0;p.ws[q.o]=(p.ws[q.o]||0)+1;sfx('bad');let m;
  if(B.sh){B.sh=false;m='🛡️ الدرع صدّ الهجمة!'}else{B.h--;m='💔 هجم الزعيم!'}
  $('b'+v).style.opacity=.35;$('fb').innerHTML=`<div class="hint">${m} الإجابة ${q.a}</div>`;
  setTimeout(B.h<=0?blose:bask,1600)}
 save()}
function bwin(){SC='e';const n=8+B.k,r=Math.round(B.f=='f5'?n*1.5:n);p.stars+=r;p.bw=(p.bw||0)+1;save();sfx('win');boom(14);
 show(`<h1>🏆 هزمت الزعيم!</h1>${mas('cheer')}<div class="card"><p>حصلت على ${r} ⭐</p><p>🔫 اشترِ سلاحاً أقوى للزعماء القادمين!</p></div><button class="big" onclick="trip()">الكوكب التالي 🚀</button><button class="alt" onclick="shop()">المتجر 🛒</button>`)}
function blose(){SC='e';sfx('bad');show(`<h1>👹 الزعيم قوي!</h1>${mas('oops')}<div class="card"><p>سلاح أقوى ورفيق مناسب يساعدانك 💪</p></div><button class="big" onclick="boss()">حاول مرة أخرى</button><button class="alt" onclick="shop()">المتجر 🛒</button><button class="alt" onclick="trip()">تخطّي 🚀</button>`)}
$('mt').textContent=S.m?'🔊':'🔇';
profiles();
window.onBack=()=>{if(SC=='p')return false;clearTimeout(TT);if(SC=='h'){profiles();return true}home();return true};
