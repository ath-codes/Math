/* سباق العوائق v2.0 — إعادة تصميم كاملة (منظور حقيقي، رفيق حيواني يرمي النار، سؤال بوقت كافٍ، قفز واضح بمنحدر).
   يُحمَّل بعد helper.js. يستعمل: show, sfx, hv, hpat, gen, animal, bwin, blose, B, p, IV, R, $, it, shipSvg, monsterSvg, petSvg, PetGun, pgBurst, mkNeb. */
function bossRun(){SC='b';
 const k=Math.max(1,Math.floor((p.planet-1)/3)),f=p.eq.f,iv=p.inv||{},mh=3+(f=='f3'?1:0)+(iv.hp?1:0),ivs=!!iv.sh,hasF=!!(f&&it(f)),pf=hasF?f:'f1';
 p.inv={hp:0,sh:0};save();B={k,f,x:0};sfx('tap');
 show(`<div class="bxw full"><canvas id="cv"></canvas><div class="bmsg" id="bm" style="top:150px"></div><div class="bhud"><button id="jb" class="rn-j">⬆<small>قفز</small></button>${hasF?`<button id="bp">${it(f)[2]}<small>مساعدة</small><i class="cdv" style="height:0"></i></button>`:'<span></span>'}</div></div>`,0,'night',1);
 window.scrollTo(0,0);
 const cv=$('cv'),c=cv.getContext('2d'),W=360,H=Math.max(500,Math.min(820,Math.round(360*innerHeight/innerWidth)));cv.width=W;cv.height=H;
 const img=(s,w,h)=>{const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s.replace('<svg ',`<svg width="${w}" height="${h}" `));return i};
 const shI=img(shipSvg(it(p.eq.s)||IT[0],{mood:'happy',h:p.eq.h}),130,140),mI=img(monsterSvg(k),200,190),peI=img(petSvg(pf,'pet'),100,80);
 const HZ=Math.max(190,Math.round(H*.3)),MY=H-150,D0=240,VX=W/2,LO=[-112,0,112],RD=950,GD=840,BRK=500,T=Math.min(90,52+7*k),CAP=12,JD=.95,gv=(p.g||0)==0?52:66;
 const SCL=d=>D0/(D0+Math.max(-150,d)),SYd=d=>HZ+(MY-HZ)*SCL(d),bY=HZ-26;
 const gun=PetGun(pf),neb=mkNeb(W,H);
 const me={x:VX,l:1,h:mh,inv:0,sh:f=='f4'||ivs,tilt:0},bs={x:VX,t:0,fl:0,thr:0,lun:0},ab={cd:0,max:15},pp={x:VX,y:MY+46};
 let t=0,P=0,dist=0,v=125,got=0,hits=0,done=0,dy=0,dyt=0,shk=0,heal=0,last=performance.now(),jt=-1,jd=JD,air=0,boost=0,slowT=0,mag=0,nxtD=300,ng=8,fw=0,gt0=0,gate=null,hint=0,pxs=0,pys=0,sw=0,mF=null,tm=0;
 const ob=[],st=[],pc=[],ft=[],rg=[],sf=Array.from({length:64},()=>({a:Math.random()*6.283,r:R(4,300),z:.4+Math.random()*.9}));
 const hgt=()=>air>0?.85+.1*Math.sin(t*8):(jt>=0&&jt<jd?Math.sin(Math.PI*jt/jd):0);
 const msg=s=>{const m=$('bm');if(!m)return;m.textContent=s;m.style.opacity=1;clearTimeout(msg.t);msg.t=setTimeout(()=>{if(m)m.style.opacity=0},2400)};
 const burst=(x,y,col,n)=>{for(let i=0;i<n;i++)pc.push({x,y,vx:R(-140,140),vy:R(-160,60),l:1,r:R(2,5),c:col})};
 const ring=(x,y,col)=>rg.push({x,y,r:8,l:1,c:col}),ftx=(x,y,s,col)=>ft.push({x,y,s,c:col||'#fff',l:1});
 msg('المس المسار الذي تريده 👆');setTimeout(()=>{if(!done)msg(it(pf)[2]+' رفيقك يهاجم الوحش 💥')},3000);
 const fin=ok=>{done=1;clearInterval(IV[0]);if(ok){B.x=got;bwin('run')}else blose(null,'run')};
 const die=()=>{dy=1;sfx('bossdie');hpat([0,120,40,160,40,220,40,320]);shk=.8;ob.length=0;st.length=0;gate=null;gun.sh.length=0;
  const cs=['#ffd23f','#ff6b35','#fff','#ff4d6d','#4cc9f0'];for(let i=0;i<50;i++)pc.push({x:bs.x,y:bY,vx:R(-240,240),vy:R(-300,120),l:1,r:R(3,8),c:cs[R(0,4)]})};
 const hurt=()=>{if(me.inv>0)return;if(me.sh){me.sh=false;hv(60,120);ring(me.x,MY,'#7df9ff')}else{me.h--;hits++;hpat([0,90,40,140]);ftx(me.x,MY-60,'💔')}me.inv=1.4;sfx('bad');shk=.35;bs.lun=.4};
 const onHit=(s,x,y)=>{if(dy)return;const bn=.8*gun.d.d*s.mul;P+=bn;bs.fl=.14;bs.lun=Math.max(bs.lun,.18);shk=Math.max(shk,.12);pgBurst(pc,rg,x,y,gun.d.k);ftx(x+R(-14,14),y-20,'-'+Math.max(1,Math.round(bn/T*100))+'%',gun.d.c);sfx('pboom');hv(10,70)};
 const mouth=()=>({x:pp.x,y:pp.y-26});
 const nearL=()=>Math.max(0,Math.min(2,Math.round((me.x-VX-LO[0])/(LO[1]-LO[0]))));
 const jump=()=>{if(done||dy||jt>=0)return;jt=0;jd=JD;sfx('jump');hv(12,70);ring(me.x,MY+30,'#fff');burst(me.x,MY+30,'rgba(255,255,255,.8)',6)};
 const mv=e=>{if(done||dy)return;const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*W,l=Math.max(0,Math.min(2,Math.floor(x/(W/3))));if(l!=me.l){me.l=l;sfx('tap')}};
 cv.style.touchAction='none';cv.onpointerdown=e=>{pxs=e.clientX;pys=e.clientY;sw=0;mv(e)};
 cv.onpointermove=e=>{if(!e.buttons||sw)return;const dx=e.clientX-pxs,d2=e.clientY-pys;if(d2<-38&&Math.abs(d2)>Math.abs(dx)*1.3){sw=1;jump();return}mv(e)};
 $('jb').onpointerdown=e=>{e.preventDefault();e.stopPropagation();jump()};
 if(hasF)$('bp').onclick=()=>{if(ab.cd>0||done||dy)return;ab.cd=ab.max;sfx('pet');animal(f);let s='';
  if(f=='f1'){mag=6;s='🧲 النجوم تأتي إليك!'}else if(f=='f2'){slowT=5;s='👃 الوقت تباطأ!'}else if(f=='f3'){me.h=Math.min(mh,me.h+1);s='❤ قلب إضافي!'}
  else if(f=='f4'){me.sh=true;s='🛡 درع جاهز!'}else if(f=='f5'){me.inv=2.5;s='🐺 اختفاء مؤقت!'}else if(f=='f6'){air=1.6;s='🐸 قفزة عالية!'}
  else if(f=='f7'){me.h=mh;s='🦁 شفاء كامل!'}else if(f=='f8'){ob.forEach(o=>{if(o.kind=='r')burst(VX+LO[o.l]*SCL(o.d),SYd(o.d),'#b9b2c9',8)});ob.length=0;const m=mouth();for(let i=0;i<3;i++)gun.fire(m.x+(i-1)*12,m.y,1.7,.5+i*.12);s='🐻 ضربة الدب! تحطّمت العوائق'}
  msg(s)};
 const spawnGate=()=>{const q=gen(p,2),w=q.c.filter(x=>x!=q.a).sort(()=>Math.random()-.5).slice(0,2);
  gate={q,vals:[q.a,...w].sort(()=>Math.random()-.5),d:GD,done:0,sel:-1,t0:(GD-BRK)/110+BRK/gv};sfx('gate');bs.thr=.5;msg('سؤال! قف عند الباب الصحيح 🚪')};
 const spawnRow=()=>{
  if(t>9&&fw<3+Math.min(2,k)&&T-P>16&&Math.random()<.17){fw++;ob.push({kind:'ramp',d:RD-140,l:0,u:0});ob.push({kind:'h',d:RD,l:0,done:0});nxtD=420;return}
  const ls=[0,1,2].sort(()=>Math.random()-.5),n=Math.random()<Math.min(.62,.18+k*.07)?2:1,bl=ls.slice(0,n),fr=ls.slice(n);
  bl.forEach(l=>ob.push({kind:'r',l,d:RD,a:R(0,6),vr:(Math.random()-.5)*2.4,s:30+R(0,8)}));bs.thr=.35;
  const sl=fr[R(0,fr.length-1)];for(let i=0;i<3&&got+st.length<CAP;i++)st.push({lx:LO[sl],d:RD+40+i*70});
  nxtD=300-Math.min(60,k*6)+R(0,50)};
 const upd=dt=>{t+=dt;P+=dt;tm+=dt;boost=Math.max(0,boost-dt);slowT=Math.max(0,slowT-dt);mag=Math.max(0,mag-dt);air=Math.max(0,air-dt);gt0=Math.max(0,gt0-dt);
  ab.cd=Math.max(0,ab.cd-dt);me.inv=Math.max(0,me.inv-dt);shk=Math.max(0,shk-dt);bs.fl=Math.max(0,bs.fl-dt);bs.thr=Math.max(0,bs.thr-dt);bs.lun=Math.max(0,bs.lun-dt);
  if(jt>=0){jt+=dt;if(jt>=jd){jt=-1;sfx('land');hv(14,80);ring(me.x,MY+30,'rgba(255,255,255,.8)');for(let i=0;i<8;i++)pc.push({x:me.x+R(-14,14),y:MY+30,vx:R(-90,90),vy:R(-60,-10),l:.7,r:R(2,4),c:'rgba(210,200,255,.7)',g:60,fd:1.8})}}
  let tv=Math.min(215,118+k*7+t*1.3);if(gate&&!gate.done)tv=gate.d>BRK?tv*.85:gv;if(slowT>0)tv*=.6;if(boost>0)tv*=1.35;
  v+=(tv-v)*Math.min(1,dt*(gate&&!gate.done?2.2:4));dist+=v*dt;
  me.x+=(VX+LO[me.l]-me.x)*Math.min(1,dt*13);me.tilt=(VX+LO[me.l]-me.x)/90*.5;
  bs.t+=dt;bs.x+=(VX+Math.sin(bs.t*.8)*38+(me.x-VX)*.25-bs.x)*Math.min(1,dt*3);
  if(f=='f7'){heal+=dt;if(heal>=15&&me.h<mh){me.h++;heal=0}}
  nxtD-=v*dt;const wantG=t>=ng&&T-P>9;
  if(!gate){const far=ob.reduce((m,o)=>Math.max(m,o.d),0);if(wantG){if(far<600&&gt0<=0){spawnGate()}}else if(nxtD<=0&&T-P>2.5)spawnRow()}
  sf.forEach(s=>{s.r+=dt*(10+v*.35)*s.z*(1+s.r/90);if(s.r>330){s.r=R(3,20);s.a=Math.random()*6.283}});
  for(let i=ob.length-1;i>=0;i--){const o=ob[i];o.d-=v*dt;if(o.a!==undefined)o.a+=(o.vr||0)*dt;
   if(o.kind=='r'){if(Math.abs(o.d)<26&&!o.hit&&Math.abs(VX+LO[o.l]-me.x)<42&&Math.abs(me.x-VX-LO[me.l])<28){o.hit=1;if(air<=0&&hgt()<.5){const x=VX+LO[o.l];burst(x,MY,'#b9b2c9',10);burst(x,MY,'#ff9f1c',6);hurt()}}}
   else if(o.kind=='ramp'){if(o.d<=0&&!o.u){o.u=1;if(jt<0&&air<=0){const hd=ob.find(h=>h.kind=='h'&&h.d>0),dd=hd?hd.d:140;jd=Math.max(.8,Math.min(1.35,2*(dd+10)/Math.max(60,v)));jt=0;sfx('jump');hv(18,90);ring(me.x,MY+30,'#ffd23f');burst(me.x,MY+30,'#ffd23f',10);msg('🚀 منحدر! طِرتَ فوق الحاجز')}}}
   else if(o.kind=='h'){if(o.d<=0&&!o.done){o.done=1;if(hgt()>.3||air>0){if(got<CAP)got++;sfx('star');ftx(me.x,MY-90,'ممتاز! ⭐','#ffd23f');burst(me.x,MY-20,'#ffd23f',12)}else{shk=.2;ftx(me.x,MY-60,'اقفز ⬆','#fff')}}}
   if(o.d<-90)ob.splice(i,1)}
  for(let i=st.length-1;i>=0;i--){const s=st[i];s.d-=v*dt;if(mag>0&&s.d<520)s.lx+=((me.x-VX)-s.lx)*Math.min(1,dt*5);
   if(Math.abs(s.d)<30&&Math.abs(VX+s.lx-me.x)<34){st.splice(i,1);got++;sfx('star');hv(8,50);burst(me.x,MY-10,'#ffd23f',6);continue}
   if(s.d<-90)st.splice(i,1)}
  if(gate){const g=gate;g.d-=v*dt;g.sel=nearL();
   if(!g.done&&g.d<=0){g.done=1;const q=g.q,ok=g.vals[nearL()]==q.a;p.ws=p.ws||{};g.ok=ok;g.pick=nearL();
    if(ok){got=Math.min(CAP,got+3);P+=1;boost=1.3;sfx('ok');hv(25,120);burst(me.x,MY,'#ffd23f',14);msg('صحيح! 🔥 رفيقك يطلق قذائف قوية');const m=mouth();for(let i=0;i<3;i++)gun.fire(m.x+(i-1)*12,m.y,1.7,.5+i*.12);p.ws[q.o]=Math.max(0,(p.ws[q.o]||0)-1)}
    else{p.ws[q.o]=(p.ws[q.o]||0)+1;msg('الإجابة الصحيحة هي '+q.a+' 💡');hurt()}
    save();ng=t+R(9,12);gt0=1.4}
   if(g.d<-130)gate=null}
  const m=mouth();gun.step(dt,m.x,m.y,()=>({x:bs.x,y:bY}),onHit,pc,!dy&&!done&&t>1.5);
  {pp.x=me.x;pp.y=MY+46-hgt()*92*.4+Math.sin(t*9)*1.5}
  if(tm>.05){tm=0;if(pc.length<260)pc.push({x:me.x+R(-5,5),y:MY-hgt()*88+30,vx:R(-20,20),vy:R(60,140),l:.5,r:R(2,4),c:'#ff9f1c',g:0,fd:2.4})}
  for(let i=pc.length-1;i>=0;i--){const q=pc[i];q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=(q.g===undefined?300:q.g)*dt;q.l-=dt*(q.fd||2.2);if(q.l<=0)pc.splice(i,1)}
  for(let i=rg.length-1;i>=0;i--){const r=rg[i];r.r+=dt*190;r.l-=dt*2.4;if(r.l<=0)rg.splice(i,1)}
  for(let i=ft.length-1;i>=0;i--){const q=ft[i];q.y-=dt*34;q.l-=dt*1.1;if(q.l<=0)ft.splice(i,1)}};
 const rr=(x,y,w,h,r)=>{c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()};
 const star=(x,y,r)=>{c.save();c.translate(x,y);c.shadowColor='#ffd23f';c.shadowBlur=8;c.fillStyle='#ffd23f';c.beginPath();for(let i=0;i<10;i++){const q=i%2?r*.45:r,a=i*Math.PI/5;c.lineTo(Math.sin(a)*q,-Math.cos(a)*q)}c.closePath();c.fill();c.restore()};
 const heart=(x,y,s,on)=>{c.save();c.translate(x,y);c.scale(s,s);c.beginPath();c.moveTo(0,-3);c.bezierCurveTo(0,-9,-10,-9,-10,-2);c.bezierCurveTo(-10,5,0,9,0,13);c.bezierCurveTo(0,9,10,5,10,-2);c.bezierCurveTo(10,-9,0,-9,0,-3);
  if(on){const g=c.createLinearGradient(0,-9,0,13);g.addColorStop(0,'#ff8fa3');g.addColorStop(1,'#e01e4f');c.fillStyle=g;c.fill();c.fillStyle='rgba(255,255,255,.5)';c.beginPath();c.ellipse(-4.5,-3.5,2.4,1.5,-.6,0,7);c.fill()}else{c.strokeStyle='rgba(255,255,255,.4)';c.lineWidth=1.5;c.stroke()}c.restore()};
 const rock=(x,y,s,a,vr)=>{c.save();c.translate(x,y);c.fillStyle='rgba(0,0,0,.3)';c.beginPath();c.ellipse(0,s*.8,s*.9,s*.25,0,0,7);c.fill();c.rotate(a);const g=c.createRadialGradient(-s*.3,-s*.3,2,0,0,s*1.1);g.addColorStop(0,'#c9c2d9');g.addColorStop(.6,'#6f6788');g.addColorStop(1,'#2e2845');
  c.fillStyle=g;c.beginPath();for(let i=0;i<9;i++){const an=i/9*6.2832,r=s*(.82+.18*Math.sin(i*2.7+vr*5));c.lineTo(Math.cos(an)*r,Math.sin(an)*r)}c.closePath();c.fill();
  c.strokeStyle='rgba(255,130,60,.6)';c.lineWidth=2;c.stroke();c.fillStyle='rgba(30,20,50,.35)';c.beginPath();c.arc(-s*.25,-s*.1,s*.2,0,7);c.fill();c.beginPath();c.arc(s*.28,s*.25,s*.14,0,7);c.fill();c.restore()};
 const ramp=o=>{const d=o.d,yN=SYd(d-30),yF=SYd(d+50),wN=172*SCL(d-30),wF=172*SCL(d+50),s=SCL(d);
  const g=c.createLinearGradient(0,yF,0,yN);g.addColorStop(0,'#ffe066');g.addColorStop(1,'#ff9f1c');c.fillStyle=g;c.beginPath();c.moveTo(VX-wF,yF);c.lineTo(VX+wF,yF);c.lineTo(VX+wN,yN);c.lineTo(VX-wN,yN);c.closePath();c.fill();
  c.strokeStyle='#fff';c.lineWidth=Math.max(1.5,3*s);c.beginPath();c.moveTo(VX-wF,yF);c.lineTo(VX+wF,yF);c.stroke();
  c.strokeStyle='#5a3300';c.lineWidth=Math.max(2,5*s);LO.forEach(lx=>{[.28,.62].forEach(q=>{const yy=yN-(yN-yF)*q,w=30*s,h=11*s;c.beginPath();c.moveTo(VX+lx*s-w,yy+h);c.lineTo(VX+lx*s,yy);c.lineTo(VX+lx*s+w,yy+h);c.stroke()})})};
 const hurdle=o=>{const d=o.d,s=SCL(d),y=SYd(d),wd=168*s,ph=64*s,pulse=.6+.4*Math.sin(t*9);
  c.fillStyle='#2a1f4d';c.fillRect(VX-wd-5*s,y-ph,8*s,ph);c.fillRect(VX+wd-3*s,y-ph,8*s,ph);
  c.fillStyle='#ffd23f';c.beginPath();c.arc(VX-wd-1*s,y-ph,6*s,0,7);c.arc(VX+wd+1*s,y-ph,6*s,0,7);c.fill();
  c.save();c.shadowColor='#ff3b3b';c.shadowBlur=12;c.fillStyle=`rgba(255,${60+pulse*60|0},70,1)`;c.fillRect(VX-wd,y-46*s,wd*2,5*s);c.fillRect(VX-wd,y-28*s,wd*2,5*s);c.restore();
  const bh=15*s;c.fillStyle='#ffd23f';c.fillRect(VX-wd,y-bh,wd*2,bh);c.fillStyle='#2a1a12';for(let x=VX-wd;x<VX+wd;x+=26*s){c.beginPath();c.moveTo(x,y-bh);c.lineTo(x+13*s,y-bh);c.lineTo(x+4*s,y);c.lineTo(x-9*s,y);c.closePath();c.fill()}};
 const doorDraw=(g)=>{const d=g.d,pr=d>0?1-d/GD:1,gs=d>0?.58+.42*pr:SCL(d),y=SYd(d)-20*gs;c.save();if(d<-60)c.globalAlpha=Math.max(0,1+(d+60)/70);
  g.vals.forEach((val,i)=>{const x=VX+LO[i]*gs,w=98*gs,h=66*gs,on=!g.done&&g.sel==i,good=g.done&&val==g.q.a,bad=g.done&&g.pick==i&&!g.ok,z=on?1.08:1;
   c.save();c.translate(x,y);c.scale(z,z);c.fillStyle=on?'rgba(255,230,120,.28)':'rgba(125,249,255,.16)';c.beginPath();c.ellipse(0,h*.62,w*.6,h*.16,0,0,7);c.fill();
   const gr=c.createLinearGradient(0,-h/2,0,h/2);if(good){gr.addColorStop(0,'#7bd957');gr.addColorStop(1,'#2e9d3a')}else if(bad){gr.addColorStop(0,'#ff6b6b');gr.addColorStop(1,'#b02323')}else{gr.addColorStop(0,'#4cc9f0');gr.addColorStop(1,'#7b6cf0')}
   c.shadowColor=on?'#ffd23f':'#7df9ff';c.shadowBlur=on?20:12;c.fillStyle=gr;rr(-w/2,-h/2,w,h,16*gs);c.fill();c.shadowBlur=0;c.strokeStyle=on?'#ffd23f':'#fff';c.lineWidth=on?4:3;c.stroke();
   c.fillStyle='rgba(255,255,255,.22)';rr(-w/2+5,-h/2+4,w-10,h*.32,10*gs);c.fill();
   c.fillStyle='#fff';c.font='bold '+Math.round(36*gs)+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(val,0,2);
   if(on){c.fillStyle='#ffd23f';c.font='bold '+Math.round(22*gs)+'px sans-serif';c.fillText('▼',0,-h/2-12*gs)}c.restore()});c.restore()};
 const mfl=()=>{if(mF||!mI.complete||!mI.naturalWidth)return mF;try{const o=document.createElement('canvas');o.width=200;o.height=190;const x=o.getContext('2d');x.drawImage(mI,0,0,200,190);x.globalCompositeOperation='source-atop';x.fillStyle='#fff';x.fillRect(0,0,200,190);mF=o}catch(e){}return mF};
 const remT=()=>{if(!gate||gate.done)return 0;return(gate.d>BRK?(gate.d-BRK)/110:0)+Math.min(gate.d,BRK)/gv};
 const draw=()=>{c.clearRect(0,0,W,H);c.direction='ltr';c.save();if(shk>0)c.translate(R(-5,5)*shk*3,R(-5,5)*shk*3);
  if(neb)c.drawImage(neb,0,0);
  c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=1.3;sf.forEach(s=>{const l=Math.min(16,2+v*.04*s.z*s.r/160),ca=Math.cos(s.a),sa=Math.sin(s.a);c.globalAlpha=Math.min(1,s.r/80);c.beginPath();c.moveTo(VX+ca*(s.r-l),HZ+sa*(s.r-l)*.75);c.lineTo(VX+ca*s.r,HZ+sa*s.r*.75);c.stroke()});c.globalAlpha=1;
  let g=c.createRadialGradient(VX,HZ,5,VX,HZ,240);g.addColorStop(0,'rgba(255,150,90,.55)');g.addColorStop(.35,'rgba(160,80,255,.28)');g.addColorStop(1,'rgba(60,40,160,0)');c.fillStyle=g;c.fillRect(0,0,W,HZ+130);
  const sb=(H-HZ)/(MY-HZ);
  g=c.createLinearGradient(0,HZ,0,H);g.addColorStop(0,'#150f45');g.addColorStop(1,'#07061f');c.fillStyle=g;c.beginPath();c.moveTo(VX,HZ);c.lineTo(VX+400*sb,H);c.lineTo(VX-400*sb,H);c.closePath();c.fill();
  g=c.createLinearGradient(0,HZ,0,H);g.addColorStop(0,'#3a2394');g.addColorStop(.5,'#241a66');g.addColorStop(1,'#120d3d');c.fillStyle=g;c.beginPath();c.moveTo(VX,HZ);c.lineTo(VX+172*sb,H);c.lineTo(VX-172*sb,H);c.closePath();c.fill();
  c.fillStyle='rgba(125,249,255,.12)';{const a=LO[me.l]-56,b=LO[me.l]+56;c.beginPath();c.moveTo(VX,HZ);c.lineTo(VX+b*sb,H);c.lineTo(VX+a*sb,H);c.closePath();c.fill()}
  for(let i=0;i<15;i++){const d=i*150-(dist%150);if(d<-30)continue;const y=SYd(d);c.strokeStyle=`rgba(150,130,255,${Math.min(.4,SCL(d)*.55)})`;c.lineWidth=1;c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke()}
  c.strokeStyle='rgba(180,170,255,.4)';c.lineWidth=1.5;[-56,56].forEach(o=>{c.beginPath();c.moveTo(VX,HZ);c.lineTo(VX+o*sb,H);c.stroke()});
  c.save();c.shadowBlur=10;[[-172,'#ff5cf0'],[172,'#4cc9f0']].forEach(a=>{c.shadowColor=a[1];c.strokeStyle=a[1];c.lineWidth=3;c.beginPath();c.moveTo(VX,HZ);c.lineTo(VX+a[0]*sb,H);c.stroke()});c.restore();
  for(let j=0;j<7;j++){const d=j*300-(dist%300);if(d<-60)continue;const s=SCL(d),y=SYd(d);[-190,190].forEach((lx,q)=>{const x=VX+lx*s;c.fillStyle='#231a55';c.fillRect(x-3*s,y-74*s,6*s,74*s);c.fillStyle=(j+q)%2?'#ff5cf0':'#4cc9f0';c.globalAlpha=.9;c.beginPath();c.arc(x,y-78*s,6*s,0,7);c.fill();c.globalAlpha=1})}
  {const b=1+.03*Math.sin(t*3)+(bs.thr>0?.12*bs.thr/.5:0)+bs.lun*.35,sx=bs.x+(dy?Math.sin(dyt*60)*6:0);c.save();c.globalAlpha=dy?Math.max(0,1-dyt/.9):1;c.translate(sx,bY+55);c.scale(b,b);c.drawImage(mI,-62,-110,124,118);
   if(bs.fl>0&&!dy){const m2=mfl();if(m2){c.globalAlpha=Math.min(.85,bs.fl/.14);c.drawImage(m2,-62,-110,124,118)}}c.restore();c.globalAlpha=1}
  const L=[];ob.forEach(o=>L.push({d:o.d,f:()=>{const s=SCL(o.d);c.globalAlpha=Math.max(0,Math.min(1,(RD+60-o.d)/160));
    if(o.kind=='r')rock(VX+LO[o.l]*s,SYd(o.d)-22*s,o.s*s*1.2,o.a,o.vr);else if(o.kind=='ramp')ramp(o);else hurdle(o);c.globalAlpha=1}}));
  st.forEach(s=>L.push({d:s.d,f:()=>{const q=SCL(s.d);c.globalAlpha=Math.max(0,Math.min(1,(RD+120-s.d)/160));star(VX+s.lx*q,SYd(s.d)-20*q,12*q+2);c.globalAlpha=1}}));
  if(gate)L.push({d:gate.d,f:()=>doorDraw(gate)});
  L.sort((a,b)=>b.d-a.d).forEach(e=>e.f());
  const hh=hgt(),lift=hh*92,kz=1+hh*.34;
  c.fillStyle='rgba(0,0,0,'+(.35-.2*hh)+')';c.beginPath();c.ellipse(me.x,MY+34,26*(1-.25*hh),8*(1-.25*hh),0,0,7);c.fill();
  c.drawImage(peI,pp.x-27,pp.y-34,54,43);{const m=mouth();gun.muzzle(c,m.x,m.y)}
  if(boost>0){c.strokeStyle='rgba(255,255,255,.55)';c.lineWidth=2;for(let i=0;i<8;i++){const x=R(0,W);c.beginPath();c.moveTo(x,R(HZ,H));c.lineTo(x,R(HZ,H)+30)}c.stroke()}
  if(me.inv<=0||Math.floor(me.inv*10)%2){c.save();c.translate(me.x,MY-lift);c.rotate(me.tilt-hh*.12);c.scale(kz,kz);c.drawImage(shI,-30,-32,60,64);c.restore()}
  if(me.sh){c.strokeStyle='#7df9ff';c.lineWidth=3;c.beginPath();c.arc(me.x,MY-lift,38*kz,0,7);c.stroke()}
  if(hh>.05&&hh<.95&&(jt>=0)){c.strokeStyle='rgba(255,255,255,'+(.4*hh)+')';c.lineWidth=2;c.beginPath();c.arc(me.x,MY-lift+10,34*kz,0.3,Math.PI-.3);c.stroke()}
  gun.draw(c);
  {const rp=ob.find(o=>o.kind=='ramp'&&o.d>0&&o.d<430);if(rp&&jt<0&&!dy){const a=.6+.4*Math.sin(t*10);c.fillStyle='rgba(255,210,63,'+a+')';rr(me.x-46,MY-96,92,30,15);c.fill();c.fillStyle='#3a2200';c.font='bold 18px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('اقفز ⬆',me.x,MY-81);c.textBaseline='alphabetic'}
   const jb=$('jb');if(jb)jb.classList.toggle('rn-pl',!!(rp&&jt<0))}
  rg.forEach(r=>{c.globalAlpha=Math.max(0,r.l);c.strokeStyle=r.c;c.lineWidth=3;c.beginPath();c.arc(r.x,r.y,r.r,0,7);c.stroke()});
  pc.forEach(q=>{if(q.l<=0)return;c.globalAlpha=Math.max(0,q.l);c.fillStyle=q.c;c.beginPath();c.arc(q.x,q.y,q.r,0,7);c.fill()});c.globalAlpha=1;
  c.font='bold 17px sans-serif';c.textAlign='center';ft.forEach(q=>{c.globalAlpha=Math.max(0,q.l);c.fillStyle=q.c;c.strokeStyle='rgba(0,0,0,.6)';c.lineWidth=3;c.strokeText(q.s,q.x,q.y);c.fillText(q.s,q.x,q.y)});c.globalAlpha=1;
  /* الواجهة */
  const hp=Math.max(0,1-P/T);c.fillStyle='rgba(0,0,0,.5)';rr(44,12,W-56,18,9);c.fill();
  if(hp>0){g=c.createLinearGradient(0,12,0,30);g.addColorStop(0,'#ff8a8a');g.addColorStop(1,hp<.3?'#b00020':'#e03131');c.fillStyle=g;rr(44,12,Math.max(14,(W-56)*hp),18,9);c.fill();c.fillStyle='rgba(255,255,255,.3)';rr(48,14,Math.max(8,(W-64)*hp),5,3);c.fill()}
  c.strokeStyle='rgba(255,255,255,.6)';c.lineWidth=2;rr(44,12,W-56,18,9);c.stroke();c.drawImage(mI,6,4,34,32);
  star(20,56,10);c.fillStyle='#fff';c.font='bold 20px sans-serif';c.textAlign='left';c.fillText(got,36,63);
  for(let i=0;i<mh;i++)heart(W-20-i*26,56,1.05,i<me.h);
  if(gate&&!gate.done){c.fillStyle='rgba(10,10,40,.82)';rr(W/2-120,76,240,60,18);c.fill();c.strokeStyle='#7df9ff';c.lineWidth=2;c.stroke();
   c.fillStyle='#fff';c.font='bold 30px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(gate.q.t,W/2,102);c.textBaseline='alphabetic';
   const fr=Math.max(0,Math.min(1,remT()/gate.t0));c.fillStyle='rgba(255,255,255,.2)';rr(W/2-100,124,200,6,3);c.fill();c.fillStyle=fr<.25?'#ff6b6b':'#7df9ff';rr(W/2-100,124,Math.max(6,200*fr),6,3);c.fill()}
  const cd=$('bp');if(cd)cd.querySelector('.cdv').style.height=(ab.cd/ab.max*100)+'%';
  c.restore()};
 IV[0]=setInterval(()=>{if(done)return;const now=performance.now(),dt=Math.min(.05,(now-last)/1000);last=now;
  if(!dy)upd(dt);else{dyt+=dt;pc.forEach(q=>{q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=420*dt;q.l-=dt*.9});if(dyt>1.3){draw();return fin(1)}}
  draw();if(!dy){if(me.h<=0)fin(0);else if(P>=T)die()}},16)}
