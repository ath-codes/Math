/* ===== الرسومات: كلها SVG مرسومة بالكود (بدون صور خارجية) ===== */
const shade=(h,a)=>{const n=parseInt(h.slice(1),16),f=c=>Math.max(0,Math.min(255,Math.round(a>0?c+(255-c)*a:c*(1+a))));
 return '#'+[n>>16,n>>8&255,n&255].map(c=>f(c).toString(16).padStart(2,'0')).join('')};

/* ---------- الشخصية ----------
 o.mood = happy | wow | think | oops | cheer
 o.h    = h1 فيونكة | h2 كاب | h3 نظارة | h4 سماعات | h5 قبعة | h6 تاج
 o.crop = الرأس فقط (للمتجر) */
function kid(o={}){
 const m=o.mood||'happy',hat=o.h,crop=!!o.crop;
 const noHair=hat=='h2'||hat=='h5'||hat=='h6';
 const sk='#ffe0b8',suit='#4f86ff',ink='#4a2f22',hr=ink;
 const arm=(sx,ang,cls)=>`<g transform="rotate(${ang} ${sx} 96)"><g class="${cls||''}"><rect x="${sx-6.5}" y="92" width="13" height="30" rx="6.5" fill="${suit}"/><circle cx="${sx}" cy="123" r="7.5" fill="#fff"/></g></g>`;
 const aL=m=='cheer'?arm(36,150,'wv'):m=='wow'?arm(36,62):arm(36,8);
 const aR=m=='happy'?arm(84,-148,'wv2'):m=='cheer'?arm(84,-150,'wv'):m=='think'?arm(84,160):m=='wow'?arm(84,-62):arm(84,-8);
 const br={happy:['M37 46Q46 41 55 46','M65 46Q74 41 83 46'],
  wow:['M37 41Q46 35 55 41','M65 41Q74 35 83 41'],
  cheer:['M37 42Q46 36 55 42','M65 42Q74 36 83 42'],
  think:['M37 47Q46 44 55 47','M65 40Q74 34 83 40'],
  oops:['M37 49L55 43','M65 43L83 49']}[m];
 const mouth={
  happy:`<path d="M47 73Q60 91 73 73Z" fill="#8a2f45"/><ellipse cx="60" cy="80" rx="5.5" ry="2.6" fill="#ff7a90"/>`,
  wow:`<ellipse cx="60" cy="80" rx="7" ry="9" fill="#8a2f45"/><ellipse cx="60" cy="85" rx="4.5" ry="2.5" fill="#ff7a90"/>`,
  cheer:`<path d="M43 72Q60 102 77 72Z" fill="#8a2f45"/><ellipse cx="60" cy="85" rx="8" ry="4" fill="#ff7a90"/>`,
  think:`<path d="M52 79Q60 75 69 80" stroke="#8a2f45" stroke-width="3.5" stroke-linecap="round" fill="none"/>`,
  oops:`<path d="M47 84Q54 74 60 80Q66 86 73 76" stroke="#8a2f45" stroke-width="3.5" stroke-linecap="round" fill="none"/>`}[m];
 const hair=noHair?'':`<path d="M21 54Q16 12 60 14Q104 12 99 54Q92 32 60 32Q28 32 21 54Z" fill="${hr}"/>`;
 const hats={
  h1:`<path d="M88 24L106 14V34Z M88 24L70 14V34Z" fill="#ff5d8f"/><circle cx="88" cy="24" r="5" fill="#ffd23f"/>`,
  h2:`<path d="M22 44Q22 12 60 12Q98 12 98 44Z" fill="#e63946"/><rect x="58" y="38" width="50" height="9" rx="4.5" fill="#c1121f"/><circle cx="60" cy="12" r="4" fill="#fff"/>`,
  h3:`<circle cx="46" cy="58" r="12" fill="rgba(125,249,255,.25)" stroke="#222" stroke-width="3.5"/><circle cx="74" cy="58" r="12" fill="rgba(125,249,255,.25)" stroke="#222" stroke-width="3.5"/><path d="M58 58H62" stroke="#222" stroke-width="3.5"/>`,
  h4:`<path d="M19 58Q16 14 60 14Q104 14 101 58" fill="none" stroke="#333" stroke-width="7"/><rect x="11" y="50" width="14" height="26" rx="7" fill="#ff6b9d"/><rect x="95" y="50" width="14" height="26" rx="7" fill="#ff6b9d"/>`,
  h5:`<ellipse cx="60" cy="30" rx="44" ry="8" fill="#222"/><rect x="38" y="-8" width="44" height="40" rx="5" fill="#222"/><rect x="38" y="16" width="44" height="8" fill="#e63946"/>`,
  h6:`<path d="M32 30L35 4L48 20L60 0L72 20L85 4L88 30Z" fill="#ffd23f" stroke="#e0a800" stroke-width="2"/><circle cx="60" cy="14" r="3.5" fill="#e63946"/>`};
 const eyes=[46,74].map(x=>`<ellipse cx="${x}" cy="58" rx="5.5" ry="7" fill="${ink}"/><circle cx="${x+2}" cy="55" r="2" fill="#fff"/>`).join('');
 return `<svg class="${crop?'kidc':'kid'}" viewBox="${crop?'8 -12 104 108':'0 -14 120 164'}" xmlns="http://www.w3.org/2000/svg">`+
  `<rect x="42" y="130" width="14" height="16" rx="6" fill="#fff"/><rect x="64" y="130" width="14" height="16" rx="6" fill="#fff"/>`+
  `<rect x="34" y="92" width="52" height="44" rx="20" fill="${suit}"/><circle cx="60" cy="113" r="7" fill="#ffd23f"/>`+aL+aR+
  `<circle cx="21" cy="60" r="8" fill="${sk}"/><circle cx="99" cy="60" r="8" fill="${sk}"/><ellipse cx="60" cy="58" rx="40" ry="38" fill="${sk}"/>`+hair+
  br.map(d=>`<path d="${d}" stroke="${ink}" stroke-width="3.5" stroke-linecap="round" fill="none"/>`).join('')+eyes+
  `<circle cx="35" cy="71" r="6" fill="#ff9eb0" opacity=".5"/><circle cx="85" cy="71" r="6" fill="#ff9eb0" opacity=".5"/>`+mouth+(hats[hat]||'')+`</svg>`}

/* ---------- السفن ---------- */
function shipSvg(sh){const c=sh[3]||'#ffd23f',d=shade(c,-.3),l=shade(c,.45);
 const kind={s0:'r',s1:'u',s2:'t',s3:'h',s4:'r',s5:'j',s6:'u',s7:'r'}[sh[0]]||'r';let b='';
 if(kind=='r')b=`<path class="fl" d="M52 112Q65 146 78 112Z" fill="#ff9f1c"/><path class="fl" d="M57 112Q65 134 73 112Z" fill="#ffe066"/><path d="M22 112L36 74V112Z M108 112L94 74V112Z" fill="${d}"/><path d="M32 112Q28 70 65 40Q102 70 98 112Z" fill="${c}"/><circle cx="65" cy="88" r="11" fill="#bfefff" stroke="${d}" stroke-width="4"/><rect x="30" y="106" width="70" height="8" rx="4" fill="${d}"/>`;
 else if(kind=='u')b=`<path class="fl" d="M52 108Q65 134 78 108Z" fill="#9bf6ff"/><path d="M35 92Q65 40 95 92Z" fill="#bfefff" opacity=".7"/><ellipse cx="65" cy="98" rx="58" ry="17" fill="${c}"/><path d="M12 100Q65 126 118 100Q112 112 65 114Q18 112 12 100Z" fill="${d}"/>`+[28,47,65,83,102].map(x=>`<circle cx="${x}" cy="99" r="4" fill="#ffe066"/>`).join('');
 else if(kind=='t')b=`<path class="fl" d="M55 114Q65 138 75 114Z" fill="#ff9f1c"/><rect x="3" y="80" width="40" height="22" rx="3" fill="#2d6cdf" stroke="#bfefff" stroke-width="2"/><rect x="87" y="80" width="40" height="22" rx="3" fill="#2d6cdf" stroke="#bfefff" stroke-width="2"/><rect x="43" y="88" width="44" height="6" fill="${d}"/><rect x="44" y="64" width="42" height="52" rx="10" fill="${c}"/><path d="M56 64Q65 46 74 64Z" fill="${l}"/><circle cx="65" cy="90" r="10" fill="#bfefff" stroke="${d}" stroke-width="3"/>`;
 else if(kind=='h')b=`<ellipse class="rot" cx="65" cy="62" rx="58" ry="4" fill="#666"/><rect x="63" y="62" width="4" height="16" fill="#444"/><ellipse cx="65" cy="94" rx="38" ry="24" fill="${c}"/><rect x="96" y="88" width="28" height="9" rx="4" fill="${d}"/><ellipse class="rot" cx="122" cy="92" rx="3" ry="12" fill="#555"/><ellipse cx="48" cy="92" rx="14" ry="10" fill="#bfefff"/><path d="M26 120H104 M44 114V120 M86 114V120" stroke="${d}" stroke-width="4" fill="none"/>`;
 else b=`<path class="fl" d="M58 116Q65 138 72 116Z" fill="#ff9f1c"/><path d="M65 44L85 82L128 104V112L80 104L72 116H58L50 104L2 112V104L45 82Z" fill="${c}"/><path d="M65 44L72 82H58Z" fill="${l}"/><ellipse cx="65" cy="86" rx="8" ry="11" fill="#bfefff" stroke="${d}" stroke-width="3"/>`;
 return `<svg class="shipsvg" viewBox="0 0 130 140" xmlns="http://www.w3.org/2000/svg">${b}</svg>`}

/* ---------- الرفاق ---------- */
function petSvg(id,cls){
 const col={f1:'#ffb347',f2:'#c8956d',f3:'#f4f4f4',f4:'#ffffff',f5:'#ff8c42',f6:'#6fcf4a',f7:'#ffffff',f8:'#7bd957'}[id]||'#ffb347';
 let bk='',ft='',eyes=`<circle cx="22" cy="34" r="3.4" fill="#222"/><circle cx="38" cy="34" r="3.4" fill="#222"/><circle cx="23" cy="33" r="1.2" fill="#fff"/><circle cx="39" cy="33" r="1.2" fill="#fff"/>`;
 let nose=`<ellipse cx="30" cy="41" rx="3" ry="2.3" fill="#e05070"/><path d="M25 46Q30 51 35 46" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>`;
 let head=`<circle cx="30" cy="36" r="21" fill="${col}"/>`;
 if(id=='f1')bk=`<path d="M10 26L12 4L28 16Z M50 26L48 4L32 16Z" fill="${col}"/><path d="M14 20L15 10L22 16Z M46 20L45 10L38 16Z" fill="#ffb3c6"/>`,ft=`<path d="M6 40H18M6 46L18 43M54 40H42M54 46L42 43" stroke="#333" stroke-width="1.5"/>`;
 if(id=='f2')bk=`<ellipse cx="10" cy="32" rx="7" ry="14" fill="#8a5a3a" transform="rotate(12 10 32)"/><ellipse cx="50" cy="32" rx="7" ry="14" fill="#8a5a3a" transform="rotate(-12 50 32)"/>`,ft=`<ellipse cx="30" cy="42" rx="9" ry="6" fill="#f3d2b3"/><ellipse cx="30" cy="40" rx="3.5" ry="2.6" fill="#333"/>`,nose=`<path d="M25 47Q30 52 35 47" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M28 50Q30 58 33 50Z" fill="#ff7a90"/>`;
 if(id=='f3')bk=`<ellipse cx="21" cy="14" rx="6" ry="15" fill="${col}" stroke="#ddd"/><ellipse cx="39" cy="14" rx="6" ry="15" fill="${col}" stroke="#ddd"/><ellipse cx="21" cy="15" rx="3" ry="10" fill="#ffb3c6"/><ellipse cx="39" cy="15" rx="3" ry="10" fill="#ffb3c6"/>`,head=`<circle cx="30" cy="38" r="19" fill="${col}" stroke="#ddd"/>`;
 if(id=='f4')bk=`<circle cx="13" cy="19" r="8" fill="#222"/><circle cx="47" cy="19" r="8" fill="#222"/>`,head=`<circle cx="30" cy="36" r="21" fill="#fff" stroke="#ddd"/><ellipse cx="21" cy="33" rx="6" ry="8" fill="#222" transform="rotate(20 21 33)"/><ellipse cx="39" cy="33" rx="6" ry="8" fill="#222" transform="rotate(-20 39 33)"/>`,eyes=`<circle cx="22" cy="33" r="2.6" fill="#fff"/><circle cx="38" cy="33" r="2.6" fill="#fff"/>`,nose=`<ellipse cx="30" cy="42" rx="3.4" ry="2.4" fill="#222"/><path d="M25 47Q30 52 35 47" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>`;
 if(id=='f5')bk=`<path d="M8 28L10 2L28 16Z M52 28L50 2L32 16Z" fill="${col}"/><path d="M10 12L10 2L17 8Z M50 12L50 2L43 8Z" fill="#4a2f22"/>`,ft=`<path d="M9 40Q30 66 51 40Q30 48 9 40Z" fill="#fff"/><ellipse cx="30" cy="41" rx="3" ry="2.3" fill="#222"/>`,nose=`<path d="M26 48Q30 52 34 48" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>`;
 if(id=='f6')bk=`<circle cx="18" cy="17" r="10" fill="${col}"/><circle cx="42" cy="17" r="10" fill="${col}"/>`,head=`<ellipse cx="30" cy="38" rx="24" ry="19" fill="${col}"/>`,eyes=`<circle cx="18" cy="16" r="6" fill="#fff"/><circle cx="42" cy="16" r="6" fill="#fff"/><circle cx="19" cy="17" r="3" fill="#222"/><circle cx="41" cy="17" r="3" fill="#222"/>`,nose=`<path d="M14 42Q30 56 46 42" stroke="#2b6a1a" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="26" cy="35" r="1.3" fill="#2b6a1a"/><circle cx="34" cy="35" r="1.3" fill="#2b6a1a"/>`;
 if(id=='f7')bk=`<path d="M8 28Q0 44 10 58" stroke="#ff7ab8" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M12 22L14 8L26 16Z M48 22L46 8L34 16Z" fill="#fff" stroke="#ddd"/>`,ft=`<path d="M30 -2L24 18H36Z" fill="#ffd23f" stroke="#e0a800" stroke-width="1.5"/><path d="M14 22Q22 12 30 18" stroke="#ff7ab8" stroke-width="5" fill="none" stroke-linecap="round"/>`,nose=`<circle cx="26" cy="43" r="1.5" fill="#b86"/><circle cx="34" cy="43" r="1.5" fill="#b86"/><path d="M25 48Q30 52 35 48" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>`;
 if(id=='f8')bk=`<path d="M16 20L8 2L26 14Z M44 20L52 2L34 14Z" fill="#ffd23f"/><path d="M0 40Q6 26 14 36Z M60 40Q54 26 46 36Z" fill="#4cae2e"/>`,ft=`<ellipse cx="30" cy="46" rx="11" ry="8" fill="#c9f2a8"/><circle cx="26" cy="45" r="1.6" fill="#2b6a1a"/><circle cx="34" cy="45" r="1.6" fill="#2b6a1a"/>`,nose=`<path d="M24 51Q30 55 36 51" stroke="#333" stroke-width="2" fill="none" stroke-linecap="round"/>`;
 return `<svg class="${cls||'pet'}" viewBox="0 -4 60 64" xmlns="http://www.w3.org/2000/svg">${bk}${head}${ft}${eyes}${nose}</svg>`}
