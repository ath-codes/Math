/* v2.3 — مواد جديدة: حروف عربية، كلمات، إنجليزي للمبتدئين. تُحمَّل بعد minigames.js.
   gen(p,qi,'S') يعيد سؤال مادة (بدل الرياضيات). q.c نصوص، q.a النص الصحيح، q.s نص قصير للّوحات، q.S=1.
   المستوى حسب العمر p.g: 0 = ٥-٦، 1 = ٧-٨، 2 = ٩. لإضافة موضوع: أضف دالة إلى TOP ووزنها في WT. */
const LT=s=>'\u2066'+s+'\u2069',shf=a=>a.slice().sort(()=>Math.random()-.5),pick=a=>a[Math.floor(Math.random()*a.length)];
const AW=[['أرنب','🐰','أ'],['بطة','🦆','ب'],['تفاحة','🍎','ت'],['ثعلب','🦊','ث'],['جمل','🐪','ج'],['حصان','🐴','ح'],['خروف','🐑','خ'],['دب','🐻','د'],['ذرة','🌽','ذ'],['زرافة','🦒','ز'],['سمكة','🐟','س'],['شمس','☀️','ش'],['صاروخ','🚀','ص'],['ضفدع','🐸','ض'],['طائرة','✈️','ط'],['ظبي','🦌','ظ'],['عصفور','🐦','ع'],['غيمة','☁️','غ'],['فيل','🐘','ف'],['قمر','🌙','ق'],['كلب','🐶','ك'],['ليمون','🍋','ل'],['موز','🍌','م'],['نجمة','⭐','ن'],['هدية','🎁','ه'],['وردة','🌹','و'],['يد','✋','ي']];
const ALET=AW.map(w=>w[2]);
const MW=['بطة','جمل','حصان','خروف','دب','سمكة','شمس','فيل','قمر','كلب','ليمون','موز','نجمة','وردة','زرافة','صاروخ','عصفور','تفاحة'];
const OPP=[['كبير','صغير'],['طويل','قصير'],['حار','بارد'],['سريع','بطيء'],['ثقيل','خفيف'],['فوق','تحت'],['نهار','ليل'],['سعيد','حزين'],['جديد','قديم'],['مفتوح','مغلق'],['قريب','بعيد'],['ممتلئ','فارغ'],['نظيف','متسخ'],['قوي','ضعيف']];
const EW=[['Apple','🍎'],['Ball','⚽'],['Cat','🐱'],['Dog','🐶'],['Egg','🥚'],['Fish','🐟'],['Grapes','🍇'],['Hat','🎩'],['Ice cream','🍦'],['Juice','🧃'],['Key','🔑'],['Lion','🦁'],['Moon','🌙'],['Nose','👃'],['Orange','🍊'],['Pizza','🍕'],['Queen','👑'],['Rabbit','🐰'],['Sun','☀️'],['Tree','🌳'],['Umbrella','☂️'],['Van','🚐'],['Watch','⌚'],['Zebra','🦓']];
const EO=[['Cat','🐱'],['Dog','🐶'],['Bird','🐦'],['Fish','🐟'],['Lion','🦁'],['Horse','🐴'],['Cow','🐮'],['Apple','🍎'],['Banana','🍌'],['Car','🚗'],['Bus','🚌'],['Book','📖'],['Sun','☀️'],['Moon','🌙'],['Star','⭐'],['Tree','🌳'],['House','🏠'],['Ball','⚽'],['Egg','🥚'],['Milk','🥛'],['Bread','🍞'],['Flower','🌸'],['Hand','✋'],['Eye','👁️'],['Pizza','🍕'],['Cake','🎂'],['Bed','🛏️'],['Boat','⛵'],['Plane','✈️'],['Rain','🌧️']];
const EC=[['Red','🔴'],['Blue','🔵'],['Green','🟢'],['Yellow','🟡'],['Orange','🟠'],['Purple','🟣'],['Black','⚫'],['White','⚪'],['Brown','🟤']];
const EN=['One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen','Twenty'];
const three=(a,x,n)=>{const o=shf(a.filter(v=>v!=x)).slice(0,n-1);return shf([x,...o])};
const Q=(k,t,s,e,a,c,h)=>({k,t,s,e:e||null,a,c,h,o:'S',nl:'',S:1,say:t.replace(/[\u2066\u2069]/g,'')});
const NC=g=>g==0?3:4;
const TOP={
 arStart:g=>{const w=pick(AW);return Q('as'+w[0],`ما الحرف الأول في كلمة «${w[0]}»؟`,`${w[1]} ؟`,w[1],w[2],three(ALET,w[2],NC(g)),`${w[0]} تبدأ بحرف ${w[2]}`)},
 arMissing:g=>{const w=pick(MW),L=[...w].filter(x=>x!='ة'),i=Math.floor(Math.random()*L.length),em=(AW.find(x=>x[0]==w)||[])[1],a=L[i],d=L.map((x,j)=>j==i?'◻':x).join(' ');
  return Q('am'+w+i,`أكمل الكلمة: ${d}`,d,em,a,three([...new Set(ALET.concat(['ر']))],a,NC(g)),`الكلمة هي ${w}`)},
 arCount:g=>{const w=pick(MW),n=w.length,em=(AW.find(x=>x[0]==w)||[])[1];return Q('ac'+w,`كم حرفاً في كلمة «${w}»؟`,`${w} = ؟`,em,n,three([2,3,4,5,6,7],n,NC(g)),`عُدّ الحروف: ${[...w].join(' - ')}`)},
 arOpp:g=>{const pr=pick(OPP),f=Math.random()<.5,w=f?pr[0]:pr[1],a=f?pr[1]:pr[0],all=OPP.flat();return Q('ao'+w,`ما عكس كلمة «${w}»؟`,`${w} ↔ ؟`,null,a,three(all,a,NC(g)),`عكس ${w} هو ${a}`)},
 enLetter:g=>{const w=pick(EW),a=w[0][0];return Q('el'+w[0],`ما الحرف الأول في ${LT(w[0])}؟`,`${w[1]} ؟`,w[1],a,three('ABCDEFGHIJKLMNOPQRSTUVWZ'.split(''),a,NC(g)),`${LT(w[0])} تبدأ بحرف ${a}`)},
 enColor:g=>{const c=pick(EC);return Q('ec'+c[0],'ما اسم هذا اللون بالإنجليزية؟',`${c[1]} = ?`,c[1],c[0],three(EC.map(x=>x[0]),c[0],NC(g)),`اللون ${c[1]} هو ${LT(c[0])}`)},
 enNum:g=>{const m=g>=2?20:10,n=1+Math.floor(Math.random()*m),a=EN[n-1];return Q('en'+n,`كيف نقول ${n} بالإنجليزية؟`,`${n} = ?`,null,a,three(EN.slice(0,m),a,NC(g)),`${n} بالإنجليزية ${LT(a)}`)},
 enObj:g=>{const o=pick(EO);return Q('eo'+o[0],'ماذا يُسمّى هذا بالإنجليزية؟',`${o[1]} = ?`,o[1],o[0],three(EO.map(x=>x[0]),o[0],NC(g)),`هذا ${LT(o[0])}`)},
 enPic:g=>{const o=pick(EO);return Q('ep'+o[0],`أيّ صورة هي ${LT(o[0])}؟`,LT(o[0]),null,o[1],three(EO.map(x=>x[1]),o[1],NC(g)),`${LT(o[0])} يعني ${o[1]}`)},
 enMiss:g=>{const o=pick(EO.filter(x=>x[0].length<=5)),L=[...o[0]],i=1+Math.floor(Math.random()*(L.length-1)),a=L[i].toLowerCase(),d=L.map((x,j)=>j==i?'_':x).join(' ');
  return Q('ex'+o[0]+i,`أكمل الكلمة: ${LT(d)}`,LT(d),o[1],a,three('abcdefghilmnoprstu'.split(''),a,NC(g)),`الكلمة ${LT(o[0])}`)}};
const WT=[{arStart:5,enLetter:2,enColor:3,enNum:2},{arStart:2,arMissing:3,arCount:2,arOpp:2,enLetter:1,enColor:1,enNum:1,enObj:3},{arMissing:2,arCount:1,arOpp:3,enNum:1,enObj:2,enPic:3,enMiss:3}];
const genMath=gen;
gen=function(p,qi,ctx){if(ctx!='S')return genMath(p,qi);
 p.recent=p.recent||[];const g=Math.max(0,Math.min(2,p.g||0)),w=WT[g],ks=Object.keys(w),tot=ks.reduce((x,k)=>x+w[k],0);let q;
 for(let n=0;n<25;n++){let r=Math.random()*tot,k=ks[0];for(const kk of ks){if(r<w[kk]){k=kk;break}r-=w[kk]}q=TOP[k](g);if(!p.recent.includes(q.k))break}
 p.recent.push(q.k);if(p.recent.length>40)p.recent.shift();return q};
/* استراحة: نسخ المواد من لعبتي الفضائي والإطعام */
MGL.splice(1,0,{id:'alienS',n:'اضرب الفضائي: حروف وكلمات',e:'👾',d:'فضائيون يحملون حروفاً وكلمات. اضرب من يحمل الإجابة الصحيحة!',f:d=>mgAlien(d,'S')});
MGL.splice(4,0,{id:'feedS',n:'أطعِم رفيقك: حروف وكلمات',e:'🍎',d:'رفيقك جائع! أطعمه الطعام الذي يحمل الإجابة الصحيحة.',f:d=>mgFeed(d,'S')});
